#pragma once
#define NITORI_X_CHECKED 1

// 00_config
#include <bits/stdc++.h>
using namespace std;
template<class T>using rmref=remove_reference_t<T>;
template<class T>using uncv=remove_cvref_t<T>;
template<class T>inline constexpr bool is_lref=is_lvalue_reference_v<T>;
template<class T>using limits=numeric_limits<T>;
template<bool C,class T,class F>using select_t=conditional_t<C,T,F>;
template<class T>using uint_t=make_unsigned_t<T>;
template<class T>concept sint=signed_integral<T>;
template<class T>concept uintg=unsigned_integral<T>;
template<class T>inline constexpr bool is_num=is_arithmetic_v<T>;
#if defined(NITORI_X_CHECKED) == defined(NITORI_X_UNSAFE)
#error select one Nitori profile
#endif
namespace ni{
[[noreturn]]inline void nfail(const char*e,const char*f,int l){
  fprintf(stderr,"Nitori contract failed: %s (%s:%d)\n",e,f,l);
  abort();
}
}// namespace ni
#ifdef NITORI_X_UNSAFE
#define npre(x)                                                                                                        \
  do{\
    if(!(x))\
      __builtin_unreachable();\
  }while(0)
#else
#define npre(x)                                                                                                        \
  do{\
    if(!(x))\
      ::ni::nfail(#x,__FILE__,__LINE__);\
  }while(0)
#endif
#define nassert(x) npre(x)
inline constexpr int nversion=20000;
#ifdef NITORI_X_UNSAFE
inline constexpr bool nunsafe=true;
#else
inline constexpr bool nunsafe=false;
#endif

// 01_base
inline constexpr int npos=-1;
template<class T>using nwide_t=select_t<is_integral_v<T>,__int128_t,long double>;
template<class T>
inline constexpr T ninf=[]{
  if constexpr(limits<T>::has_infinity)
    return limits<T>::infinity();
  else
    return limits<T>::max()/4;
}();
template<class T>
inline constexpr T nninf=[]{
  if constexpr(limits<T>::has_infinity)
    return-limits<T>::infinity();
  else if constexpr(is_signed_v<T>)
    return limits<T>::lowest()/4;
  else
    return T{};
}();

namespace ni{
template<integral T,integral U>constexpr T icast(U x){
  if constexpr(sint<U>&&sint<T>)
    npre(__int128_t(x)>=limits<T>::lowest()&&__int128_t(x)<=limits<T>::max());
  else if constexpr(sint<U>)
    npre(x>=0&&__uint128_t(x)<=limits<T>::max());
  else
    npre(__uint128_t(x)<=limits<T>::max());
  return T(x);
}
template<integral T>constexpr int cint(T x){
  return icast<int>(x);
}
template<class T,class U>
T numcast(U x)
  requires is_num<T>&&is_num<U>
{
  if constexpr(integral<T>&&integral<U>)
    return icast<T>(x);
  long double y=x;
  npre(!isnan(y));
  if constexpr(integral<T>){
    npre(isfinite(y)&&trunc(y)==y);
    long double z=ldexp(1.L,limits<T>::digits);
    if constexpr(sint<T>)
      npre(-z<=y&&y<z);
    else
      npre(0<=y&&y<z);
  }else if(isfinite(y))
    npre(abs(y)<=limits<T>::max());
  else
    npre(limits<T>::has_infinity);
  return T(x);
}
template<class T>T cadd(T a,T b){
  if constexpr(is_integral_v<T>){
    T c;
    npre(!__builtin_add_overflow(a,b,&c));
    return c;
  }else
    return a+b;
}
template<class T>T nchecked_sub(T a,T b){
  if constexpr(is_integral_v<T>){
    T c;
    npre(!__builtin_sub_overflow(a,b,&c));
    return c;
  }else
    return a-b;
}
template<class T>T cmul(T a,T b){
  if constexpr(is_integral_v<T>){
    T c;
    npre(!__builtin_mul_overflow(a,b,&c));
    return c;
  }else
    return a*b;
}
}// namespace ni

template<class T>struct nmaybe{
  optional<T>x;
  nmaybe()=default;
  nmaybe(const T&v):x(v){}
  nmaybe(T&&v):x(move(v)){}
  bool ok()const{return x.has_value();}
  explicit operator bool()const{return ok();}
  T&val(){
    npre(ok());
    return*x;
  }
  const T&val()const{
    npre(ok());
    return*x;
  }
  T val(T z)const&{return x?*x:move(z);}
  T val(T z)&&{return x?move(*x):move(z);}
  T&operator*(){return val();}
  const T&operator*()const{return val();}
  T*operator->(){return&val();}
  const T*operator->()const{return&val();}
  void reset(){x.reset();}
};

template<class T,class U>bool nchmin(T&a,U&&b){
  if(b<a){
    a=forward<U>(b);
    return true;
  }
  return false;
}
template<class T,class U>bool nchmax(T&a,U&&b){
  if(a<b){
    a=forward<U>(b);
    return true;
  }
  return false;
}

namespace ni{
template<class A>
concept nhas_len=requires(const A&a){
  {a.len()}->integral;
};
template<class A>
concept nhas_size=requires(const A&a){
  {a.size()}->integral;
};
}// namespace ni
template<class A>
int nlen(const A&a)
  requires ni::nhas_len<A>||(!requires{a.len();}&&ni::nhas_size<A>)
{
  auto n=[&]{
    if constexpr(ni::nhas_len<A>)
      return a.len();
    else
      return a.size();
  }();
  if constexpr(sint<decltype(n)>)
    npre(n>=0);
  return ni::cint(n);
}
inline int nbitceil(int n){
  npre(0<=n&&n<=1<<30);
  return n<=1?1:int(bit_ceil(unsigned(n)));
}
template<class=void>struct nless{
  bool operator()(const auto&a,const auto&b)const{return a<b;}
};
template<class=void>struct ngreater{
  bool operator()(const auto&a,const auto&b)const{return b<a;}
};
template<class=void>struct nequal{
  bool operator()(const auto&a,const auto&b)const{return a==b;}
};
struct nidentity{
  template<class T>T&&operator()(T&&x)const{return forward<T>(x);}
};

struct nrng{
  using result_type=uint64_t;
  uint64_t s;
  explicit constexpr nrng(uint64_t s=0x243f6a8885a308d3ULL):s(s){}
  static constexpr uint64_t min(){return 0;}
  static constexpr uint64_t max(){return ~0ULL;}
  static constexpr uint64_t mix(uint64_t x){
    x+=0x9e3779b97f4a7c15ULL;
    x=(x^(x>>30))*0xbf58476d1ce4e5b9ULL;
    x=(x^(x>>27))*0x94d049bb133111ebULL;
    return x^(x>>31);
  }
  uint64_t operator()(){return s=mix(s);}
  template<integral T>T operator()(T n){
    npre(n>0);
    return T((__uint128_t((*this)())*uint_t<T>(n))>>64);
  }
  template<integral T>T operator()(T l,T r){
    npre(l<r);
    using U=uint_t<T>;
    U d=U(r)-U(l);
    if constexpr(sint<T>)
      return T(__int128_t(l)+(*this)(d));
    else
      return T(U(l)+(*this)(d));
  }
};
inline uint64_t nseed_value=chrono::steady_clock::now().time_since_epoch().count()^uintptr_t(&nseed_value);
inline nrng nrng_global(nseed_value);
inline uint64_t nhash_seed=nrng::mix(nseed_value);
inline void nseed(uint64_t s){
  nseed_value=s;
  nrng_global=nrng(s);
  nhash_seed=nrng::mix(s);
}
template<class T>struct nhash{
  uint64_t s=nhash_seed;
  nhash()=default;
  explicit nhash(uint64_t s):s(s){}
  size_t operator()(const T&x)const noexcept(noexcept(hash<T>{}(x))){return nrng::mix(uint64_t(hash<T>{}(x))+s);}
};
template<class A,class B>struct nhash<pair<A,B>>{
  uint64_t s=nhash_seed;
  nhash()=default;
  explicit nhash(uint64_t s):s(s){}
  size_t operator()(const pair<A,B>&x)const{
    uint64_t a=nhash<A>{s}(x.first),b=nhash<B>{s^0x9e3779b97f4a7c15ULL}(x.second);
    return nrng::mix(a^(b+0x9e3779b97f4a7c15ULL));
  }
};

// 02_algebra
enum class nlaw:unsigned{none=0,associative=1,identity=2,inverse=4,commutative=8,idempotent=16};
constexpr nlaw operator|(nlaw a,nlaw b){
  return nlaw(unsigned(a)|unsigned(b));
}
constexpr bool nhas_law(nlaw a,nlaw b){
  return(unsigned(a)&unsigned(b))==unsigned(b);
}

template<class O,nlaw L>
concept ndeclares=requires{
  {O::laws}->convertible_to<nlaw>;
}&&nhas_law(O::laws,L);
template<class O,class T>
concept nsemigroup=ndeclares<O,nlaw::associative>&&requires(O o,T a,const T&b){
  {o(move(a),b)}->convertible_to<T>;
};
template<class O,class T>
concept nmonoid=nsemigroup<O,T>&&ndeclares<O,nlaw::identity>&&requires(O o){
  {o.id()}->convertible_to<T>;
};
template<class O,class T>
concept ngroup=nmonoid<O,T>&&ndeclares<O,nlaw::inverse>&&requires(O o,T a){
  {o.inv(move(a))}->convertible_to<T>;
};
template<class O,class T>
concept ncommutative_monoid=nmonoid<O,T>&&ndeclares<O,nlaw::commutative>;
template<class A,class M,class T>inline constexpr bool nsemiring_laws=false;
template<class A,class M,class T>
concept nsemiring=
    ncommutative_monoid<A,T>&&nmonoid<M,T>&&nsemiring_laws<uncv<A>,uncv<M>,T>;
template<class T>inline constexpr bool nadd_group=is_num<T>&&!same_as<remove_cv_t<T>,bool>;
template<class T>inline constexpr bool nexact_field=false;
template<class T>
concept nexact_field_element=
    nexact_field<uncv<T>>&&copyable<uncv<T>>&&requires(T a,const T&b){
      T{};
      T{1};
      a==b;
      a!=b;
      a*b;
      a*=b;
      a-=b;
      a/b;
      -a;
    };
template<class T>concept nfield=nexact_field_element<T>;
template<class A,class S,class F>inline constexpr bool naction_laws=false;
template<class A,class S,class F>
concept naction=copyable<F>&&naction_laws<uncv<A>,S,F>&&requires(A a,S s,const F&f){
  {a.tag_id()}->convertible_to<F>;
  {a.compose(f,f)}->convertible_to<F>;
  {a.apply(move(s),f,0)}->convertible_to<S>;
};

template<class T>struct nadd{
  static constexpr nlaw laws=
      nlaw::associative|nlaw::identity|(nadd_group<T>?nlaw::inverse|nlaw::commutative:nlaw::none);
  T id()const{return T{};}
  T operator()(T a,const T&b)const{return a+=b;}
  T inv(T a)const
    requires requires{-a;}
  {
    return-a;
  }
};
template<class T>struct nmul{
  static constexpr nlaw laws=nlaw::associative|nlaw::identity;
  T id()const{return T{1};}
  T operator()(T a,const T&b)const{return a*=b;}
};
template<class T>struct nxor{
  static constexpr nlaw laws=nlaw::associative|nlaw::identity|nlaw::inverse|nlaw::commutative;
  T id()const{return T{};}
  T operator()(T a,const T&b)const{return a^=b;}
  T inv(T a)const{return a;}
};
template<class T>struct nmin{
  static constexpr nlaw laws=nlaw::associative|nlaw::identity|nlaw::commutative|nlaw::idempotent;
  T id()const{return limits<T>::has_infinity?limits<T>::infinity():limits<T>::max();}
  T operator()(const T&a,const T&b)const{return b<a?b:a;}
};
template<class T>struct nmax{
  static constexpr nlaw laws=nlaw::associative|nlaw::identity|nlaw::commutative|nlaw::idempotent;
  T id()const{
    return limits<T>::has_infinity?-limits<T>::infinity():limits<T>::lowest();
  }
  T operator()(const T&a,const T&b)const{return a<b?b:a;}
};
template<class T>struct naddsum_action{
  T tag_id()const{return T{};}
  T compose(const T&newer,const T&older)const{return older+newer;}
  T apply(T sum,const T&delta,int len)const{return sum+delta*T(len);}
};
template<integral T>
  requires(!same_as<remove_cv_t<T>,bool>)
inline constexpr bool naction_laws<naddsum_action<T>,T,T> = true;
template<integral T>
  requires(!same_as<remove_cv_t<T>,bool>)
inline constexpr bool nsemiring_laws<nadd<T>,nmul<T>,T> = true;

template<class T,class O=nmul<T>>
  requires nmonoid<O,T>&&copy_constructible<T>
T npow(T a,long long e,O op={}){
  uint64_t n;
  if(e<0){
    if constexpr(ngroup<O,T>){
      a=op.inv(move(a));
      n=0-uint64_t(e);
    }
    else{
      npre(e>=0);
      return op.id();
    }
  }else
    n=e;
  T r=op.id();
  while(n){
    if(n&1)
      r=op(move(r),a);
    n>>=1;
    if(n){
      T b=a;
      a=op(move(b),a);
    }
  }
  return r;
}

// 03_ref
namespace ni{
template<class T>struct contig_access{
  T*p{};
  T&operator()(int i)const{return p[i];}
  T*data()const{return p;}
};
inline int nview_volume(int n,int m){
  npre(n>=0&&m>=0&&(!n||m<=INT_MAX/n));
  return n*m;
}
template<class T,bool C>struct matrix_access{
  T*p{};
  int n{},m{};
  ptrdiff_t rs{},cs{};
  matrix_access()=default;
  matrix_access(T*p,int n,int m):p(p),n(n),m(m),rs(m),cs(1){}
  matrix_access(T*p,int n,int m,ptrdiff_t rs,ptrdiff_t cs):p(p),n(n),m(m),rs(rs),cs(cs){}
  T&operator()(int i)const{return(*this)(i/m,i%m);}
  T&operator()(int i,int j)const{
    npre(0<=i&&i<n&&0<=j&&j<m);
    return p[i*rs+j*cs];
  }
  int rows()const{return n;}
  int cols()const{return m;}
  T*data()const
    requires C
  {
    return p;
  }
  T*row_data(int i)const
    requires C
  {
    npre(0<=i&&i<n);
    return m?p+ptrdiff_t(i)*m:p;
  }
};
template<class T>using contig2=matrix_access<T,true>;
template<class T>using stride2=matrix_access<T,false>;
template<class F>struct index2_access{
  int n,m;
  [[no_unique_address]]F f;
  decltype(auto)operator()(int k){return(*this)(k/m,k%m);}
  decltype(auto)operator()(int k)const{return(*this)(k/m,k%m);}
  decltype(auto)operator()(int i,int j){
    npre(0<=i&&i<n&&0<=j&&j<m);
    return invoke(f,i,j);
  }
  decltype(auto)operator()(int i,int j)const
    requires invocable<const F&,int,int>
  {
    npre(0<=i&&i<n&&0<=j&&j<m);
    return invoke(f,i,j);
  }
  int rows()const{return n;}
  int cols()const{return m;}
};
}// namespace ni

template<class T,class F=ni::contig_access<T>>struct nview{
  int n{};
  [[no_unique_address]]F f;
  using element_type=T;
  using value_type=remove_cv_t<T>;
  using reference=invoke_result_t<F&,int>;
  using accessor_type=F;
  using nview_tag=void;
  using nrange_tag=void;
  nview()
    requires default_initializable<F>
  =default;
  nview(T*p,int n)
    requires same_as<F,ni::contig_access<T>>
      :n(n),f{p}{
    npre(n>=0&&(!n||p));
  }
  nview(T*p,int r,int c)
    requires same_as<F,ni::contig2<T>>
      :n(ni::nview_volume(r,c)),f(p,r,c){
    npre(!n||p);
  }
  nview(T*p,int r,int c,ptrdiff_t rs,ptrdiff_t cs)
    requires same_as<F,ni::stride2<T>>
      :n(ni::nview_volume(r,c)),f(p,r,c,rs,cs){
    npre(!n||p);
  }
  template<class G>
  nview(int r,int c,G g)
    requires same_as<F,ni::index2_access<G>>
      :n(ni::nview_volume(r,c)),f{r,c,move(g)}{}
  template<size_t N>
  nview(T(&a)[N])
    requires same_as<F,ni::contig_access<T>>
      :n(int(N)),f{a}{
    static_assert(N<=INT_MAX);
  }
  template<class U>
  nview(const nview<U>&a)
    requires same_as<F,ni::contig_access<T>>&&is_convertible_v<U(*)[],T(*)[]>
      :n(a.len()),f{a.data()}{}
  nview(int n,F f):n(n),f(move(f)){npre(n>=0);}
  int len()const{return n;}
  bool empty()const{return!n;}
  int rows()const
    requires requires{f.rows();}
  {
    return f.rows();
  }
  int cols()const
    requires requires{f.cols();}
  {
    return f.cols();
  }
  int dim(int d,int miss=npos)const
    requires requires{
      f.rows();
      f.cols();
    }
  {
    return d==0?rows():d==1?cols():miss;
  }
  decltype(auto)data()
    requires requires{f.data();}
  {
    return f.data();
  }
  decltype(auto)data()const
    requires requires{f.data();}
  {
    return f.data();
  }
  decltype(auto)row_data(int i)
    requires requires{f.row_data(i);}
  {
    return f.row_data(i);
  }
  decltype(auto)row_data(int i)const
    requires requires{f.row_data(i);}
  {
    return f.row_data(i);
  }
  decltype(auto)operator[](int i){
    npre(0<=i&&i<n);
    return invoke(f,i);
  }
  decltype(auto)operator[](int i)const
    requires invocable<const F&,int>
  {
    npre(0<=i&&i<n);
    return invoke(f,i);
  }
  template<integral... I>
  decltype(auto)operator()(I... i)
    requires(sizeof...(I)>1&&invocable<F&,I...>)
  {
    return invoke(f,i...);
  }
  template<integral... I>
  decltype(auto)operator()(I... i)const
    requires(sizeof...(I)>1&&invocable<const F&,I...>)
  {
    return invoke(f,i...);
  }
  auto get(int i)
    requires is_lref<decltype((*this)[0])>
  {
    using P=add_pointer_t<rmref<decltype((*this)[0])>>;
    return 0<=i&&i<n?addressof((*this)[i]):P{};
  }
  auto get(int i)const
    requires is_lref<decltype((*this)[0])>
  {
    using P=add_pointer_t<rmref<decltype((*this)[0])>>;
    return 0<=i&&i<n?addressof((*this)[i]):P{};
  }
};
template<class T>nview(T*,int)->nview<T>;
template<class T,size_t N>nview(T(&)[N])->nview<T>;
template<class T>nview(T*,int,int)->nview<T,ni::contig2<T>>;
template<class T>nview(T*,int,int,ptrdiff_t,ptrdiff_t)->nview<T,ni::stride2<T>>;
template<class F>
nview(int,int,F)->nview<rmref<invoke_result_t<F&,int,int>>,ni::index2_access<F>>;
template<class F>nview(int,F)->nview<rmref<invoke_result_t<F&,int>>,F>;

template<class A>
concept nindexed=requires(A&a,const A&b){
  nlen(b);
  a[0];
  b[0];
};
template<class A>using nindex_reference_t=decltype(declval<A&>()[0]);
template<class A>using nindex_value_t=uncv<nindex_reference_t<A>>;
template<class A>using nref_t=nindex_reference_t<A>;
template<class A>using nvalue_t=nindex_value_t<A>;
template<class A>
concept nreference_indexed=nindexed<A>&&is_lref<nindex_reference_t<A>>;
template<class A>
concept nswappable_indexed=nreference_indexed<A>&&!is_const_v<rmref<nindex_reference_t<A>>>&&
                             requires(A&a){ranges::swap(a[0],a[0]);};
template<class A>
concept ncontiguous_indexed=nindexed<A>&&requires(A&a){
  {a.data()}->contiguous_iterator;
};
template<class A>
concept nresizable=requires(A&a){a.resize(0);};
template<class A>
concept nview_object=requires{typename uncv<A>::nview_tag;};
template<class A>
concept nrange_object=requires{typename uncv<A>::nrange_tag;};
template<class A>
concept nviewable_indexed=
    nindexed<rmref<A>>&&(is_lref<A>||nrange_object<uncv<A>>)&&
    (!nrange_object<uncv<A>>||constructible_from<uncv<A>,A>);
template<class A>concept nviewable=nviewable_indexed<A>;

namespace ni{
template<class A,bool Own=nview_object<uncv<A>>||!is_lref<A>>struct nholder{
  static constexpr bool owns=Own;
  using U=rmref<A>;
  using S=select_t<Own,uncv<A>,U*>;
  [[no_unique_address]]S x;
  explicit nholder(A a)
      :x([&]()->S{
          if constexpr(Own)
            return forward<A>(a);
          else
            return addressof(a);
        }()){}
  decltype(auto)get(){
    if constexpr(Own)
      return(x);
    else
      return*x;
  }
  decltype(auto)get()const{
    if constexpr(Own)
      return(x);
    else
      return*x;
  }
};
template<class A>
auto nhold(A&&a)
  requires nviewable_indexed<A&&>
{
  return nholder<A&&>(forward<A>(a));
}
}// namespace ni

template<class A>
auto nall(A&&a)
  requires nviewable_indexed<A&&>
{
  if constexpr(nview_object<uncv<A>>)
    return uncv<A>(forward<A>(a));
  else if constexpr(is_lref<A&&>&&ncontiguous_indexed<rmref<A>>)
    return nview(a.data(),nlen(a));
  else{
    auto h=ni::nhold(forward<A>(a));
    int n=nlen(h.get());
    return nview(n,[h=move(h)](int i)->decltype(auto){return h.get()[i];});
  }
}
template<class A>
auto nsub(A&&a,int l,int r)
  requires nviewable_indexed<A&&>
{
  npre(0<=l&&l<=r&&r<=nlen(a));
  if constexpr(ncontiguous_indexed<rmref<A>>&&
               (is_lref<A&&>||nview_object<uncv<A>>))
    return nview(a.data()+l,r-l);
  else{
    auto h=ni::nhold(forward<A>(a));
    return nview(r-l,[h=move(h),l](int i)->decltype(auto){return h.get()[l+i];});
  }
}
template<class A>
auto nstride(A&&a,int first,int last,int step)
  requires nviewable_indexed<A&&>
{
  auto h=ni::nhold(forward<A>(a));
  int n=nlen(h.get());
  npre(step);
  long long d,s=step;
  if(step>0){
    npre(0<=first&&first<=last&&last<=n);
    d=last-first;
  }else{
    if(first==last)
      npre(-1<=first&&first<=n);
    else
      npre(-1<=last&&last<first&&first<n);
    d=first-last;
    s=-s;
  }
  d=(d+s-1)/s;
  npre(d<=INT_MAX);
  return nview(int(d),[h=move(h),first,step](int i)->decltype(auto){return h.get()[first+i*step];});
}
template<class A>
concept nmatrix_viewable=nviewable_indexed<A&&>&&requires(rmref<A>&a){
  a.rows();
  a.cols();
  a(0,0);
};
template<class A>
auto nrow(A&&a,int r)
  requires nmatrix_viewable<A>
{
  npre(0<=r&&r<a.rows());
  if constexpr(requires{a.row_data(r);})
    return nview(a.row_data(r),a.cols());
  else{
    auto h=ni::nhold(forward<A>(a));
    int n=h.get().cols();
    return nview(n,[h=move(h),r](int i)->decltype(auto){return h.get()(r,i);});
  }
}
template<class A>
auto ncolumn(A&&a,int c)
  requires nmatrix_viewable<A>
{
  auto h=ni::nhold(forward<A>(a));
  npre(0<=c&&c<h.get().cols());
  int n=h.get().rows();
  return nview(n,[h=move(h),c](int i)->decltype(auto){return h.get()(i,c);});
}
template<class A>
auto ndiagonal(A&&a,int d=0)
  requires nmatrix_viewable<A>
{
  auto h=ni::nhold(forward<A>(a));
  int n=h.get().rows(),m=h.get().cols();
  npre(-1LL*n<=d&&d<=m);
  int r=max(0,-d),c=max(0,d),z=min(n-r,m-c);
  npre(z>=0);
  return nview(z,[h=move(h),r,c](int i)->decltype(auto){return h.get()(r+i,c+i);});
}

// 04_enum
template<sint T>struct nrange_t{
  T first{},last{},step{1};
  using value_type=T;
  using nrange_tag=void;
  nrange_t()=default;
  nrange_t(T a,T b,T s=1):first(a),last(b),step(s){
    npre(s);
    (void)len();
  }
  int len()const{
    if((step>0&&first>=last)||(step<0&&first<=last))
      return 0;
    __int128 d=step>0?__int128(last)-first:__int128(first)-last;
    __int128 s=step>0?__int128(step):-__int128(step),n=(d+s-1)/s;
    npre(n<=INT_MAX);
    return int(n);
  }
  bool empty()const{return!len();}
  int position(T x)const{
    __int128 d=step>0?__int128(x)-first:__int128(first)-x,s=step>0?__int128(step):-__int128(step);
    if(d<0||d%s)
      return npos;
    d/=s;
    return d<len()?int(d):npos;
  }
  T operator[](int i)const{
    npre(0<=i&&i<len());
    return T(__int128(first)+__int128(i)*step);
  }
  struct cursor{
    T x,last,step;
    int i{};
    bool ok()const{return step>0?x<last:x>last;}
    T val()const{return x;}
    int idx()const{return i;}
    void next(){
      __int128 y=__int128(x)+step;
      x=y>limits<T>::max()||y<limits<T>::lowest()?last:T(y);
      ++i;
    }
  };
  cursor enumerate()const{return{first,last,step};}
};
template<sint T>auto nrange(T b){
  return nrange_t<T>(0,b);
}
template<sint T>auto nrange(T a,T b){
  return nrange_t<T>(a,b);
}
template<sint T>auto nrange(T a,T b,T s){
  return nrange_t<T>(a,b,s);
}
template<integral T>int ni_nloop_count(T n){
  if constexpr(sint<T>)
    if(n<=0)
      return 0;
  npre(__uint128_t(n)<=INT_MAX);
  return int(n);
}

namespace ni{
enum class cmode{value,index,keyvalue};

template<class H,bool Keyed=false>struct indexed_cursor{
  H a;
  int i{};
  bool ok()const{return i<nlen(a.get());}
  decltype(auto)val(){return a.get()[i];}
  decltype(auto)key()
    requires Keyed
  {
    return a.get().key(i);
  }
  int idx()const{return i;}
  void next(){++i;}
};
struct cursor_end{};
template<class R>struct ncursor_entry{
  int index;
  R value;
};
template<class C,cmode Mode>struct cursor_iter{
  C*c;
  bool operator!=(cursor_end)const{return c->ok();}
  decltype(auto)operator*()const{
    if constexpr(Mode==cmode::index)
      return ncursor_entry<decltype(c->val())>{c->idx(),c->val()};
    else if constexpr(Mode==cmode::keyvalue)
      return pair<decltype(c->key()),decltype(c->val())>(c->key(),c->val());
    else
      return c->val();
  }
  void operator++(){c->next();}
};
template<class C,cmode Mode>struct cursor_range{
  C c;
  auto begin(){return cursor_iter<C,Mode>{&c};}
  auto end()const{return cursor_end{};}
};
}// namespace ni
template<class A>
  requires requires(A&&a){forward<A>(a).enumerate();}
decltype(auto)nenumerate(A&&a){
  return forward<A>(a).enumerate();
}
template<class A>
  requires nindexed<rmref<A>>&&(!requires(A&&a){forward<A>(a).enumerate();})
auto nenumerate(A&&a){
  using H=ni::nholder<A&&,!is_lref<A&&>>;
  return ni::indexed_cursor<H>{H(forward<A>(a))};
}
template<class A>using nenumerator_t=uncv<decltype(nenumerate(declval<A>()))>;
template<class A>
concept nenumerable=requires(A&&a){nenumerate(forward<A>(a));}&&requires(nenumerator_t<A>&c){
  c.ok();
  c.val();
  c.idx();
  c.next();
};
template<bool I,class A>auto ni_cur_range(A&&a){
  using C=nenumerator_t<A&&>;
  constexpr auto mode=I?ni::cmode::index:ni::cmode::value;
  return ni::cursor_range<C,mode>{nenumerate(forward<A>(a))};
}
template<class A>
concept nkeyvalue_enumerable=requires(A&&a){
  nenumerate(forward<A>(a)).key();
  nenumerate(forward<A>(a)).val();
};
template<class A>
  requires nkeyvalue_enumerable<A&&>
auto ni_kv_range(A&&a){
  using C=nenumerator_t<A&&>;
  return ni::cursor_range<C,ni::cmode::keyvalue>{nenumerate(forward<A>(a))};
}
template<class A>
  requires(!nkeyvalue_enumerable<A&&>)&&nviewable<A&&>&&requires(rmref<A>&a){a.key(0);}
auto ni_kv_range(A&&a){
  auto h=ni::nhold(forward<A>(a));
  using C=ni::indexed_cursor<decltype(h),true>;
  return ni::cursor_range<C,ni::cmode::keyvalue>{C{move(h)}};
}
#define nfor(x, a) for(auto &&x : ni_cur_range<false>((a)))
#define nfori(i, x, a) for(auto &&[i, x] : ni_cur_range<true>((a)))
#define nforkv(k, v, a) for(auto &&[k, v] : ni_kv_range((a)))
#define nrep(i, n) for(int i = 0, ni_##i = ni_nloop_count((n)); i < ni_##i; ++i)
#define nrrep(i, n) for(int i = ni_nloop_count((n)); i-- > 0;)

template<class A>
  requires nviewable<A&&>
auto nreverse(A&&a){
  int n=nlen(a);
  return nstride(forward<A>(a),n-1,-1,-1);
}
template<class A,class F>
  requires nviewable<A&&>
auto nproject(A&&a,F f){
  auto h=ni::nhold(forward<A>(a));
  int n=nlen(h.get());
  return nview(n,[h=move(h),f=move(f)](int i)->decltype(auto){return invoke(f,h.get()[i]);});
}
template<class A,class B>
  requires nviewable<A&&>&&nviewable<B&&>
auto nzip(A&&a,B&&b){
  auto x=ni::nhold(forward<A>(a)),y=ni::nhold(forward<B>(b));
  int n=min(nlen(x.get()),nlen(y.get()));
  return nview(n,[x=move(x),y=move(y)](
                      int i){return pair<decltype(x.get()[i]),decltype(y.get()[i])>(x.get()[i],y.get()[i]);});
}
template<class A,class B>
  requires nviewable<A&&>&&nviewable<B&&>
auto nproduct(A&&a,B&&b){
  auto x=ni::nhold(forward<A>(a)),y=ni::nhold(forward<B>(b));
  int n=nlen(x.get()),m=nlen(y.get());
  npre(!n||m<=INT_MAX/n);
  return nview(n*m,[x=move(x),y=move(y),m](int i){
    return pair<decltype(x.get()[0]),decltype(y.get()[0])>(x.get()[i/m],y.get()[i%m]);
  });
}
namespace ni{
template<class H>struct win_access{
  H a;
  int w,s;
  auto operator()(int i)const{
    int l=i*s;
    auto h=a;
    return nview(w,[h=move(h),l](int j)->decltype(auto){return h.get()[l+j];});
  }
};
inline int nwindow_count(int n,int w,int s){
  npre(w>=0&&s>0);
  if(w>n)
    return 0;
  long long z=1LL+(n-w)/s;
  npre(z<=INT_MAX);
  return int(z);
}
}// namespace ni
template<class A>
  requires nviewable<A&&>
auto nwindows(A&&a,int w,int s=1){
  auto h=ni::nhold(forward<A>(a));
  int n=ni::nwindow_count(nlen(h.get()),w,s);
  return nview(n,ni::win_access<decltype(h)>{move(h),w,s});
}

// 05_ast
enum class nbranch:unsigned char{left,take,right};

template<class S>class nnode{
public:
  using value_type=typename S::value_type;
  using info_type=typename S::info_type;

private:
  const S*owner_=nullptr;
  int handle_=0;
  uint64_t epoch_=0;

  constexpr nnode(const S*owner,int handle,uint64_t epoch):owner_(owner),handle_(handle),epoch_(epoch){}
  friend S;

public:
  constexpr nnode()=default;

  bool current()const{return owner_&&epoch_==owner_->nnode_epoch();}
  bool ok()const{return current()&&handle_&&owner_->nnode_alive(handle_);}
  explicit operator bool()const{return ok();}

  const value_type&val()const{
    npre(ok());
    return owner_->nnode_val(handle_);
  }
  int count()const{
    npre(current());
    return owner_->nnode_count(handle_);
  }
  int len()const{
    npre(current());
    return owner_->nnode_len(handle_);
  }
  info_type info()const{
    npre(current());
    return owner_->nnode_info(handle_);
  }
  nnode left()const{
    npre(current());
    return{owner_,owner_->nnode_left(handle_),epoch_};
  }
  nnode right()const{
    npre(current());
    return{owner_,owner_->nnode_right(handle_),epoch_};
  }
  int handle()const noexcept{return handle_;}
};

template<class S>
concept nnode_tree=requires(const S&tree){
  {tree.root()}->same_as<nnode<S>>;
};

template<nnode_tree S,class F>nnode<S>nwalk(const S&tree,F&&decide){
  auto node=tree.root();
  while(node){
    nbranch branch=invoke(decide,node);
    if(branch==nbranch::left)
      node=node.left();
    else if(branch==nbranch::right)
      node=node.right();
    else{
      npre(branch==nbranch::take);
      return node;
    }
  }
  return node;
}

template<class A,class T>
concept naugment=copyable<typename A::info_type>&&
                   requires(const A&augment,const T&value,int count,typename A::info_type info){
                     {augment.id()}->convertible_to<typename A::info_type>;
                     {augment.one(value,count)}->convertible_to<typename A::info_type>;
                     {augment.op(info,info)}->convertible_to<typename A::info_type>;
                   };

template<class T>struct nempty_augment{
  using info_type=monostate;
  constexpr info_type id()const{return{};}
  constexpr info_type one(const T&,int)const{return{};}
  constexpr info_type op(info_type,info_type)const{return{};}
};

template<class S>
concept naugmented_tree=nnode_tree<S>&&requires(const S&tree){
  typename S::augment_type;
  {tree.augment()}->same_as<const typename S::augment_type&>;
};

template<naugmented_tree S,class P>nnode<S>nfirst_prefix(const S&tree,P&&predicate){
  const auto&augment=tree.augment();
  auto node=tree.root();
  auto prefix=augment.id();
  while(node){
    auto through_left=augment.op(prefix,node.left().info());
    if(invoke(predicate,through_left)){
      node=node.left();
      continue;
    }
    auto through_node=augment.op(through_left,augment.one(node.val(),node.count()));
    if(invoke(predicate,through_node))
      return node;
    prefix=move(through_node);
    node=node.right();
  }
  return node;
}

template<naugmented_tree S,class P>nnode<S>nlast_suffix(const S&tree,P&&predicate){
  const auto&augment=tree.augment();
  auto node=tree.root();
  auto suffix=augment.id();
  while(node){
    auto through_right=augment.op(node.right().info(),suffix);
    if(invoke(predicate,through_right)){
      node=node.right();
      continue;
    }
    auto through_node=augment.op(augment.one(node.val(),node.count()),through_right);
    if(invoke(predicate,through_node))
      return node;
    suffix=move(through_node);
    node=node.left();
  }
  return node;
}

// 06_func
namespace ni{

template<class A>using held=nholder<A,!is_lref<A>>;

template<class A>auto hold(A&&a){
  return held<A&&>(forward<A>(a));
}

enum class fk{map,gather,branch,bound};

template<class A>
concept fn_src=requires{typename uncv<A>::nfunction_tag;};

template<fk Kind,class A,class B,class C=monostate>struct fn{
  A source;
  [[no_unique_address]]B data;
  [[no_unique_address]]C extra;

  using nrange_tag=void;
  using nfunction_tag=void;

  int len()const{
    if constexpr(Kind==fk::gather)
      return nlen(data.get());
    else
      return nlen(source.get());
  }
  bool empty()const{return!len();}

  int position(int i)const
    requires(Kind==fk::gather)
  {
    npre(0<=i&&i<len());
    int p=cint(data.get()[i]);
    npre(0<=p&&p<nlen(source.get()));
    return p;
  }

  template<class K>
  int locate(const K&key)const
    requires(Kind==fk::bound)
  {
    if constexpr(requires{source.get().position(key);}){
      int i=source.get().position(key);
      npre(i!=npos);
      return i;
    }else{
      auto p=extra.get(key);
      npre(p);
      return*p;
    }
  }

private:
  template<class Self>static decltype(auto)key_at(Self&f,int i){
    npre(0<=i&&i<f.len());
    if constexpr(Kind==fk::gather)
      return f.source.get().key(f.position(i));
    else if constexpr(Kind==fk::branch||(Kind==fk::map&&fn_src<decltype(f.source.get())>))
      return f.source.get().key(i);
    else
      return f.source.get()[i];
  }

  template<class Self>static decltype(auto)value_at(Self&f,int i){
    npre(0<=i&&i<f.len());
    if constexpr(Kind==fk::map){
      decltype(auto)value=f.source.get()[i];
      return invoke(f.data.get(),forward<decltype(value)>(value));
    }else if constexpr(Kind==fk::gather){
      return f.source.get()[f.position(i)];
    }else if constexpr(Kind==fk::branch){
      decltype(auto)key=f.source.get().key(i);
      return invoke(f.data.get(),key)?invoke(f.extra.get(),key):f.source.get()[i];
    }else{
      npre(nlen(f.data.get())==f.len());
      return f.data.get()[i];
    }
  }

  template<class Self,class X>static decltype(auto)call(Self&f,X&&x){
    if constexpr(Kind==fk::map){
      if constexpr(fn_src<decltype(f.source.get())>){
        decltype(auto)value=invoke(f.source.get(),forward<X>(x));
        return invoke(f.data.get(),forward<decltype(value)>(value));
      }else
        return invoke(f.data.get(),forward<X>(x));
    }else if constexpr(Kind==fk::gather)
      return invoke(f.source.get(),forward<X>(x));
    else if constexpr(Kind==fk::branch)
      return invoke(f.data.get(),x)?invoke(f.extra.get(),forward<X>(x)):invoke(f.source.get(),forward<X>(x));
    else
      return f.data.get()[f.locate(x)];
  }

public:
  decltype(auto)key(int i){return key_at(*this,i);}
  decltype(auto)key(int i)const{return key_at(*this,i);}
  decltype(auto)operator[](int i){return value_at(*this,i);}
  decltype(auto)operator[](int i)const{return value_at(*this,i);}

  template<class X>decltype(auto)operator()(X&&x){return call(*this,forward<X>(x));}
  template<class X>decltype(auto)operator()(X&&x)const{return call(*this,forward<X>(x));}

  auto keys()const
    requires copy_constructible<fn>
  {
    return nview(len(),[function=*this](int i)->decltype(auto){return function.key(i);});
  }
};

template<class D,class E>auto make_fn(D&&domain,E&&eval){
  auto source=hold(forward<D>(domain));
  auto data=hold(forward<E>(eval));
  return fn<fk::map,decltype(source),decltype(data)>{move(source),move(data)};
}

}// namespace ni

template<class H,class F>using ndiscrete_function=ni::fn<ni::fk::map,H,F>;

template<class A>
concept ndiscrete=nindexed<A>&&requires(A&a,const A&b){
  a.key(0);
  b.key(0);
};

template<class A>using nfunction_key_reference_t=decltype(declval<A&>().key(0));

template<class A>using nfunction_key_t=uncv<nfunction_key_reference_t<A>>;

template<class D,class F>
auto nfunc(D&&domain,F eval)
  requires nindexed<rmref<D>>&&
           (is_lref<D&&>||constructible_from<uncv<D>,D&&>)&&
           invocable<F&,nref_t<rmref<D>>>
{
  return ni::make_fn(forward<D>(domain),move(eval));
}

template<class G>
auto nkeys(G&&function)
  requires ndiscrete<rmref<G>>
{
  auto source=ni::hold(forward<G>(function));
  int n=nlen(source.get());
  return nview(n,[source=move(source)](int i)->decltype(auto){return source.get().key(i);});
}

template<class G>
auto nvalues(G&&function)
  requires ndiscrete<rmref<G>>&&nviewable<G&&>
{
  return nall(forward<G>(function));
}

template<class G>
auto nentries(G&&function)
  requires ndiscrete<rmref<G>>
{
  auto source=ni::hold(forward<G>(function));
  int n=nlen(source.get());
  return nview(n,[source=move(source)](int i){
    auto&function=source.get();
    return pair<decltype(function.key(i)),decltype(function[i])>(function.key(i),function[i]);
  });
}

template<class G,class D>
auto nrestrict(G&&function,D&&domain)
  requires nindexed<rmref<D>>&&
           (is_lref<D&&>||constructible_from<uncv<D>,D&&>)
{
  return ni::make_fn(forward<D>(domain),forward<G>(function));
}

template<class O,class I>
auto ncompose(O&&outer,I&&inner)
  requires ndiscrete<rmref<I>>
{
  return ni::make_fn(forward<I>(inner),forward<O>(outer));
}

template<class G,class F>
auto nmap_values(G&&function,F&&transform)
  requires ndiscrete<rmref<G>>
{
  return ncompose(forward<F>(transform),forward<G>(function));
}

template<class G,class P>
auto ngather(G&&function,P&&positions)
  requires ndiscrete<rmref<G>>&&nindexed<rmref<P>>&&
           integral<nvalue_t<rmref<P>>>&&
           (is_lref<P&&>||constructible_from<uncv<P>,P&&>)
{
  auto source=ni::hold(forward<G>(function));
  auto data=ni::hold(forward<P>(positions));
  using F=ni::fn<ni::fk::gather,decltype(source),decltype(data)>;
  return F{move(source),move(data)};
}

template<class G>
auto nsubfunc(G&&function,int l,int r)
  requires ndiscrete<rmref<G>>
{
  npre(0<=l&&l<=r&&r<=nlen(function));
  return ngather(forward<G>(function),nrange(l,r));
}

template<class G>
auto nblock(G&&function,int block,int width)
  requires ndiscrete<rmref<G>>
{
  npre(block>=0&&width>0);
  long long l=1LL*block*width;
  npre(l<=nlen(function));
  int r=int(min<long long>(nlen(function),l+width));
  return nsubfunc(forward<G>(function),int(l),r);
}

template<class G>
auto nblocks(G&&function,int width)
  requires ndiscrete<rmref<G>>
{
  auto source=ni::hold(forward<G>(function));
  npre(width>0);
  int n=nlen(source.get());
  return nview(
      (n+width-1)/width,[source=move(source),width](int i){return nblock(source.get(),i,width);});
}

// 10_seq
namespace ni{
template<class D,class T,class B>class sapi:public B{
protected:
  sapi()=default;
  template<class... A>explicit sapi(in_place_t,A&&...a):B(forward<A>(a)...){}
  D&self(){return static_cast<D&>(*this);}
  const D&self()const{return static_cast<const D&>(*this);}

public:
  using value_type=T;
  int len()const{
    npre(B::size()<=size_t(INT_MAX));
    return int(B::size());
  }
  bool empty()const{return B::empty();}
  T&operator[](int i){
    npre(0<=i&&i<len());
    return B::operator[](size_t(i));
  }
  const T&operator[](int i)const{
    npre(0<=i&&i<len());
    return B::operator[](size_t(i));
  }
  T*get(int i){return 0<=i&&i<len()?addressof((*this)[i]):nullptr;}
  const T*get(int i)const{return 0<=i&&i<len()?addressof((*this)[i]):nullptr;}
  T get(int i,T fallback)const{return 0<=i&&i<len()?(*this)[i]:move(fallback);}
  T&front(){
    npre(!empty());
    return B::front();
  }
  const T&front()const{
    npre(!empty());
    return B::front();
  }
  T front(T fallback)const{return empty()?move(fallback):B::front();}
  T&back(){
    npre(!empty());
    return B::back();
  }
  const T&back()const{
    npre(!empty());
    return B::back();
  }
  T back(T fallback)const{return empty()?move(fallback):B::back();}
};
}// namespace ni

template<class T>class nvector:public ni::sapi<nvector<T>,T,vector<T>>{
  using B=vector<T>;
  using api=ni::sapi<nvector,T,B>;
  static size_t size_of(int n){
    npre(n>=0);
    return size_t(n);
  }

public:
  using value_type=T;
  nvector()=default;
  explicit nvector(int n):api(in_place,size_of(n)){}
  nvector(int n,const T&x):api(in_place,size_of(n),x){}
  nvector(initializer_list<T>x):api(in_place,x){}
  int cap()const{
    npre(B::capacity()<=size_t(INT_MAX));
    return int(B::capacity());
  }
  void reserve(int n){
    npre(n>=0);
    B::reserve(size_t(n));
  }
  void resize(int n){
    npre(n>=0);
    B::resize(size_t(n));
  }
  void resize(int n,const T&x){
    npre(n>=0);
    B::resize(size_t(n),x);
  }
  template<class... A>T&push(A&&...x){
    npre(B::size()<size_t(INT_MAX));
    return B::emplace_back(forward<A>(x)...);
  }
  T pop(){
    npre(!B::empty());
    T x=move(B::back());
    B::pop_back();
    return x;
  }
  T pop(T fallback){return B::empty()?move(fallback):pop();}
  void del(int i){
    npre(0<=i&&i<api::len());
    B::erase(B::begin()+i);
  }
  T swapdel(int i){
    npre(0<=i&&i<api::len());
    T x=move((*this)[i]);
    if(i+1<api::len())
      (*this)[i]=move(B::back());
    B::pop_back();
    return x;
  }
  nvector&operator+=(const T&x){
    push(x);
    return*this;
  }
  nvector&operator+=(T&&x){
    push(move(x));
    return*this;
  }
  friend bool operator==(const nvector&a,const nvector&b){
    return static_cast<const B&>(a)==static_cast<const B&>(b);
  }
};
template<class T>using nvector_stl=nvector<T>;

namespace ni{
template<class T>struct own_value{
  using type=T;
};
template<class A,class B>struct own_value<pair<A,B>>{
  using type=
      pair<typename own_value<uncv<A>>::type,typename own_value<uncv<B>>::type>;
};
template<class... T>struct own_value<tuple<T...>>{
  using type=tuple<typename own_value<uncv<T>>::type...>;
};
template<class T>using owned_t=typename own_value<uncv<T>>::type;
template<class A,class=void>struct collect_t{
  using type=owned_t<decltype(declval<nenumerator_t<A>&>().val())>;
};
template<class A>struct collect_t<A,void_t<typename uncv<A>::value_type>>{
  using type=owned_t<typename uncv<A>::value_type>;
};
}// namespace ni
template<class T=void,class A>
  requires nenumerable<A&&>
auto ncollect(A&&a){
  using X=select_t<same_as<T,void>,typename ni::collect_t<A&&>::type,ni::owned_t<T>>;
  nvector<X>r;
  if constexpr(requires{nlen(a);})
    r.reserve(nlen(a));
  nfor(x,forward<A>(a)){
    r.push(forward<decltype(x)>(x));
  }
  return r;
}
template<class G>
  requires ndiscrete<rmref<G>>
auto ntabulate(G&&g){
  return ncollect(forward<G>(g));
}

namespace ni{
template<class T>class deq:public sapi<deq<T>,T,deque<T>>{
  using B=deque<T>;
  using api=sapi<deq,T,B>;

public:
  using value_type=T;
  deq()=default;
  deq(initializer_list<T>x):api(in_place,x){}
  deq(const deq&)=default;
  deq&operator=(const deq&)=default;
  deq(deq&&o)noexcept:api(move(o)){o.clear();}
  deq&operator=(deq&&o)noexcept{
    if(this!=&o){
      api::operator=(move(o));
      o.clear();
    }
    return*this;
  }
  void reserve(int n){npre(n>=0);}
  template<class... A>T&pushr(A&&...x){
    npre(B::size()<size_t(INT_MAX));
    return B::emplace_back(forward<A>(x)...);
  }
  template<class... A>T&pushl(A&&...x){
    npre(B::size()<size_t(INT_MAX));
    return B::emplace_front(forward<A>(x)...);
  }
  T popr(){
    npre(!api::empty());
    T x=move(B::back());
    B::pop_back();
    return x;
  }
  T popl(){
    npre(!api::empty());
    T x=move(B::front());
    B::pop_front();
    return x;
  }
  T popr(T x){return api::empty()?move(x):popr();}
  T popl(T x){return api::empty()?move(x):popl();}
  deq&operator+=(const T&x){
    pushr(x);
    return*this;
  }
  deq&operator+=(T&&x){
    pushr(move(x));
    return*this;
  }
};
}// namespace ni
template<class T>using ndeque_stl=ni::deq<T>;
template<class T>using ndeque=ni::deq<T>;

template<class T,class C=nless<T>>class nheap_binary{
  nvector<T>a_;
  [[no_unique_address]]C cmp_{};
  int up(int i){
    while(i){
      int p=(i-1)/2;
      if(!invoke(cmp_,a_[i],a_[p]))
        break;
      ranges::swap(a_[i],a_[p]);
      i=p;
    }
    return i;
  }
  void down(int i){
    for(;;){
      int j=i*2+1;
      if(j>=len())
        return;
      if(j+1<len()&&invoke(cmp_,a_[j+1],a_[j]))
        ++j;
      if(!invoke(cmp_,a_[j],a_[i]))
        return;
      ranges::swap(a_[i],a_[j]);
      i=j;
    }
  }

public:
  using value_type=T;
  nheap_binary()=default;
  explicit nheap_binary(C c):cmp_(move(c)){}
  template<class A>
    requires nenumerable<const A&>
  explicit nheap_binary(const A&a,C c={}):cmp_(move(c)){
    if constexpr(requires{nlen(a);})
      a_.reserve(nlen(a));
    nfor(x,a)
      a_.push(x);
    for(int i=len()/2;i--;)
      down(i);
  }
  int len()const{return a_.len();}
  bool empty()const{return a_.empty();}
  void clear(){a_.clear();}
  void reserve(int n){a_.reserve(n);}
  template<class... A>T&push(A&&...x){
    a_.push(forward<A>(x)...);
    return a_[up(len()-1)];
  }
  const T&top()const{
    npre(!empty());
    return a_[0];
  }
  T top(T x)const{return empty()?move(x):a_[0];}
  T pop(){
    npre(!empty());
    T x=move(a_[0]);
    if(len()==1){
      a_.pop();
      return x;
    }
    a_[0]=a_.pop();
    down(0);
    return x;
  }
  T pop(T x){return empty()?move(x):pop();}
  void replace(T x){
    npre(!empty());
    a_[0]=move(x);
    down(0);
  }
};
template<class T,class C=nless<T>>using nheap=nheap_binary<T,C>;

template<class T,int R>
  requires(R>0)
class narray{
  array<int,R>d_{};
  nvector<T>a_;
  static int volume(const array<int,R>&d){
    long long z=1;
    for(int x:d){
      npre(x>=0);
      if(!x)
        z=0;
      else if(z){
        npre(z<=INT_MAX/x);
        z*=x;
      }
    }
    return int(z);
  }
  template<integral I>static int coord(I x){return ni::cint(x);}

public:
  using value_type=T;
  using coord_type=array<int,R>;
  narray()=default;
  explicit narray(coord_type d):d_(d),a_(volume(d)){}
  narray(coord_type d,const T&x):d_(d),a_(volume(d),x){}
  static constexpr int rank(){return R;}
  int len()const{return a_.len();}
  bool empty()const{return a_.empty();}
  int dim(int k,int f=npos)const{return 0<=k&&k<R?d_[k]:f;}
  nview<const int>shape()const{return{d_.data(),R};}
  T*data(){return a_.data();}
  const T*data()const{return a_.data();}
  int pos(const coord_type&c,int f=npos)const{
    int p=0;
    nrep(k,R){
      if(c[k]<0||c[k]>=d_[k])
        return f;
      p=p*d_[k]+c[k];
    }
    return p;
  }
  T&operator[](int i){return a_[i];}
  const T&operator[](int i)const{return a_[i];}
  T&operator()(const coord_type&c){
    int i=pos(c);
    npre(i!=npos);
    return a_[i];
  }
  const T&operator()(const coord_type&c)const{
    int i=pos(c);
    npre(i!=npos);
    return a_[i];
  }
  template<class... I>
    requires(sizeof...(I)==R&&(integral<uncv<I>>&&...))
  T&operator()(I... x){
    return(*this)(coord_type{coord(x)...});
  }
  template<class... I>
    requires(sizeof...(I)==R&&(integral<uncv<I>>&&...))
  const T&operator()(I... x)const{
    return(*this)(coord_type{coord(x)...});
  }
};

namespace ni{
template<class C,class P>struct projected_compare{
  [[no_unique_address]]C c;
  [[no_unique_address]]P p;
  template<class A,class B>bool operator()(A&&a,B&&b){
    return invoke(c,invoke(p,forward<A>(a)),invoke(p,forward<B>(b)));
  }
};
template<class A,class P>using projected_value_t=uncv<invoke_result_t<P&,nref_t<A>>>;
template<class A,class C>void nheap_sift(A&a,int i,int n,C&c){
  for(;;){
    int j=i*2+1;
    if(j>=n)
      return;
    if(j+1<n&&c(a[j],a[j+1]))
      ++j;
    if(!c(a[i],a[j]))
      return;
    ranges::swap(a[i],a[j]);
    i=j;
  }
}
template<class A,class C>void nheap_sort(A&a,C&c){
  int n=nlen(a);
  for(int i=n/2;i--;)
    nheap_sift(a,i,n,c);
  while(n>1){
    ranges::swap(a[0],a[--n]);
    nheap_sift(a,0,n,c);
  }
}
}// namespace ni

template<class A,class X>
  requires nviewable<A&&>
void nfill(A&&a,const X&x){
  nrep(i,nlen(a))
    a[i]=x;
}
template<class D,class S,class P=nidentity>
  requires nviewable<D&&>&&nenumerable<S&&>
void nassign(D&&d,S&&s,P p={}){
  int n=nlen(d);
  auto c=nenumerate(forward<S>(s));
  if constexpr(requires{nlen(s);})
    npre(n==nlen(s));
  nrep(i,n){
    if constexpr(!requires{nlen(s);})
      npre(c.ok());
    d[i]=invoke(p,c.val());
    c.next();
  }
  if constexpr(!requires{nlen(s);})
    npre(!c.ok());
}
template<class A,class B>
  requires nviewable<A&&>&&nviewable<B&&>
void nswap_ranges(A&&a,B&&b){
  int n=nlen(a);
  npre(n==nlen(b));
  nrep(i,n)
    ranges::swap(a[i],b[i]);
}
template<class A,class F,class P=nidentity>
  requires nenumerable<A&&>
int nfind_if(A&&a,F f,P p={},int miss=npos){
  nfori(i,x,forward<A>(a)){
    if(invoke(f,invoke(p,x)))
      return i;
  }
  return miss;
}
template<class A,class X,class P=nidentity>
  requires nenumerable<A&&>
bool ncontains(A&&a,const X&x,P p={}){
  nfor(y,forward<A>(a)){
    if(invoke(p,y)==x)
      return true;
  }
  return false;
}
template<class A,class X,class P=nidentity>
  requires nenumerable<A&&>
int ncount(A&&a,const X&x,P p={}){
  int z=0;
  nfor(y,forward<A>(a)){
    z+=invoke(p,y)==x;
  }
  return z;
}
template<class A,class F,class P=nidentity>
  requires nenumerable<A&&>
int ncount_if(A&&a,F f,P p={}){
  int z=0;
  nfor(x,forward<A>(a)){
    z+=bool(invoke(f,invoke(p,x)));
  }
  return z;
}
template<class A,class F,class P=nidentity>
  requires nenumerable<A&&>
bool nall_of(A&&a,F f,P p={}){
  nfor(x,forward<A>(a)){
    if(!invoke(f,invoke(p,x)))
      return false;
  }
  return true;
}
template<class A,class F,class P=nidentity>
  requires nenumerable<A&&>
bool nany_of(A&&a,F f,P p={}){
  nfor(x,forward<A>(a)){
    if(invoke(f,invoke(p,x)))
      return true;
  }
  return false;
}
template<class A,class F,class P=nidentity>
  requires nenumerable<A&&>
bool nnone_of(A&&a,F f,P p={}){
  return!nany_of(forward<A>(a),move(f),move(p));
}
template<class A,class B,class E=nequal<>,class PA=nidentity,class PB=nidentity>
  requires nenumerable<A&&>&&nenumerable<B&&>
bool nsame(A&&a,B&&b,E e={},PA p={},PB q={}){
  auto x=nenumerate(forward<A>(a)),y=nenumerate(forward<B>(b));
  while(x.ok()&&y.ok()){
    if(!invoke(e,invoke(p,x.val()),invoke(q,y.val())))
      return false;
    x.next();
    y.next();
  }
  return!x.ok()&&!y.ok();
}
template<class A,class C=nless<>,class P=nidentity>
  requires nindexed<A>
int nargmin(const A&a,C c={},P p={}){
  if(!nlen(a))
    return npos;
  int z=0;
  for(int i=1;i<nlen(a);++i)
    if(invoke(c,invoke(p,a[i]),invoke(p,a[z])))
      z=i;
  return z;
}
template<class A,class C=nless<>,class P=nidentity>
  requires nindexed<A>
int nargmax(const A&a,C c={},P p={}){
  if(!nlen(a))
    return npos;
  int z=0;
  for(int i=1;i<nlen(a);++i)
    if(invoke(c,invoke(p,a[z]),invoke(p,a[i])))
      z=i;
  return z;
}
template<class A,class C=nless<>,class P=nidentity>
  requires nviewable<A&&>
void nsort(A&&a,C c={},P p={}){
  int n=nlen(a);
  if(n<2)
    return;
  ni::projected_compare<C,P>q{move(c),move(p)};
  if constexpr(ncontiguous_indexed<rmref<A>>)
    sort(a.data(),a.data()+n,move(q));
  else
    ni::nheap_sort(a,q);
}
template<class A>
  requires nviewable<A&&>
void nreverse_inplace(A&&a,int l=0,int r=npos){
  if(r==npos)
    r=nlen(a);
  npre(0<=l&&l<=r&&r<=nlen(a));
  while(l<--r)
    ranges::swap(a[l++],a[r]);
}
template<class A,class X,class P>
  requires nindexed<A>
int nfind(const A&a,const X&x,P p,int miss=npos){
  nrep(i,nlen(a))
    if(invoke(p,a[i])==x)
      return i;
  return miss;
}
template<class A,class X>
  requires nindexed<A>
int nfind(const A&a,const X&x,int miss=npos){
  return nfind(a,x,nidentity{},miss);
}
template<class A,class X,class C=nless<>,class P=nidentity>
  requires nindexed<A>
int nlower(const A&a,const X&x,C c={},P p={}){
  int l=0,r=nlen(a);
  while(l<r){
    int m=(l+r)>>1;
    if(invoke(c,invoke(p,a[m]),x))
      l=m+1;
    else
      r=m;
  }
  return l;
}
template<class A,class X,class C=nless<>,class P=nidentity>
  requires nindexed<A>
int nupper(const A&a,const X&x,C c={},P p={}){
  int l=0,r=nlen(a);
  while(l<r){
    int m=(l+r)>>1;
    if(invoke(c,x,invoke(p,a[m])))
      r=m;
    else
      l=m+1;
  }
  return l;
}
template<class A,class X,class C=nless<>,class P=nidentity>
  requires nindexed<A>
int nfind_sorted(const A&a,const X&x,C c={},P p={},int miss=npos){
  int i=nlower(a,x,c,p);
  if(i==nlen(a))
    return miss;
  auto&&y=invoke(p,a[i]);
  return!invoke(c,x,y)&&!invoke(c,y,x)?i:miss;
}
template<class A,class X,class C>
  requires nindexed<A>
int nfind_sorted(const A&a,const X&x,C c,int miss){
  return nfind_sorted(a,x,move(c),nidentity{},miss);
}
template<class A,class P=nidentity,class O=nadd<ni::projected_value_t<const A,P>>>
  requires nindexed<A>&&nmonoid<O,ni::projected_value_t<const A,P>>
auto nfold(const A&a,int l,int r,O op={},P p={}){
  using T=ni::projected_value_t<const A,P>;
  npre(0<=l&&l<=r&&r<=nlen(a));
  T z=op.id();
  for(int i=l;i<r;++i)
    z=op(move(z),invoke(p,a[i]));
  return z;
}
template<class A,class P=nidentity,class O=nadd<ni::projected_value_t<const A,P>>>
  requires nindexed<A>&&nmonoid<O,ni::projected_value_t<const A,P>>
auto nfold(const A&a,O op={},P p={}){
  return nfold(a,0,nlen(a),move(op),move(p));
}
template<class A,class E=nequal<>,class P=nidentity>
  requires nviewable<A&&>
int nunique_compact(A&&a,E e={},P p={}){
  if(!nlen(a))
    return 0;
  int k=1;
  for(int i=1;i<nlen(a);++i)
    if(!invoke(e,invoke(p,a[k-1]),invoke(p,a[i]))){
      if(k!=i)
        a[k]=move(a[i]);
      ++k;
    }
  return k;
}
template<class A,class E=nequal<>,class P=nidentity>
  requires nviewable<A&&>&&nresizable<rmref<A>>
int nunique(A&&a,E e={},P p={}){
  int k=nunique_compact(a,move(e),move(p));
  a.resize(k);
  return k;
}
template<class A,class C=nless<>,class E=nequal<>,class P=nidentity>
  requires nviewable<A&&>&&nresizable<rmref<A>>
int nsort_unique(A&&a,C c={},E e={},P p={}){
  nsort(a,c,p);
  return nunique(a,move(e),move(p));
}

// 20_mechanism
template<class A,class O=nadd<nvalue_t<const A>>>
  requires nmonoid<O,nvalue_t<const A>>
auto nscan(const A&a,O op={}){
  using T=nvalue_t<const A>;
  npre(nlen(a)<INT_MAX);
  nvector<T>result;
  result.reserve(nlen(a)+1);
  result.push(op.id());
  for(int i=0;i<nlen(a);++i)
    result.push(op(result.back(),a[i]));
  return result;
}

template<class A,class O=nadd<nvalue_t<const A>>>
  requires nmonoid<O,nvalue_t<const A>>
auto nsuffix_scan(const A&a,O op={}){
  using T=nvalue_t<const A>;
  npre(nlen(a)<INT_MAX);
  nvector<T>reversed;
  reversed.reserve(nlen(a)+1);
  reversed.push(op.id());
  for(int i=nlen(a);i-->0;)
    reversed.push(op(a[i],reversed.back()));
  nreverse_inplace(reversed);
  return reversed;
}

template<sint I,class P>constexpr I nfirst_true(I first,I last,P predicate){
  npre(first<=last);
  while(first<last){
    I middle=midpoint(first,last);
    if(predicate(middle))
      last=middle;
    else
      first=middle+1;
  }
  return first;
}

template<sint I,class P>constexpr I nlast_true(I first,I last,P predicate){
  npre(first<=last&&first>limits<I>::lowest());
  while(first<last){
    I middle=midpoint(first,last);
    if(predicate(middle))
      first=middle+1;
    else
      last=middle;
  }
  return first-1;
}

template<class T>class nrollback{
  struct change{
    T*target;
    T old_value;
  };
  vector<change>history_;

public:
  int time()const noexcept{
    npre(history_.size()<=size_t(INT_MAX));
    return int(history_.size());
  }
  bool empty()const noexcept{return history_.empty();}
  void reserve(int n){
    npre(n>=0);
    history_.reserve(size_t(n));
  }
  void save(T&target){
    npre(history_.size()<size_t(INT_MAX));
    history_.push_back({addressof(target),target});
  }
  void assign(T&target,T value){
    npre(history_.size()<size_t(INT_MAX));
    history_.push_back({addressof(target),move(target)});
    target=move(value);
  }
  template<class F>decltype(auto)mutate(T&target,F&&mutation){
    save(target);
    return invoke(forward<F>(mutation),target);
  }
  void undo(){
    npre(!history_.empty());
    auto change=move(history_.back());
    history_.pop_back();
    *change.target=move(change.old_value);
  }
  void rollback(int checkpoint){
    npre(0<=checkpoint&&checkpoint<=time());
    while(time()>checkpoint)
      undo();
  }
  void clear()noexcept{history_.clear();}
};

// 21_memory
template<class T>class nscratch{
  nvector<T>storage_;

public:
  int cap()const noexcept{return storage_.cap();}
  void reserve(int n){storage_.reserve(n);}

  // Any view returned by a previous call may be invalidated by the next resize.
  nview<T>space(int n){
    storage_.resize(n);
    return{storage_.data(),n};
  }
  nview<T>filled(int n,const T&value=T{}){
    auto result=space(n);
    for(int i=0;i<n;++i)
      result[i]=value;
    return result;
  }
};

template<class T>class narena{
  nvector<T>storage_;

public:
  int len()const noexcept{return storage_.len();}
  bool empty()const noexcept{return storage_.empty();}
  void reserve(int n){storage_.reserve(n);}
  int mark()const noexcept{return len();}

  template<class... A>int make(A&&...arguments){
    npre(len()<INT_MAX);
    int handle=len();
    storage_.push(forward<A>(arguments)...);
    return handle;
  }
  T&operator[](int handle){return storage_[handle];}
  const T&operator[](int handle)const{return storage_[handle];}
  T*get(int handle)noexcept{return storage_.get(handle);}
  const T*get(int handle)const noexcept{return storage_.get(handle);}

  void rollback(int checkpoint){
    npre(0<=checkpoint&&checkpoint<=len());
    while(len()>checkpoint)
      storage_.pop();
  }
  void clear()noexcept{storage_.clear();}
};

template<class T>class npool_dynamic{
  vector<optional<T>>storage_;
  vector<int>free_;
  int live_=0;

public:
  int len()const noexcept{return live_;}
  int cap()const noexcept{
    npre(storage_.size()<=size_t(INT_MAX));
    return int(storage_.size());
  }
  bool empty()const noexcept{return live_==0;}
  void reserve(int capacity){
    npre(capacity>=0);
    storage_.reserve(size_t(capacity));
    free_.reserve(size_t(capacity));
  }

  template<class... A>int make(A&&...arguments){
    int handle;
    if(free_.empty()){
      npre(storage_.size()<size_t(INT_MAX));
      storage_.emplace_back(in_place,forward<A>(arguments)...);
      handle=int(storage_.size());
    }else{
      handle=free_.back();
      free_.pop_back();
      storage_[handle-1].emplace(forward<A>(arguments)...);
    }
    ++live_;
    return handle;
  }
  void del(int handle){
    npre(get(handle)!=nullptr);
    storage_[handle-1].reset();
    free_.push_back(handle);
    --live_;
  }
  T&operator[](int handle){
    T*value=get(handle);
    npre(value!=nullptr);
    return*value;
  }
  const T&operator[](int handle)const{
    const T*value=get(handle);
    npre(value!=nullptr);
    return*value;
  }
  T*get(int handle)noexcept{
    return 0<handle&&handle<=cap()&&storage_[handle-1]?addressof(*storage_[handle-1]):nullptr;
  }
  const T*get(int handle)const noexcept{
    return 0<handle&&handle<=cap()&&storage_[handle-1]?addressof(*storage_[handle-1]):nullptr;
  }
  void clear()noexcept{
    storage_.clear();
    free_.clear();
    live_=0;
  }
};

template<class T>using npool=npool_dynamic<T>;

// 22_finite
class npartition{
  nvector<int>classes_;
  int count_=0;

public:
  npartition()=default;
  explicit npartition(nvector<int>labels):classes_(move(labels)){
    unordered_map<int,int>dense;
    dense.reserve(size_t(classes_.len()));
    for(int i=0;i<classes_.len();++i){
      auto[position,inserted]=dense.emplace(classes_[i],count_);
      if(inserted)
        ++count_;
      classes_[i]=position->second;
    }
  }

  int len()const noexcept{return classes_.len();}
  int classes()const noexcept{return count_;}
  bool empty()const noexcept{return classes_.empty();}

  int classof(int element,int fallback=npos)const{
    return 0<=element&&element<len()?classes_[element]:fallback;
  }
  int operator[](int element)const{
    npre(0<=element&&element<len());
    return classes_[element];
  }
  bool same(int a,int b)const{
    npre(0<=a&&a<len()&&0<=b&&b<len());
    return classes_[a]==classes_[b];
  }

  nvector<nvector<int>>groups()const{
    nvector<nvector<int>>result(count_);
    for(int element=0;element<len();++element)
      result[classes_[element]].push(element);
    return result;
  }

  friend bool operator==(const npartition&,const npartition&)=default;
};

using npart=npartition;
using npart_dense=npartition;

class nperm{
  nvector<int>image_;

  void validate()const{
    nvector<unsigned char>seen(len());
    for(int i=0;i<len();++i){
      npre(0<=image_[i]&&image_[i]<len());
      npre(!seen[image_[i]]);
      seen[image_[i]]=1;
    }
  }

public:
  nperm()=default;
  explicit nperm(int n):image_(n){
    for(int i=0;i<n;++i)
      image_[i]=i;
  }
  explicit nperm(nvector<int>image):image_(move(image)){validate();}
  nperm(initializer_list<int>image):image_(image){validate();}

  int len()const noexcept{return image_.len();}
  bool empty()const noexcept{return image_.empty();}
  int operator()(int value)const{
    npre(0<=value&&value<len());
    return image_[value];
  }
  int operator[](int value)const{return(*this)(value);}

  nperm inverse()const{
    nvector<int>result(len());
    for(int i=0;i<len();++i)
      result[image_[i]]=i;
    return nperm(move(result));
  }
  friend nperm operator~(const nperm&permutation){return permutation.inverse();}

  // Composition follows function notation: (f*g)(x) = f(g(x)).
  friend nperm operator*(const nperm&f,const nperm&g){
    npre(f.len()==g.len());
    nvector<int>result(f.len());
    for(int i=0;i<f.len();++i)
      result[i]=f(g(i));
    return nperm(move(result));
  }

  nperm pow(int64_t exponent)const{
    nperm base=exponent<0?inverse():*this;
    uint64_t remaining=exponent<0?uint64_t{}-uint64_t(exponent):uint64_t(exponent);
    nperm result(len());
    while(remaining){
      if(remaining&1)
        result=base*result;
      remaining>>=1;
      if(remaining)
        base=base*base;
    }
    return result;
  }

  npartition cycles()const{
    nvector<int>labels(len(),npos);
    int label=0;
    for(int first=0;first<len();++first)
      if(labels[first]==npos){
        for(int value=first;labels[value]==npos;value=image_[value])
          labels[value]=label;
        ++label;
      }
    return npartition(move(labels));
  }

  template<nindexed A>auto pull(const A&source)const{
    using T=nvalue_t<const A>;
    npre(nlen(source)==len());
    nvector<T>result(len());
    for(int i=0;i<len();++i)
      result[i]=source[image_[i]];
    return result;
  }
  template<nindexed A>auto push(const A&source)const{
    using T=nvalue_t<const A>;
    npre(nlen(source)==len());
    nvector<T>result(len());
    for(int i=0;i<len();++i)
      result[image_[i]]=source[i];
    return result;
  }

  friend bool operator==(const nperm&,const nperm&)=default;
};

// 23_ordered
namespace ni{
template<class S>bool ord_eq(const S&a,const S&b){
  if(a.len()!=b.len())
    return false;
  auto x=a.enumerate(),y=b.enumerate();
  while(x.ok()){
    if(!a.equivalent(x.val(),y.val()))
      return false;
    x.next();
    y.next();
  }
  return true;
}

template<class D,class V,bool Enabled=true>struct setop{
  D&self(){return static_cast<D&>(*this);}
  const D&self()const{return static_cast<const D&>(*this);}
  D&operator|=(const D&b)
    requires Enabled
  {
    if(&self()!=&b)
      nfor(x,b)
        self().nset_add(x);
    return self();
  }
  D&operator&=(const D&b)
    requires Enabled
  {
    if(&self()==&b)
      return self();
    nvector<V>removed;
    nfor(x,self()){
      if(!b.nset_has(x))
        removed.push(x);
    }
    nfor(x,removed)
      self().nset_del(x);
    return self();
  }
  D&operator-=(const D&b)
    requires Enabled
  {
    if(&self()==&b)
      self().clear();
    else
      nfor(x,b)
        self().nset_del(x);
    return self();
  }
  D&operator^=(const D&b)
    requires Enabled
  {
    if(&self()==&b)
      self().clear();
    else{
      nfor(x,b){
        if(self().nset_has(x))
          self().nset_del(x);
        else
          self().nset_add(x);
      }
    }
    return self();
  }
  friend D operator|(D a,const D&b)
    requires Enabled
  {
    return a|=b;
  }
  friend D operator&(D a,const D&b)
    requires Enabled
  {
    return a&=b;
  }
  friend D operator-(D a,const D&b)
    requires Enabled
  {
    return a-=b;
  }
  friend D operator^(D a,const D&b)
    requires Enabled
  {
    return a^=b;
  }
};

template<class D,class T,bool Algebra>struct set_api:public setop<D,T,Algebra>{
  D&self(){return static_cast<D&>(*this);}
  const D&self()const{return static_cast<const D&>(*this);}
  T kth(int i,T fallback)const{
    auto x=self().kth(i);
    return x?x.val():move(fallback);
  }
  T lower(const T&v,T fallback)const{
    auto x=self().lower(v);
    return x?x.val():move(fallback);
  }
  T upper(const T&v,T fallback)const{
    auto x=self().upper(v);
    return x?x.val():move(fallback);
  }
  nmaybe<T>min()const{return self().kth(0);}
  nmaybe<T>max()const{return self().kth(self().len()-1);}
  T min(T fallback)const{return kth(0,move(fallback));}
  T max(T fallback)const{return kth(self().len()-1,move(fallback));}
};

template<class T,class C,bool Multi,class A,bool TouchFind>
  requires naugment<A,T>
class ord:public set_api<ord<T,C,Multi,A,TouchFind>,T,!Multi>{
  struct node{
    T v;
    uint64_t p;
    int l=0,r=0,sz=1,cnt=1;
    typename A::info_type info;
    node(T v,uint64_t p,int cnt,typename A::info_type info)
        :v(move(v)),p(p),sz(cnt),cnt(cnt),info(move(info)){}
  };
  mutable npool<node>pool;
  mutable int rt=0;
  [[no_unique_address]]C cmp{};
  [[no_unique_address]]A aug{};
  mutable uint64_t epoch=1;
  void touch()const{
    if(!++epoch)
      ++epoch;
  }
  int size(int x)const{return x?pool[x].sz:0;}
  typename A::info_type info(int x)const{return x?pool[x].info:aug.id();}
  void pull(int x)const{
    if(!x)
      return;
    auto&q=pool[x];
    long long z=1LL*size(q.l)+q.cnt+size(q.r);
    npre(z<=INT_MAX);
    q.sz=int(z);
    q.info=aug.op(aug.op(info(q.l),aug.one(q.v,q.cnt)),info(q.r));
  }
  int merge(int x,int y){
    if(!x||!y)
      return x|y;
    if(pool[x].p>=pool[y].p){
      pool[x].r=merge(pool[x].r,y);
      pull(x);
      return x;
    }
    pool[y].l=merge(x,pool[y].l);
    pull(y);
    return y;
  }
  void split(int x,const T&v,int&l,int&r){
    if(!x){
      l=r=0;
      return;
    }
    if(invoke(cmp,pool[x].v,v)){
      l=x;
      split(pool[x].r,v,pool[l].r,r);
      pull(l);
    }else{
      r=x;
      split(pool[x].l,v,l,pool[r].l);
      pull(r);
    }
  }
  int&child(int x,bool right)const{
    return right?pool[x].r:pool[x].l;
  }
  int rotate(int x,bool right)const{
    int y=child(x,right);
    child(x,right)=child(y,!right);
    child(y,!right)=x;
    pull(x);
    pull(y);
    return y;
  }
  int splay(int x,const T&v)const{
    if(!x||equivalent(v,pool[x].v))
      return x;
    bool right=invoke(cmp,pool[x].v,v);
    int y=child(x,right);
    if(!y)
      return x;
    bool same=right?invoke(cmp,pool[y].v,v):invoke(cmp,v,pool[y].v);
    bool cross=right?invoke(cmp,v,pool[y].v):invoke(cmp,pool[y].v,v);
    if(same){
      child(y,right)=splay(child(y,right),v);
      child(x,right)=y;
      x=rotate(x,right);
    }else if(cross){
      child(y,!right)=splay(child(y,!right),v);
      if(child(y,!right))
        child(x,right)=rotate(y,!right);
    }
    if(!child(x,right)){
      pull(x);
      return x;
    }
    return rotate(x,right);
  }
  int find(const T&v)const{
    if constexpr(TouchFind){
      if(!rt)
        return 0;
      rt=splay(rt,v);
      // Splay queries invalidate every old nnode view.
      touch();
      return equivalent(v,pool[rt].v)?rt:0;
    }
    int x=rt;
    while(x&&!equivalent(v,pool[x].v))
      x=invoke(cmp,v,pool[x].v)?pool[x].l:pool[x].r;
    return x;
  }
  int add(int x,const T&v,int c){
    if(!x)
      return-1;
    auto&q=pool[x];
    if(equivalent(v,q.v)){
      if constexpr(Multi){
        npre(q.cnt<=INT_MAX-c);
        q.cnt+=c;
        pull(x);
        return c;
      }
      return 0;
    }
    int z=add(invoke(cmp,v,q.v)?q.l:q.r,v,c);
    if(z>=0)
      pull(x);
    return z;
  }
  int erase(int&x,const T&v,int c,bool all){
    if(!x)
      return 0;
    auto&q=pool[x];
    if(equivalent(v,q.v)){
      if constexpr(Multi)
        if(!all&&q.cnt>c){
          q.cnt-=c;
          pull(x);
          return c;
        }
      int z=Multi?q.cnt:1,old=x;
      x=merge(q.l,q.r);
      pool.del(old);
      return z;
    }
    int z=erase(invoke(cmp,v,q.v)?q.l:q.r,v,c,all);
    pull(x);
    return z;
  }
  int sins(T&&v,int c){
    int k=Multi?c:1;
    if(!rt){
      auto info=aug.one(v,k);
      rt=pool.make(move(v),uint64_t(0),k,move(info));
      touch();
      return k;
    }
    rt=splay(rt,v);
    if(equivalent(v,pool[rt].v)){
      if constexpr(Multi){
        npre(pool[rt].cnt<=INT_MAX-c);
        pool[rt].cnt+=c;
        pull(rt);
        touch();
        return c;
      }
      touch();
      return 0;
    }
    auto info=aug.one(v,k);
    int old=rt,z=pool.make(move(v),uint64_t(0),k,move(info));
    bool right=invoke(cmp,pool[old].v,pool[z].v);
    child(z,right)=child(old,right);
    child(z,!right)=old;
    child(old,right)=0;
    pull(old);
    pull(z);
    rt=z;
    touch();
    return k;
  }
  int sdel(const T&v,int c,bool all){
    if(!rt)
      return 0;
    rt=splay(rt,v);
    if(!equivalent(v,pool[rt].v)){
      touch();
      return 0;
    }
    auto&q=pool[rt];
    if constexpr(Multi)
      if(!all&&q.cnt>c){
        q.cnt-=c;
        pull(rt);
        touch();
        return c;
      }
    int removed=Multi?q.cnt:1;
    int old=rt,l=q.l,r=q.r;
    pool.del(old);
    if(!l)
      rt=r;
    else{
      rt=splay(l,v);
      pool[rt].r=r;
      pull(rt);
    }
    touch();
    return removed;
  }
  friend class::nnode<ord>;
  uint64_t nnode_epoch()const{return epoch;}
  bool nnode_alive(int x)const{return pool.get(x);}
  const T&nnode_val(int x)const{return pool[x].v;}
  int nnode_count(int x)const{return x?pool[x].cnt:0;}
  int nnode_len(int x)const{return size(x);}
  typename A::info_type nnode_info(int x)const{return info(x);}
  int nnode_left(int x)const{return x?pool[x].l:0;}
  int nnode_right(int x)const{return x?pool[x].r:0;}
  friend struct setop<ord,T,!Multi>;
  bool nset_has(const T&x)const{return has(x);}
  void nset_add(const T&x){ins(x);}
  void nset_del(const T&x){del(x);}

public:
  using value_type=T;
  using api=set_api<ord,T,!Multi>;
  using api::kth;
  using api::lower;
  using api::max;
  using api::min;
  using api::upper;
  using augment_type=A;
  using info_type=typename A::info_type;
  using node_view=::nnode<ord>;
  ord()=default;
  explicit ord(C c):cmp(move(c)){}
  explicit ord(A a)
    requires(!same_as<C,A>)
      :aug(move(a)){}
  ord(C c,A a):cmp(move(c)),aug(move(a)){}
  ord(initializer_list<T>a){
    for(const T&x:a)
      ins(x);
  }
  ord(const ord&o):pool(o.pool),rt(o.rt),cmp(o.cmp),aug(o.aug){}
  ord(ord&&o)noexcept:pool(move(o.pool)),rt(exchange(o.rt,0)),cmp(move(o.cmp)),aug(move(o.aug)){
    o.touch();
  }
  ord&operator=(const ord&o){
    if(this!=&o){
      pool=o.pool;
      rt=o.rt;
      cmp=o.cmp;
      aug=o.aug;
      touch();
    }
    return*this;
  }
  ord&operator=(ord&&o)noexcept{
    if(this!=&o){
      pool=move(o.pool);
      rt=exchange(o.rt,0);
      cmp=move(o.cmp);
      aug=move(o.aug);
      touch();
      o.touch();
    }
    return*this;
  }
  int len()const{return size(rt);}
  bool empty()const{return!rt;}
  bool equivalent(const T&a,const T&b)const{return!invoke(cmp,a,b)&&!invoke(cmp,b,a);}
  const A&augment()const{return aug;}
  node_view root()const{return{this,rt,epoch};}
  template<class F>node_view walk(F&&f)const{return nwalk(*this,forward<F>(f));}
  template<class P>node_view first_prefix(P&&p)const{return nfirst_prefix(*this,forward<P>(p));}
  template<class P>node_view last_suffix(P&&p)const{return nlast_suffix(*this,forward<P>(p));}
  void reserve(int n){pool.reserve(n);}
  void clear(){
    if(rt)
      touch();
    pool.clear();
    rt=0;
  }
  int ins(const T&v,int c=1){
    T x=v;
    return ins(move(x),c);
  }
  int ins(T&&v,int c=1){
    npre(c>=0);
    if(!c)
      return 0;
    npre(len()<=INT_MAX-(Multi?c:1));
    if constexpr(TouchFind)
      return sins(move(v),c);
    int z=add(rt,v,c);
    if(z>=0){
      if(z)
        touch();
      return z;
    }
    int l,r,k=Multi?c:1;
    split(rt,v,l,r);
    auto info=aug.one(v,k);
    int x=pool.make(move(v),nrng_global(),k,move(info));
    rt=merge(merge(l,x),r);
    touch();
    return k;
  }
  int del(const T&v,int c=1){
    npre(c>=0);
    if constexpr(TouchFind)
      return c?sdel(v,c,false):0;
    int z=c?erase(rt,v,c,false):0;
    if(z)
      touch();
    return z;
  }
  int delall(const T&v){
    if constexpr(TouchFind)
      return sdel(v,0,true);
    int z=erase(rt,v,0,true);
    if(z)
      touch();
    return z;
  }
  bool has(const T&v)const{return find(v);}
  int count(const T&v)const{
    int x=find(v);
    return x?pool[x].cnt:0;
  }
  const T*get(const T&v)const{
    int x=find(v);
    return x?addressof(pool[x].v):nullptr;
  }
  int rank(const T&v)const{
    if constexpr(TouchFind)
      if(rt){
        rt=splay(rt,v);
        touch();
      }
    int ans=0;
    for(int x=rt;x;){
      auto&q=pool[x];
      if(invoke(cmp,q.v,v)){
        ans+=size(q.l)+q.cnt;
        x=q.r;
      }else{
        if(equivalent(v,q.v)){
          ans+=size(q.l);
          break;
        }
        x=q.l;
      }
    }
    return ans;
  }
  nmaybe<T>kth(int k)const{
    if(k<0||k>=len())
      return{};
    for(int x=rt;;){
      auto&q=pool[x];
      int s=size(q.l);
      if(k<s)
        x=q.l;
      else if(k<s+q.cnt){
        if constexpr(TouchFind){
          rt=splay(rt,q.v);
          touch();
        }
        return q.v;
      }else{
        k-=s+q.cnt;
        x=q.r;
      }
    }
  }
  nmaybe<T>bound(const T&v,bool strict)const{
    int ans=0,last=0;
    for(int x=rt;x;){
      last=x;
      auto&q=pool[x];
      bool take=strict?invoke(cmp,v,q.v):!invoke(cmp,q.v,v);
      if(take){
        ans=x;
        x=q.l;
      }else
        x=q.r;
    }
    if constexpr(TouchFind){
      int target=ans?ans:last;
      if(target){
        rt=splay(rt,pool[target].v);
        touch();
      }
    }
    return ans?nmaybe<T>(pool[ans].v):nmaybe<T>{};
  }
  nmaybe<T>lower(const T&v)const{return bound(v,false);}
  nmaybe<T>upper(const T&v)const{return bound(v,true);}
  struct cursor{
    const ord*s;
    vector<int>st;
    int rep=0,i=0;
    explicit cursor(const ord*s):s(s){down(s->rt);}
    void down(int x){
      while(x){
        st.push_back(x);
        x=s->pool[x].l;
      }
    }
    bool ok()const{return!st.empty();}
    const T&val()const{return s->pool[st.back()].v;}
    int idx()const{return i;}
    void next(){
      int x=st.back();
      ++i;
      if(++rep<s->pool[x].cnt)
        return;
      rep=0;
      st.pop_back();
      down(s->pool[x].r);
    }
  };
  cursor enumerate()const&{return cursor(this);}
  cursor enumerate()&&=delete;
  friend bool operator==(const ord&a,const ord&b){return ord_eq(a,b);}
};
}// namespace ni

template<class T,class C=nless<T>,bool Multi=false,class A=nempty_augment<T>>
using nset_fhq=ni::ord<T,C,Multi,A,false>;
template<class T,class C=nless<T>,bool Multi=false,class A=nempty_augment<T>>
using nset_splay=ni::ord<T,C,Multi,A,true>;

template<class T,class C=nless<T>>class nset_stl:
    public set<T,C>,public ni::set_api<nset_stl<T,C>,T,true>{
  using B=set<T,C>;
  friend struct ni::setop<nset_stl,T,true>;
  bool nset_has(const T&x)const{return has(x);}
  void nset_add(const T&x){ins(x);}
  void nset_del(const T&x){del(x);}

public:
  using value_type=T;
  using api=ni::set_api<nset_stl,T,true>;
  using api::kth;
  using api::lower;
  using api::max;
  using api::min;
  using api::upper;

  using B::B;
  nset_stl()=default;

  int len()const{
    npre(B::size()<=size_t(INT_MAX));
    return int(B::size());
  }
  bool empty()const noexcept{return B::empty();}
  bool equivalent(const T&a,const T&b)const{
    auto compare=B::key_comp();
    return!invoke(compare,a,b)&&!invoke(compare,b,a);
  }
  void clear()noexcept{B::clear();}
  void reserve(int capacity){npre(capacity>=0);}
  int ins(const T&value,int count=1){
    npre(count>=0);
    return count?int(B::insert(value).second):0;
  }
  int ins(T&&value,int count=1){
    npre(count>=0);
    return count?int(B::insert(move(value)).second):0;
  }
  int del(const T&value,int count=1){
    npre(count>=0);
    return count?int(B::erase(value)):0;
  }
  int delall(const T&value){return del(value);}
  bool has(const T&value)const{return B::contains(value);}
  int count(const T&value)const{return int(B::contains(value));}
  const T*get(const T&value)const{
    auto found=B::find(value);
    return found==B::end()?nullptr:addressof(*found);
  }
  int rank(const T&value)const{return int(distance(B::begin(),B::lower_bound(value)));}
  nmaybe<T>kth(int index)const{
    if(index<0||index>=len())
      return{};
    auto found=B::begin();
    advance(found,index);
    return*found;
  }
  nmaybe<T>lower(const T&value)const{
    auto found=B::lower_bound(value);
    return found==B::end()?nmaybe<T>{}:nmaybe<T>(*found);
  }
  nmaybe<T>upper(const T&value)const{
    auto found=B::upper_bound(value);
    return found==B::end()?nmaybe<T>{}:nmaybe<T>(*found);
  }

  struct cursor{
    const nset_stl*owner;
    typename set<T,C>::const_iterator iterator;
    int index=0;
    bool ok()const{return iterator!=owner->B::end();}
    const T&val()const{return*iterator;}
    int idx()const{return index;}
    void next(){
      ++iterator;
      ++index;
    }
  };
  cursor enumerate()const&{return{this,B::begin()};}
  cursor enumerate()&&=delete;

  friend bool operator==(const nset_stl&left,const nset_stl&right){return ni::ord_eq(left,right);}
};

template<class T,class C=nless<T>,class A=nempty_augment<T>>using nset=nset_fhq<T,C,false,A>;

template<class T,class C=nless<T>,class A=nempty_augment<T>>using nbag=nset_fhq<T,C,true,A>;

// 24_map
namespace ni{
template<class K,class V,class H,class E>class maptab{
  struct node{
    K key;
    V val;
    size_t hash;
  };
  vector<node>a;
  vector<int>bucket;
  int dead=0;
  [[no_unique_address]]H hash{};
  [[no_unique_address]]E eq{};
  int cap()const{return int(bucket.size());}
  static int capacity(uint64_t n){
    n=max<uint64_t>(8,n);
    npre(n<=1u<<30);
    return int(bit_ceil(uint32_t(n)));
  }
  pair<int,bool>slot(const K&key,size_t h)const{
    if(!cap())
      return{0,false};
    int mask=cap()-1,i=int(h&mask),hole=npos;
    for(int z=0;z<cap();++z,i=(i+1)&mask){
      int x=bucket[i];
      if(!x)
        return{hole==npos?i:hole,false};
      if(x<0){
        if(hole==npos)
          hole=i;
        continue;
      }
      const auto&q=a[x-1];
      if(q.hash==h&&invoke(eq,q.key,key))
        return{i,true};
    }
    npre(hole!=npos);
    return{hole,false};
  }
  void place(int k){
    int mask=cap()-1,i=int(a[k].hash&mask);
    while(bucket[i]>0)
      i=(i+1)&mask;
    bucket[i]=k+1;
  }
  void rehash(int n){
    bucket.assign(capacity(n),0);
    dead=0;
    for(int i=0;i<len();++i)
      place(i);
  }
  void grow(){
    if(!cap())
      return rehash(8);
    if((1LL*len()+dead+1)*10<=1LL*cap()*7)
      return;
    if(dead>len())
      rehash(cap());
    else{
      npre(cap()<=1<<29);
      rehash(cap()*2);
    }
  }
  template<class X,class Y>bool insert(X&&key,Y&&val){
    grow();
    size_t h=size_t(invoke(hash,key));
    auto[i,found]=slot(key,h);
    if(found)
      return false;
    npre(a.size()<size_t(INT_MAX));
    if(bucket[i]<0)
      --dead;
    a.push_back({forward<X>(key),forward<Y>(val),h});
    bucket[i]=len();
    return true;
  }

public:
  using key_type=K;
  using mapped_type=V;
  maptab()=default;
  explicit maptab(int n,H h={},E e={}):hash(move(h)),eq(move(e)){reserve(n);}
  int len()const{
    npre(a.size()<=size_t(INT_MAX));
    return int(a.size());
  }
  bool empty()const{return a.empty();}
  void clear(){
    a.clear();
    fill(bucket.begin(),bucket.end(),0);
    dead=0;
  }
  void reserve(int n){
    npre(n>=0);
    a.reserve(n);
    uint64_t need=(uint64_t(n)*10+6)/7;
    if(int(need)>cap())
      rehash(int(need));
  }
  V*get(const K&key){
    auto[i,f]=slot(key,size_t(invoke(hash,key)));
    return f?addressof(a[bucket[i]-1].val):nullptr;
  }
  const V*get(const K&key)const{
    auto[i,f]=slot(key,size_t(invoke(hash,key)));
    return f?addressof(a[bucket[i]-1].val):nullptr;
  }
  V get(const K&key,V fallback)const{
    auto p=get(key);
    return p?*p:move(fallback);
  }
  bool has(const K&key)const{return get(key);}
  bool ins(const K&key,const V&val){return insert(key,val);}
  bool ins(K&&key,V&&val){return insert(move(key),move(val));}
  template<class X>V&set(const K&key,X&&val){
    if(auto p=get(key)){
      *p=forward<X>(val);
      return*p;
    }
    insert(key,forward<X>(val));
    return a.back().val;
  }
  V&operator[](const K&key){
    if(auto p=get(key))
      return*p;
    insert(key,V{});
    return a.back().val;
  }
  V&operator[](K&&key){
    if(auto p=get(key))
      return*p;
    insert(move(key),V{});
    return a.back().val;
  }
  V&operator()(const K&key){
    auto p=get(key);
    npre(p);
    return*p;
  }
  const V&operator()(const K&key)const{
    auto p=get(key);
    npre(p);
    return*p;
  }
  int del(const K&key){
    if(!cap())
      return 0;
    auto[i,f]=slot(key,size_t(invoke(hash,key)));
    if(!f)
      return 0;
    int x=bucket[i]-1,last=len()-1;
    bucket[i]=-1;
    ++dead;
    if(x!=last){
      a[x]=move(a[last]);
      int mask=cap()-1,j=int(a[x].hash&mask);
      while(bucket[j]!=last+1)
        j=(j+1)&mask;
      bucket[j]=x+1;
    }
    a.pop_back();
    if(dead>len()&&cap()>8)
      rehash(cap());
    return 1;
  }
  template<bool Const>struct cur{
    using S=select_t<Const,const maptab,maptab>;
    S*s;
    int i=0;
    bool ok()const{return i<s->len();}
    const K&key()const{return s->a[i].key;}
    decltype(auto)val()const{return(s->a[i].val);}
    int idx()const{return i;}
    void next(){++i;}
  };
  cur<false>enumerate()&{return{this};}
  cur<true>enumerate()const&{return{this};}
  cur<false>enumerate()&&=delete;
  friend bool operator==(const maptab&x,const maptab&y){
    if(x.len()!=y.len())
      return false;
    for(auto&q:x.a){
      auto p=y.get(q.key);
      if(!p||!(*p==q.val))
        return false;
    }
    return true;
  }
};
}// namespace ni
template<class K,class V,class H=nhash<K>,class E=equal_to<K>>using nmap_hash=ni::maptab<K,V,H,E>;
template<class K,class V,class H=nhash<K>,class E=equal_to<K>>using nmap_flat=ni::maptab<K,V,H,E>;
template<class K,class V,class H=nhash<K>,class E=equal_to<K>>using nmap=ni::maptab<K,V,H,E>;

// 25_relation
template<class L,class R,class EL=nequal<>,class ER=nequal<>>
class nrel_scan:public ni::setop<nrel_scan<L,R,EL,ER>,pair<L,R>>{
  struct edge{
    L left;
    R right;
    edge(const L&l,const R&r):left(l),right(r){}
    edge(L&&l,R&&r):left(move(l)),right(move(r)){}
  };
  nvector<edge>a;
  [[no_unique_address]]EL eql{};
  [[no_unique_address]]ER eqr{};
  friend struct ni::setop<nrel_scan,pair<L,R>>;
  template<class E>bool nset_has(const E&e)const{return has(e.first,e.second);}
  template<class E>void nset_add(const E&e){add(e.first,e.second);}
  template<class E>void nset_del(const E&e){del(e.first,e.second);}

public:
  nrel_scan()=default;
  explicit nrel_scan(EL l,ER r={}):eql(move(l)),eqr(move(r)){}
  int len()const{return a.len();}
  bool empty()const{return a.empty();}
  void reserve(int n){a.reserve(n);}
  void clear(){a.clear();}
  bool equal_left(const L&x,const L&y)const{return invoke(eql,x,y);}
  bool equal_right(const R&x,const R&y)const{return invoke(eqr,x,y);}
  bool has(const L&l,const R&r)const{
    nrep(i,len()){
      auto&e=a[i];
      if(equal_left(e.left,l)&&equal_right(e.right,r))
        return true;
    }
    return false;
  }
  bool add(const L&l,const R&r){
    if(has(l,r))
      return false;
    a.push(l,r);
    return true;
  }
  bool add(L&&l,R&&r){
    if(has(l,r))
      return false;
    a.push(move(l),move(r));
    return true;
  }
  bool del(const L&l,const R&r){
    for(int i=0;i<len();++i)
      if(equal_left(a[i].left,l)&&equal_right(a[i].right,r)){
        a.swapdel(i);
        return true;
      }
    return false;
  }
  nvector<R>image(const L&l)const{
    nvector<R>z;
    nrep(i,len()){
      auto&e=a[i];
      if(equal_left(e.left,l))
        z.push(e.right);
    }
    return z;
  }
  nvector<L>preimage(const R&r)const{
    nvector<L>z;
    nrep(i,len()){
      auto&e=a[i];
      if(equal_right(e.right,r))
        z.push(e.left);
    }
    return z;
  }
  struct cursor{
    const nrel_scan*s;
    int i=0;
    bool ok()const{return i<s->len();}
    auto val()const{return pair<const L&,const R&>(s->a[i].left,s->a[i].right);}
    int idx()const{return i;}
    void next(){++i;}
  };
  cursor enumerate()const&{return{this};}
  cursor enumerate()&&=delete;
  friend bool operator==(const nrel_scan&x,const nrel_scan&y){
    if(x.len()!=y.len())
      return false;
    nrep(i,x.len()){
      auto&e=x.a[i];
      if(!y.has(e.left,e.right))
        return false;
    }
    return true;
  }
};
template<class L,class R,class EL=nequal<>,class ER=nequal<>>using nrel=nrel_scan<L,R,EL,ER>;

template<class A,class B,class HA=nhash<A>,class HB=nhash<B>,class EA=equal_to<A>,class EB=equal_to<B>>
class npartial_hash{
  nmap<A,B,HA,EA>f;
  [[no_unique_address]]EB eq{};

public:
  npartial_hash()=default;
  explicit npartial_hash(EB e):eq(move(e)){}
  int len()const{return f.len();}
  bool empty()const{return f.empty();}
  void reserve(int n){f.reserve(n);}
  void clear(){f.clear();}
  bool has(const A&a)const{return f.has(a);}
  B*to(const A&a){return f.get(a);}
  const B*to(const A&a)const{return f.get(a);}
  B to(const A&a,B x)const{return f.get(a,move(x));}
  bool bind(const A&a,const B&b){
    auto p=f.get(a);
    return p?invoke(eq,*p,b):f.ins(a,b);
  }
  template<class X>B&set(const A&a,X&&b){return f.set(a,forward<X>(b));}
  bool unbind(const A&a){return f.del(a);}
  B&operator()(const A&a){return f(a);}
  const B&operator()(const A&a)const{return f(a);}
  auto enumerate()&{return f.enumerate();}
  auto enumerate()const&{return f.enumerate();}
  auto enumerate()&&=delete;
  friend bool operator==(const npartial_hash&a,const npartial_hash&b){return a.f==b.f;}
};
template<class A,class B,class HA=nhash<A>,class HB=nhash<B>,class EA=equal_to<A>,class EB=equal_to<B>>
using nfunc_hash=npartial_hash<A,B,HA,HB,EA,EB>;
template<class A,class B,class HA=nhash<A>,class HB=nhash<B>,class EA=equal_to<A>,class EB=equal_to<B>>
using npartial=npartial_hash<A,B,HA,HB,EA,EB>;

template<class A,class B,class HA=nhash<A>,class HB=nhash<B>,class EA=equal_to<A>,class EB=equal_to<B>>
class nbije_hash{
  template<class,class,class,class,class,class>friend class nbije_hash;
  nmap<A,B,HA,EA>f;
  nmap<B,A,HB,EB>g;
  [[no_unique_address]]EA eqa{};
  [[no_unique_address]]EB eqb{};

public:
  int len()const{return f.len();}
  bool empty()const{return f.empty();}
  void reserve(int n){
    f.reserve(n);
    g.reserve(n);
  }
  void clear(){
    f.clear();
    g.clear();
  }
  bool hasl(const A&a)const{return f.has(a);}
  bool hasr(const B&b)const{return g.has(b);}
  const B*to(const A&a)const{return f.get(a);}
  const A*from(const B&b)const{return g.get(b);}
  B to(const A&a,B x)const{return f.get(a,move(x));}
  A from(const B&b,A x)const{return g.get(b,move(x));}
  const B&operator()(const A&a)const{return f(a);}
  bool bind(const A&a,const B&b){
    auto x=to(a);
    auto y=from(b);
    if(x||y)
      return x&&y&&invoke(eqb,*x,b)&&invoke(eqa,*y,a);
    npre(f.ins(a,b)&&g.ins(b,a));
    return true;
  }
  bool unbindl(const A&a){
    auto p=to(a);
    if(!p)
      return false;
    B b=*p;
    npre(f.del(a)&&g.del(b));
    return true;
  }
  bool unbindr(const B&b){
    auto p=from(b);
    if(!p)
      return false;
    A a=*p;
    npre(g.del(b)&&f.del(a));
    return true;
  }
  void set(const A&a,const B&b){
    unbindl(a);
    unbindr(b);
    npre(bind(a,b));
  }
  auto inverse()const{
    nbije_hash<B,A,HB,HA,EB,EA>z;
    z.f=g;
    z.g=f;
    z.eqa=eqb;
    z.eqb=eqa;
    return z;
  }
  auto operator~()const{return inverse();}
  auto enumerate()const&{return f.enumerate();}
  auto enumerate()&&=delete;
  template<class X,class HX,class EX>auto operator*(const nbije_hash<X,A,HX,HA,EX,EA>&h)const{
    nbije_hash<X,B,HX,HB,EX,EB>z;
    nforkv(x,a,h){
      if(auto b=to(a))
        z.bind(x,*b);
    }
    return z;
  }
  friend bool operator==(const nbije_hash&a,const nbije_hash&b){return a.f==b.f;}
};

template<class T,class C=nless<T>>class nbije_rank{
  nvector<T>a;
  [[no_unique_address]]C cmp{};
  bool eq(const T&x,const T&y)const{return!invoke(cmp,x,y)&&!invoke(cmp,y,x);}

public:
  nbije_rank()=default;
  template<class S>
    requires nenumerable<const S&>
  explicit nbije_rank(const S&s,C c={}):a(ncollect<T>(s)),cmp(move(c)){
    nsort(a,cmp);
    nunique(a,[this](const T&x,const T&y){return eq(x,y);});
  }
  int len()const{return a.len();}
  bool empty()const{return a.empty();}
  int to(const T&x)const{
    int i=nlower(a,x,cmp);
    return i<len()&&eq(x,a[i])?i:npos;
  }
  int to(const T&x,int f)const{
    int i=to(x);
    return i==npos?f:i;
  }
  bool hasl(const T&x)const{return to(x)!=npos;}
  bool hasr(int i)const{return i>=0&&i<len();}
  const T*from(int i)const{return a.get(i);}
  T from(int i,T f)const{return a.get(i,move(f));}
  const T&operator()(int i)const{
    npre(hasr(i));
    return a[i];
  }
  struct cursor{
    const nbije_rank*s;
    int i=0;
    bool ok()const{return i<s->len();}
    const T&key()const{return s->a[i];}
    int val()const{return i;}
    int idx()const{return i;}
    void next(){++i;}
  };
  cursor enumerate()const&{return{this};}
  cursor enumerate()&&=delete;
  auto inverse()const{
    nbije_hash<int,T>z;
    z.reserve(len());
    for(int i=0;i<len();++i)
      z.bind(i,a[i]);
    return z;
  }
  auto operator~()const{return inverse();}
};
template<class A,class C=nless<nvalue_t<const A>>>
  requires nenumerable<const A&>
auto ncompress(const A&a,C c={}){
  return nbije_rank<nvalue_t<const A>,C>(a,move(c));
}
template<class A,class C=nless<typename A::value_type>>auto ncompress_stl(const A&a,C c={}){
  nvector<typename A::value_type>v;
  for(auto&x:a)
    v.push(x);
  return nbije_rank<typename A::value_type,C>(v,move(c));
}
template<class A,class B,class HA=nhash<A>,class HB=nhash<B>,class EA=equal_to<A>,class EB=equal_to<B>>
using nbije=nbije_hash<A,B,HA,HB,EA,EB>;
template<class A,class B,class HA=nhash<A>,class HB=nhash<B>,class EA=equal_to<A>,class EB=equal_to<B>>
using ninj=nbije_hash<A,B,HA,HB,EA,EB>;

// 26_func_more
namespace ni{

template<class D,class K>
concept ndirect_domain_locator=requires(const D&domain,const K&key){
  {domain.position(key)}->convertible_to<int>;
};

template<class S>struct run_fn{
  S source;
  nvector<int>starts;

  using nrange_tag=void;
  using nfunction_tag=void;

  int len()const{return starts.len();}

  bool empty()const{return starts.empty();}

  int key(int i)const{
    npre(0<=i&&i<len());
    return starts[i];
  }

  int key(int i){return as_const(*this).key(i);}

  int locate(int position)const{
    int i=nlower(starts,position);
    npre(i<len()&&starts[i]==position);
    return i;
  }

  pair<int,int>bounds(int i)const{
    npre(0<=i&&i<len());
    int r=i+1<len()?starts[i+1]:nlen(source.get());
    return{starts[i],r};
  }

private:
  template<class Self>static auto part(Self&&self,int i){
    auto[l,r]=self.bounds(i);
    if constexpr(is_rvalue_reference_v<Self&&>&&S::owns)
      return nsubfunc(move(self.source.get()),l,r);
    else
      return nsubfunc(self.source.get(),l,r);
  }

public:
  auto operator[](int i)&{return part(*this,i);}
  auto operator[](int i)const&{return part(*this,i);}
  auto operator[](int i)&&{return part(move(*this),i);}
  auto operator()(int position)&{return(*this)[locate(position)];}
  auto operator()(int position)const&{return(*this)[locate(position)];}
  auto operator()(int position)&&{return move(*this)[locate(position)];}
};

}// namespace ni

template<class D,class V>
auto nfunc(D&&domain,V&&values)
  requires nindexed<rmref<D>>&&nindexed<rmref<V>>&&
           (is_lref<V&&>||constructible_from<uncv<V>,V&&>)
{
  auto data=ni::hold(forward<V>(values));
  using T=rmref<D>;
  using K=nvalue_t<T>;

  if constexpr(ni::ndirect_domain_locator<T,K>&&constructible_from<uncv<D>,D&&>){
    auto source=ni::hold(uncv<D>(forward<D>(domain)));
    npre(nlen(source.get())==nlen(data.get()));
    using F=ni::fn<ni::fk::bound,decltype(source),decltype(data)>;
    return F{move(source),move(data)};
  }else{
    auto keys=ncollect<K>(forward<D>(domain));
    nmap<K,int>index;
    index.reserve(keys.len());
    nrep(i,keys.len()){
      npre(index.ins(keys[i],i));
    }
    auto source=ni::hold(move(keys));
    npre(nlen(source.get())==nlen(data.get()));
    using F=ni::fn<ni::fk::bound,decltype(source),decltype(data),nmap<K,int>>;
    return F{move(source),move(data),move(index)};
  }
}

template<class S,class A>
auto nanchors(S&&source,A&&anchors)
  requires nindexed<rmref<S>>&&nindexed<rmref<A>>
{
  return nfunc(forward<A>(anchors),forward<S>(source));
}

template<class G,class P>
auto nbranch(G&&function,P predicate,auto&&alternative)
  requires ndiscrete<rmref<G>>
{
  auto source=ni::hold(forward<G>(function));
  auto data=ni::hold(move(predicate));
  using X=rmref<decltype(alternative)>;
  using K=decltype(source.get().key(0));

  if constexpr(invocable<X&,K>){
    auto extra=ni::hold(forward<decltype(alternative)>(alternative));
    using F=ni::fn<ni::fk::branch,decltype(source),decltype(data),decltype(extra)>;
    return F{move(source),move(data),move(extra)};
  }else{
    auto constant=[value=forward<decltype(alternative)>(alternative)](auto&&)->decltype(auto){
      return(value);
    };
    auto extra=ni::hold(move(constant));
    using F=ni::fn<ni::fk::branch,decltype(source),decltype(data),decltype(extra)>;
    return F{move(source),move(data),move(extra)};
  }
}

template<class G,class P=nequal<>>
auto nruns(G&&function,P together={})
  requires ndiscrete<rmref<G>>
{
  auto source=ni::hold(forward<G>(function));
  nvector<int>starts;
  if(nlen(source.get())){
    starts.push(0);
    for(int i=1;i<nlen(source.get());++i){
      if(!invoke(together,source.get()[i-1],source.get()[i])){
        starts.push(i);
      }
    }
  }
  return ni::run_fn<decltype(source)>{move(source),move(starts)};
}

template<class A,class P=nequal<>>
auto nruns(A&&sequence,P together={})
  requires nindexed<rmref<A>>&&(!ndiscrete<rmref<A>>)
{
  return nruns(nfunc(nrange(nlen(sequence)),forward<A>(sequence)),move(together));
}

// 30_ds
template<class T,class O=nadd<T>>
  requires ncommutative_monoid<O,T>
class nfenwick{
  [[no_unique_address]]O op_;
  int n_=0;
  vector<T>a_;

public:
  nfenwick():a_(1,op_.id()){}
  explicit nfenwick(int n,O op={}):op_(move(op)),n_(n),a_(size_t(n)+1,op_.id()){
    npre(0<=n&&n<INT_MAX);
  }
  template<nindexed A>explicit nfenwick(const A&a,O op={}):nfenwick(nlen(a),move(op)){
    nrep(i,n_)
      a_[i+1]=a[i];
    for(int i=1;i<=n_;++i)
      if(int j=i+(i&-i);j<=n_)
        a_[j]=op_(a_[j],a_[i]);
  }
  int len()const{return n_;}
  bool empty()const{return!n_;}
  const O&operation()const{return op_;}
  void clear(){fill(a_.begin(),a_.end(),op_.id());}
  void add(int i,const T&x){
    npre(0<=i&&i<n_);
    for(++i;i<=n_;i+=i&-i)
      a_[i]=op_(a_[i],x);
  }
  T prefix(int r)const{
    npre(0<=r&&r<=n_);
    T x=op_.id();
    while(r){
      x=op_(a_[r],move(x));
      r-=r&-r;
    }
    return x;
  }
  T fold(int l,int r)const
    requires ngroup<O,T>
  {
    npre(0<=l&&l<=r&&r<=n_);
    return op_(op_.inv(prefix(l)),prefix(r));
  }
  T get(int i)const
    requires ngroup<O,T>
  {
    npre(0<=i&&i<n_);
    return fold(i,i+1);
  }
  template<class C=nless<>>int lower(const T&target,C less={})const{
    if(!less(op_.id(),target))
      return 0;
    int p=0;
    T x=op_.id();
    for(int k=int(bit_floor(unsigned(n_)));k;k>>=1)
      if(int q=p+k;q<=n_){
        T y=op_(x,a_[q]);
        if(less(y,target)){
          p=q;
          x=move(y);
        }
      }
    return p==n_?npos:p;
  }
};

template<class T,class O=nadd<T>>
  requires nmonoid<O,T>
class nseg{
  [[no_unique_address]]O op_;
  int n_=0,s_=1;
  vector<T>a_;

public:
  nseg():a_(2,op_.id()){}
  explicit nseg(int n,O op={}):op_(move(op)),n_(n),s_(nbitceil(n)),a_(size_t(2)*s_,op_.id()){
    npre(0<=n&&n<=(1<<30));
  }
  template<nindexed A>explicit nseg(const A&a,O op={}):nseg(nlen(a),move(op)){
    nrep(i,n_)
      a_[s_+i]=a[i];
    for(int i=s_;--i;)
      a_[i]=op_(a_[i<<1],a_[i<<1|1]);
  }
  int len()const{return n_;}
  bool empty()const{return!n_;}
  const O&operation()const{return op_;}
  void clear(){fill(a_.begin(),a_.end(),op_.id());}
  void set(int i,T x){
    npre(0<=i&&i<n_);
    a_[i+=s_]=move(x);
    while(i>>=1)
      a_[i]=op_(a_[i<<1],a_[i<<1|1]);
  }
  T get(int i)const{
    npre(0<=i&&i<n_);
    return a_[s_+i];
  }
  T fold(int l,int r)const{
    npre(0<=l&&l<=r&&r<=n_);
    T x=op_.id(),y=op_.id();
    for(l+=s_,r+=s_;l<r;l>>=1,r>>=1){
      if(l&1)
        x=op_(move(x),a_[l++]);
      if(r&1)
        y=op_(a_[--r],move(y));
    }
    return op_(move(x),move(y));
  }
  T fold()const{return n_?a_[1]:op_.id();}
};

template<class T,class O=nadd<T>>using nseg_iter=nseg<T,O>;

// 31_lazy
template<class S,class F,class M,class A>
  requires nmonoid<M,S>&&naction<A,S,F>
class nlazyseg{
  [[no_unique_address]]M op_;
  [[no_unique_address]]A act_;
  int n_=0,s_=1;
  vector<S>a_;
  vector<F>tag_;
  vector<unsigned char>has_;
  void put(int p,int z,const F&f){
    a_[p]=act_.apply(move(a_[p]),f,z);
    tag_[p]=has_[p]?act_.compose(f,tag_[p]):f;
    has_[p]=1;
  }
  void push(int p,int l,int r){
    if(!has_[p]||r-l==1)
      return;
    int m=(l+r)>>1;
    put(p<<1,m-l,tag_[p]);
    put(p<<1|1,r-m,tag_[p]);
    tag_[p]=act_.tag_id();
    has_[p]=0;
  }
  void pull(int p){a_[p]=op_(a_[p<<1],a_[p<<1|1]);}
  void apply0(int p,int l,int r,int ql,int qr,const F&f){
    if(ql<=l&&r<=qr){
      put(p,r-l,f);
      return;
    }
    push(p,l,r);
    int m=(l+r)>>1;
    if(ql<m)
      apply0(p<<1,l,m,ql,qr,f);
    if(m<qr)
      apply0(p<<1|1,m,r,ql,qr,f);
    pull(p);
  }
  S fold0(int p,int l,int r,int ql,int qr){
    if(ql<=l&&r<=qr)
      return a_[p];
    push(p,l,r);
    int m=(l+r)>>1;
    if(qr<=m)
      return fold0(p<<1,l,m,ql,qr);
    if(m<=ql)
      return fold0(p<<1|1,m,r,ql,qr);
    return op_(fold0(p<<1,l,m,ql,qr),fold0(p<<1|1,m,r,ql,qr));
  }
  void set0(int p,int l,int r,int i,S x){
    if(r-l==1){
      a_[p]=move(x);
      tag_[p]=act_.tag_id();
      has_[p]=0;
      return;
    }
    push(p,l,r);
    int m=(l+r)>>1;
    if(i<m)
      set0(p<<1,l,m,i,move(x));
    else
      set0(p<<1|1,m,r,i,move(x));
    pull(p);
  }

public:
  nlazyseg():a_(2,op_.id()),tag_(2,act_.tag_id()),has_(2){}
  explicit nlazyseg(int n,M op={},A act={})
      :op_(move(op)),act_(move(act)),n_(n),s_(nbitceil(n)),a_(size_t(2)*s_,op_.id()),
        tag_(size_t(2)*s_,act_.tag_id()),has_(size_t(2)*s_){
    npre(0<=n&&n<=(1<<30));
  }
  template<nindexed V>explicit nlazyseg(const V&v,M op={},A act={}):nlazyseg(nlen(v),move(op),move(act)){
    nrep(i,n_)
      a_[s_+i]=v[i];
    for(int i=s_;--i;)
      pull(i);
  }
  int len()const{return n_;}
  bool empty()const{return!n_;}
  const M&operation()const{return op_;}
  const A&action()const{return act_;}
  void clear(){
    fill(a_.begin(),a_.end(),op_.id());
    fill(tag_.begin(),tag_.end(),act_.tag_id());
    fill(has_.begin(),has_.end(),0);
  }
  void apply(int l,int r,const F&f){
    npre(0<=l&&l<=r&&r<=n_);
    if(l<r)
      apply0(1,0,s_,l,r,f);
  }
  S fold(int l,int r){
    npre(0<=l&&l<=r&&r<=n_);
    return l==r?op_.id():fold0(1,0,s_,l,r);
  }
  S fold()const{return n_?a_[1]:op_.id();}
  void set(int i,S x){
    npre(0<=i&&i<n_);
    set0(1,0,s_,i,move(x));
  }
  S get(int i){
    npre(0<=i&&i<n_);
    return fold(i,i+1);
  }
};
template<class T>using nlazy_addsum=nlazyseg<T,T,nadd<T>,naddsum_action<T>>;

// 32_dsu_queue
template<class T,class O=nadd<T>>
  requires nmonoid<O,T>&&copyable<T>
class nqueue_agg{
  struct E{
    T x,sum;
  };
  [[no_unique_address]]O op_;
  vector<E>l_,r_;
  void move_left(){
    if(!l_.empty())
      return;
    while(!r_.empty()){
      T x=move(r_.back().x);
      r_.pop_back();
      T s=l_.empty()?x:op_(x,l_.back().sum);
      l_.push_back({move(x),move(s)});
    }
  }

public:
  nqueue_agg()=default;
  explicit nqueue_agg(O op):op_(move(op)){}
  int len()const{
    npre(l_.size()+r_.size()<=size_t(INT_MAX));
    return int(l_.size()+r_.size());
  }
  bool empty()const{return l_.empty()&&r_.empty();}
  void push(T x){
    npre(len()<INT_MAX);
    T s=r_.empty()?x:op_(r_.back().sum,x);
    r_.push_back({move(x),move(s)});
  }
  const T&front(){
    npre(!empty());
    return l_.empty()?r_.front().x:l_.back().x;
  }
  const T&front()const{
    npre(!empty());
    return l_.empty()?r_.front().x:l_.back().x;
  }
  T pop(){
    npre(!empty());
    move_left();
    T x=move(l_.back().x);
    l_.pop_back();
    return x;
  }
  T pop(T fallback){return empty()?move(fallback):pop();}
  T fold()const{
    if(l_.empty())
      return r_.empty()?op_.id():r_.back().sum;
    return r_.empty()?l_.back().sum:op_(l_.back().sum,r_.back().sum);
  }
};

class ndsu{
  vector<int>p_;

public:
  explicit ndsu(int n=0):p_(size_t(n),-1){npre(n>=0);}
  int len()const{return int(p_.size());}
  int find(int x){
    npre(0<=x&&x<len());
    int r=x;
    while(p_[r]>=0)
      r=p_[r];
    while(x!=r){
      int y=p_[x];
      p_[x]=r;
      x=y;
    }
    return r;
  }
  int operator()(int x){return find(x);}
  int size(int x){return-p_[find(x)];}
  bool same(int a,int b){return find(a)==find(b);}
  int merge(int a,int b){
    a=find(a);
    b=find(b);
    if(a==b)
      return a;
    if(p_[a]>p_[b])
      swap(a,b);
    p_[a]+=p_[b];
    p_[b]=a;
    return a;
  }
  nvector<int>partition(){
    nvector<int>id(len(),npos),ans(len());
    int k=0;
    nrep(i,len()){
      int r=find(i);
      if(id[r]==npos)
        id[r]=k++;
      ans[i]=id[r];
    }
    return ans;
  }
};

class nrollback_dsu{
  struct C{
    int a,pa,b,pb;
  };
  vector<int>p_;
  vector<C>h_;

public:
  explicit nrollback_dsu(int n=0):p_(size_t(n),-1){npre(n>=0);}
  int len()const{return int(p_.size());}
  int time()const{return int(h_.size());}
  int find(int x)const{
    npre(0<=x&&x<len());
    while(p_[x]>=0)
      x=p_[x];
    return x;
  }
  int size(int x)const{return-p_[find(x)];}
  bool same(int a,int b)const{return find(a)==find(b);}
  bool merge(int a,int b){
    a=find(a);
    b=find(b);
    if(a==b)
      return false;
    if(p_[a]>p_[b])
      swap(a,b);
    h_.push_back({a,p_[a],b,p_[b]});
    p_[a]+=p_[b];
    p_[b]=a;
    return true;
  }
  void undo(){
    npre(!h_.empty());
    auto c=h_.back();
    h_.pop_back();
    p_[c.a]=c.pa;
    p_[c.b]=c.pb;
  }
  void rollback(int t){
    npre(0<=t&&t<=time());
    while(time()>t)
      undo();
  }
};
using ndsu_rollback=nrollback_dsu;

// 33_persistent
template<class T,class O=nadd<T>>
  requires nmonoid<O,T>&&copyable<T>
class npersistent_seg{
  struct E{
    T x;
    int l=0,r=0;
  };
  [[no_unique_address]]O op_;
  int n_=0,s_=1;
  vector<E>a_;
  vector<int>root_;
  int add(E e){
    npre(a_.size()<=size_t(INT_MAX));
    a_.push_back(move(e));
    return int(a_.size())-1;
  }
  const T&val(int p)const{return a_[p].x;}
  template<class V>int build(const V&v,int l,int r){
    if(l>=n_)
      return 0;
    if(r-l==1)
      return add({v[l]});
    int m=(l+r)>>1,x=build(v,l,m),y=build(v,m,r);
    return add({op_(val(x),val(y)),x,y});
  }
  int set0(int p,int l,int r,int i,const T&x){
    if(r-l==1)
      return add({x});
    int m=(l+r)>>1,a=a_[p].l,b=a_[p].r;
    if(i<m)
      a=set0(a,l,m,i,x);
    else
      b=set0(b,m,r,i,x);
    return add({op_(val(a),val(b)),a,b});
  }
  T fold0(int p,int l,int r,int ql,int qr)const{
    if(!p||qr<=l||r<=ql)
      return op_.id();
    if(ql<=l&&r<=qr)
      return val(p);
    int m=(l+r)>>1;
    return op_(fold0(a_[p].l,l,m,ql,qr),fold0(a_[p].r,m,r,ql,qr));
  }

public:
  explicit npersistent_seg(int n=0,O op={}):op_(move(op)),n_(n),s_(nbitceil(n)),a_{{op_.id()}},root_{0}{
    npre(0<=n&&n<=(1<<30));
  }
  template<nindexed V>
  explicit npersistent_seg(const V&v,O op={}):op_(move(op)),n_(nlen(v)),s_(nbitceil(n_)),a_{{op_.id()}}{
    npre(n_<=(1<<30));
    root_.push_back(n_?build(v,0,s_):0);
  }
  int len()const{return n_;}
  int versions()const{
    npre(root_.size()<=size_t(INT_MAX));
    return int(root_.size());
  }
  int nodes()const{
    npre(a_.size()<=size_t(INT_MAX)+1);
    return int(a_.size())-1;
  }
  const O&operation()const{return op_;}
  void reserve_nodes(int n){
    npre(n>=0);
    a_.reserve(size_t(n)+1);
  }
  int fork(int v){
    npre(0<=v&&v<versions()&&root_.size()<size_t(INT_MAX));
    root_.push_back(root_[v]);
    return versions()-1;
  }
  int set(int v,int i,const T&x){
    npre(0<=v&&v<versions()&&0<=i&&i<n_&&root_.size()<size_t(INT_MAX));
    root_.push_back(set0(root_[v],0,s_,i,x));
    return versions()-1;
  }
  T fold(int v,int l,int r)const{
    npre(0<=v&&v<versions()&&0<=l&&l<=r&&r<=n_);
    return fold0(root_[v],0,s_,l,r);
  }
  T fold(int v)const{return fold(v,0,n_);}
  T get(int v,int i)const{
    npre(0<=i&&i<n_);
    return fold(v,i,i+1);
  }
};

// 34_wavelet
template<integral T>
  requires(!same_as<remove_cv_t<T>,bool>)
class nwavelet{
  using U=uint_t<T>;
  static constexpr int B=limits<U>::digits;
  int n_=0;
  array<vector<int>,B>z_;
  array<int,B>mid_{};
  static constexpr U enc(T x){
    U y=U(x);
    if constexpr(is_signed_v<T>)
      y^=U(1)<<(B-1);
    return y;
  }
  static constexpr T dec(U x){
    if constexpr(is_signed_v<T>){
      x^=U(1)<<(B-1);
      return bit_cast<T>(x);
    }else
      return x;
  }
  void zero(int k,int&l,int&r)const{
    l=z_[k][l];
    r=z_[k][r];
  }
  void one(int k,int&l,int&r)const{
    l=mid_[k]+l-z_[k][l];
    r=mid_[k]+r-z_[k][r];
  }

public:
  nwavelet(){
    for(auto&v:z_)
      v={0};
  }
  template<nindexed A>explicit nwavelet(const A&a):n_(nlen(a)){
    npre(n_>=0);
    vector<U>x(n_),y(n_);
    nrep(i,n_)
      x[i]=enc(T(a[i]));
    nrep(k,B){
      int b=B-1-k;
      auto&p=z_[k];
      p.resize(size_t(n_)+1);
      nrep(i,n_)
        p[i+1]=p[i]+int(!((x[i]>>b)&1));
      int i=0,j=mid_[k]=p[n_];
      for(U v:x)
        y[((v>>b)&1)?j++:i++]=v;
      x.swap(y);
    }
  }
  int len()const{return n_;}
  bool empty()const{return!n_;}
  T kth(int l,int r,int k)const{
    npre(0<=l&&l<=r&&r<=n_&&0<=k&&k<r-l);
    U x=0;
    nrep(q,B){
      int c=z_[q][r]-z_[q][l];
      if(k<c)
        zero(q,l,r);
      else{
        k-=c;
        x|=U(1)<<(B-1-q);
        one(q,l,r);
      }
    }
    return dec(x);
  }
  int count_less(int l,int r,T bound)const{
    npre(0<=l&&l<=r&&r<=n_);
    U x=enc(bound);
    int ans=0;
    nrep(k,B){
      if((x>>(B-1-k))&1){
        ans+=z_[k][r]-z_[k][l];
        one(k,l,r);
      }else
        zero(k,l,r);
    }
    return ans;
  }
  int count(int l,int r,T x)const{
    npre(0<=l&&l<=r&&r<=n_);
    U y=enc(x);
    nrep(k,B){
      if((y>>(B-1-k))&1)
        one(k,l,r);
      else
        zero(k,l,r);
    }
    return r-l;
  }
  int count(int l,int r,T lo,T hi)const{
    npre(!(hi<lo));
    return count_less(l,r,hi)-count_less(l,r,lo);
  }
  nmaybe<T>predecessor(int l,int r,T x)const{
    int k=count_less(l,r,x);
    return k?nmaybe<T>(kth(l,r,k-1)):nmaybe<T>{};
  }
  nmaybe<T>successor(int l,int r,T x)const{
    int k=count_less(l,r,x);
    return k<r-l?nmaybe<T>(kth(l,r,k)):nmaybe<T>{};
  }
};

// 35_offline
struct ninterval_query{
  int left,right,id;
};

template<nindexed Q>nvector<int>nmo_order(const Q&q,int n){
  npre(n>=0);
  int z=nlen(q),b=max(1,int(sqrt(double(max(1,n)))));
  nvector<int>p(z);
  nrep(i,z){
    npre(0<=q[i].left&&q[i].left<=q[i].right&&q[i].right<=n);
    p[i]=i;
  }
  nsort(p,[&](int i,int j){
    int x=q[i].left/b,y=q[j].left/b;
    return x!=y?x<y:(x&1?q[i].right>q[j].right:q[i].right<q[j].right);
  });
  return p;
}

template<nindexed Q,class AL,class AR,class RL,class RR,class Ans>
void nrun_mo(const Q&q,int n,AL&&al,AR&&ar,RL&&rl,RR&&rr,Ans&&ans){
  int l=0,r=0;
  for(int i:nmo_order(q,n)){
    auto&x=q[i];
    while(x.left<l)
      invoke(al,--l);
    while(r<x.right)
      invoke(ar,r++);
    while(l<x.left)
      invoke(rl,l++);
    while(x.right<r)
      invoke(rr,--r);
    invoke(ans,x.id);
  }
}
template<nindexed Q,class Add,class Remove,class Ans>
void nrun_mo(const Q&q,int n,Add&&add,Remove&&remove,Ans&&ans){
  nrun_mo(q,n,add,add,remove,remove,ans);
}

// 36_classic
template<class T,class O=nmin<T>>
  requires nmonoid<O,T>&&copyable<T>
class nsparse{
  nvector<T>v_;
  nvector<nvector<T>>st_;
  [[no_unique_address]]O op_;

public:
  nsparse()=default;
  template<nindexed A>explicit nsparse(const A&a,O op={}):v_(ncollect<T>(a)),op_(move(op)){
    int n=v_.len(),k=n<=1?0:int(bit_width(unsigned(n-1)));
    st_.resize(k);
    nrep(h,k){
      auto&t=st_[h];
      t=v_;
      int z=1<<h;
      for(int l=0;l<n;l+=z<<1){
        int m=min(l+z,n),r=min(l+(z<<1),n);
        for(int i=m-1;i-->l;)
          t[i]=op_(v_[i],t[i+1]);
        for(int i=m+1;i<r;++i)
          t[i]=op_(t[i-1],v_[i]);
      }
    }
  }
  int len()const{return v_.len();}
  bool empty()const{return v_.empty();}
  const T&operator[](int i)const{return v_[i];}
  T fold(int l,int r)const{
    npre(0<=l&&l<=r&&r<=len());
    if(l==r)
      return op_.id();
    if(l+1==r)
      return v_[l];
    int k=int(bit_width(unsigned(l^(r-1))))-1;
    return op_(st_[k][l],st_[k][r-1]);
  }
  T fold(int l,int r,T fallback)const{
    npre(0<=l&&l<=r&&r<=len());
    return l==r?move(fallback):fold(l,r);
  }
};

template<class T>
  requires copyable<T>&&requires(T a,const T&b){
    {a+=b}->same_as<T&>;
    {-a}->convertible_to<T>;
    {a==b}->convertible_to<bool>;
  }
class npotential_dsu{
  vector<int>p_;
  nvector<T>d_;
  static T add(T a,const T&b){return a+=b;}
  static T sub(T a,const T&b){return a+=-b;}
  pair<int,T>root(int x){
    npre(0<=x&&x<len());
    int r=x;
    T sum{};
    while(p_[r]>=0){
      sum=add(move(sum),d_[r]);
      r=p_[r];
    }
    int u=x;
    T pref{};
    while(p_[u]>=0){
      int v=p_[u];
      T e=d_[u];
      p_[u]=r;
      d_[u]=sub(sum,pref);
      pref=add(move(pref),e);
      u=v;
    }
    return{r,sum};
  }

public:
  explicit npotential_dsu(int n=0):p_(size_t(n),-1),d_(n){npre(n>=0);}
  int len()const{return int(p_.size());}
  int find(int x){return root(x).first;}
  int size(int x){return-p_[find(x)];}
  bool same(int a,int b){return find(a)==find(b);}
  bool bind(int a,int b,T w){
    auto[x,dx]=root(a);
    auto[y,dy]=root(b);
    if(x==y)
      return sub(dy,dx)==w;
    T t=add(add(move(w),dx),-dy);
    if(p_[x]>p_[y]){
      swap(x,y);
      t=-t;
    }
    p_[x]+=p_[y];
    p_[y]=x;
    d_[y]=move(t);
    return true;
  }
  nmaybe<T>diff(int a,int b){
    auto[x,dx]=root(a);
    auto[y,dy]=root(b);
    return x==y?nmaybe<T>(sub(dy,dx)):nmaybe<T>{};
  }
  T diff(int a,int b,T fallback){
    auto x=diff(a,b);
    return x?x.val():move(fallback);
  }
};

// 40_graph
template<class W=int>struct narc{
  int to;
  W weight;
  friend bool operator==(const narc&,const narc&)=default;
};
template<integral E>constexpr int nedge_to(E e){
  return ni::cint(e);
}
template<class E>
  requires requires(const E&e){e.to;}
constexpr int nedge_to(const E&e){
  return ni::cint(e.to);
}
template<integral E>constexpr int nedge_weight(E){
  return 1;
}
template<class E>
  requires requires(const E&e){e.weight;}
constexpr decltype(auto)nedge_weight(const E&e){
  return(e.weight);
}
template<class E>
  requires(!requires(const E&e){e.weight;})&&requires(const E&e){e.w;}
constexpr decltype(auto)nedge_weight(const E&e){
  return(e.w);
}
template<class W=int>struct nedge{
  int from,to,id;
  W w;
};

template<class T>constexpr T ncapadd(T a,T b,T inf=ninf<T>){
  if constexpr(integral<T>&&sizeof(T)<=8){
    using X=select_t<sint<T>,__int128_t,__uint128_t>;
    X x=X(a)+X(b);
    if(x>X(inf))
      return inf;
    if constexpr(sint<T>)
      if(x<X(nninf<T>))
        return nninf<T>;
    return T(x);
  }else
    return a+b;
}

template<class F>class ngraph_view{
  int n_;
  [[no_unique_address]]F f_;

public:
  ngraph_view(int n,F f):n_(n),f_(move(f)){npre(n>=0);}
  int vertices()const{return n_;}
  decltype(auto)neighbors(int u)const{
    npre(0<=u&&u<n_);
    return invoke(f_,u);
  }
};
template<class F>ngraph_view(int,F)->ngraph_view<F>;

template<class G>
concept ngraph_like=requires(const G&g,int u){
  g.vertices();
  g.neighbors(u);
  requires nenumerable<decltype(g.neighbors(u))>;
}&&(!same_as<uncv<decltype(declval<const G&>().vertices())>,bool>);
namespace ni{
template<ngraph_like G>int gverts(const G&g){
  if constexpr(integral<uncv<decltype(g.vertices())>>)
    return cint(g.vertices());
  else
    return nlen(g.vertices());
}
template<class G>
using gneighbor_t=decltype(nenumerate(declval<decltype(declval<const G&>().neighbors(0))>()).val());
template<class G>using ngraph_weight_t=uncv<decltype(nedge_weight(declval<gneighbor_t<G>>()))>;
template<class G>using ngraph_edge_t=gneighbor_t<G>;
}// namespace ni

namespace ni{
template<class D,class W>struct gapi{
private:
  D&self(){return static_cast<D&>(*this);}
  const D&self()const{return static_cast<const D&>(*this);}
  template<bool Const>auto near(int u)const{
    using G=select_t<Const,const D,D>;
    G*g=const_cast<G*>(static_cast<const G*>(addressof(self())));
    npre(0<=u&&u<g->len());
    return nview(g->edge_degree(u),[g,u](int i){
      int id=g->edge_id(u,i);
      using R=select_t<Const,const W&,W&>;
      return nedge<R>{u,g->edge_to(id),id,g->edge_weight(id)};
    });
  }
  template<bool Const>struct all_view{
    using G=select_t<Const,const D,D>;
    G*g;
    struct cursor{
      G*g;
      int u=0,i=0;
      explicit cursor(G*g):g(g){seek();}
      void seek(){
        while(u<g->len()&&i==g->edge_degree(u)){
          ++u;
          i=0;
        }
      }
      bool ok()const{return u<g->len();}
      auto val()const{
        int id=g->edge_id(u,i);
        using R=select_t<Const,const W&,W&>;
        return nedge<R>{u,g->edge_to(id),id,g->edge_weight(id)};
      }
      int idx()const{return g->edge_id(u,i);}
      void next(){
        ++i;
        seek();
      }
    };
    int len()const{return g->edges();}
    bool empty()const{return!len();}
    cursor enumerate()const{return cursor(g);}
  };

public:
  auto neighbors(int u)&{return near<false>(u);}
  auto neighbors(int u)const&{return near<true>(u);}
  auto operator[](int u)&{return neighbors(u);}
  auto operator[](int u)const&{return neighbors(u);}
  auto from(int u)&{return neighbors(u);}
  auto from(int u)const&{return neighbors(u);}
  int degree(int u)const{
    npre(0<=u&&u<self().len());
    return self().edge_degree(u);
  }
  int find(int u,int v,int miss=npos)const{
    nfor(edge,neighbors(u)){
      if(edge.to==v)
        return edge.id;
    }
    return miss;
  }
  bool has(int u,int v)const{return find(u,v)!=npos;}
  auto weight(int id){return self().weight_ptr(id);}
  auto weight(int id)const{return self().weight_ptr(id);}
  W weight(int id,W fallback)const{
    auto p=weight(id);
    return p?*p:move(fallback);
  }
  bool set(int id,W value){
    auto p=weight(id);
    if(!p)
      return false;
    *p=move(value);
    return true;
  }
  auto vertices()const{return nrange(self().len());}
  auto arcs()&{return all_view<false>{addressof(self())};}
  auto arcs()const&{return all_view<true>{addressof(self())};}
};
}// namespace ni

template<class W=int>class ngraph_list{
  nvector<nvector<narc<W>>>a_;
  int m_=0;

public:
  explicit ngraph_list(int n=0):a_(n){}
  int vertices()const{return a_.len();}
  int arcs()const{return m_;}
  void add(int u,int v,W w=W{1}){
    npre(0<=u&&u<vertices()&&0<=v&&v<vertices()&&m_<INT_MAX);
    a_[u].push(narc<W>{v,move(w)});
    ++m_;
  }
  void add2(int u,int v,const W&w=W{1}){
    add(u,v,w);
    add(v,u,w);
  }
  nview<const narc<W>>neighbors(int u)const{
    npre(0<=u&&u<vertices());
    return{a_[u].data(),a_[u].len()};
  }
};

template<class W=int>class ngraph_forward:public ni::gapi<ngraph_forward<W>,W>{
  struct E{
    int u,v;
    W w;
  };
  nvector<nvector<int>>adj_;
  nvector<E>e_;
  friend struct ni::gapi<ngraph_forward,W>;
  int edge_degree(int u)const{return adj_[u].len();}
  int edge_id(int u,int i)const{return adj_[u][i];}
  int edge_to(int id)const{return e_[id].v;}
  W&edge_weight(int id){return e_[id].w;}
  const W&edge_weight(int id)const{return e_[id].w;}

public:
  using edge=nedge<W>;
  ngraph_forward()=default;
  explicit ngraph_forward(int n,int cap=0):adj_(n){reserve(cap);}
  template<ngraph_like G>explicit ngraph_forward(const G&g){build(g);}
  template<ngraph_like G>void build(const G&g){
    adj_=nvector<nvector<int>>(ni::gverts(g));
    e_.clear();
    nrep(u,len()){
      nfor(x,g.neighbors(u)){
        add(u,nedge_to(x),W(nedge_weight(x)));
      }
    }
  }
  int len()const{return adj_.len();}
  int edges()const{return e_.len();}
  bool empty()const{return adj_.empty();}
  void reserve(int n){e_.reserve(n);}
  void clear_edges(){
    nfor(x,adj_)
      x.clear();
    e_.clear();
  }
  int add(int u,int v,W w=W{1}){
    npre(0<=u&&u<len()&&0<=v&&v<len());
    int id=e_.len();
    e_.push(E{u,v,move(w)});
    adj_[u].push(id);
    return id;
  }
  pair<int,int>add2(int u,int v,W w=W{1}){
    int a=add(u,v,w),b=add(v,u,move(w));
    return{a,b};
  }
  W*weight_ptr(int id){return e_.get(id)?&e_[id].w:nullptr;}
  const W*weight_ptr(int id)const{return e_.get(id)?&e_[id].w:nullptr;}
  ngraph_forward reverse()const{
    ngraph_forward r(len(),edges());
    nfor(x,this->arcs())
      r.add(x.to,x.from,x.w);
    return r;
  }
};

template<class W=int>class ngraph_csr:public ni::gapi<ngraph_csr<W>,W>{
  int n_=0;
  nvector<int>off_{0},to_;
  nvector<W>w_;
  friend struct ni::gapi<ngraph_csr,W>;
  int edge_degree(int u)const{return off_[u+1]-off_[u];}
  int edge_id(int u,int i)const{return off_[u]+i;}
  int edge_to(int id)const{return to_[id];}
  W&edge_weight(int id){return w_[id];}
  const W&edge_weight(int id)const{return w_[id];}

public:
  using edge=nedge<W>;
  ngraph_csr()=default;
  explicit ngraph_csr(int n):n_(n),off_(n+1){npre(n>=0);}
  template<ngraph_like G>explicit ngraph_csr(const G&g){build(g);}
  template<ngraph_like G>void build(const G&g){
    n_=ni::gverts(g);
    off_=nvector<int>(n_+1);
    nrep(u,n_){
      nfor(x,g.neighbors(u)){
        int v=nedge_to(x);
        npre(0<=v&&v<n_&&off_[u+1]<INT_MAX);
        ++off_[u+1];
      }
      off_[u+1]+=off_[u];
    }
    to_.clear();
    w_.clear();
    to_.reserve(off_.back());
    w_.reserve(off_.back());
    nrep(u,n_){
      nfor(x,g.neighbors(u)){
        to_.push(nedge_to(x));
        w_.push(W(nedge_weight(x)));
      }
    }
  }
  int len()const{return n_;}
  int edges()const{return to_.len();}
  bool empty()const{return!n_;}
  W*weight_ptr(int id){return w_.get(id);}
  const W*weight_ptr(int id)const{return w_.get(id);}
  ngraph_csr reverse()const{
    ngraph_forward<W>g(n_,edges());
    nfor(x,this->arcs())
      g.add(x.to,x.from,x.w);
    return ngraph_csr(g);
  }
};
template<ngraph_like G>ngraph_csr(const G&)->ngraph_csr<ni::ngraph_weight_t<G>>;
template<class W=int>using ngraph=ngraph_forward<W>;
template<ngraph_like G>auto nvertices(const G&g){
  return nrange(ni::gverts(g));
}

template<class G>class ngraph_arcs_view{
  G*g_;
  using A=decltype(declval<G&>().neighbors(0));
  using I=nenumerator_t<A>;

public:
  explicit ngraph_arcs_view(G&g):g_(&g){}
  struct cursor{
    G*g;
    int u=0,id=0;
    optional<I>it;
    cursor(G*x):g(x){seek();}
    void seek(){
      while(u<ni::gverts(*g)){
        it.emplace(nenumerate(g->neighbors(u)));
        if(it->ok())
          return;
        ++u;
      }
      it.reset();
    }
    bool ok()const{return bool(it);}
    auto val(){
      auto&&e=it->val();
      int k=id;
      if constexpr(requires{e.id;})
        k=e.id;
      return nedge<decltype(nedge_weight(e))>{u,nedge_to(e),k,nedge_weight(e)};
    }
    int idx()const{return id;}
    void next(){
      it->next();
      ++id;
      if(!it->ok()){
        ++u;
        seek();
      }
    }
  };
  cursor enumerate()const{return cursor(g_);}
  bool empty()const{return!enumerate().ok();}
  int len()const{
    int n=0;
    for(auto c=enumerate();c.ok();c.next()){
      npre(n<INT_MAX);
      ++n;
    }
    return n;
  }
};
template<ngraph_like G>auto narcs(G&g){
  return ngraph_arcs_view<G>(g);
}
template<ngraph_like G>auto narcs(const G&g){
  return ngraph_arcs_view<const G>(g);
}
template<ngraph_like G>auto narcs(G&&)=delete;

template<class G,class P>class ngraph_where_view{
  const G*g_;
  [[no_unique_address]]P p_;
  using A=decltype(declval<const G&>().neighbors(0));
  using I=nenumerator_t<A>;
  struct adj{
    const ngraph_where_view*o;
    int u;
    struct cursor{
      I it;
      const P*p;
      int i=0;
      cursor(I x,const P*q):it(move(x)),p(q){skip();}
      void skip(){
        while(it.ok()&&!invoke(*p,it.val()))
          it.next();
      }
      bool ok()const{return it.ok();}
      decltype(auto)val(){return it.val();}
      int idx()const{return i;}
      void next(){
        it.next();
        ++i;
        skip();
      }
    };
    cursor enumerate()const{return{nenumerate(o->g_->neighbors(u)),&o->p_};}
    bool empty()const{return!enumerate().ok();}
    int len()const{
      int n=0;
      for(auto c=enumerate();c.ok();c.next())
        ++n;
      return n;
    }
  };

public:
  ngraph_where_view(const G&g,P p):g_(&g),p_(move(p)){}
  int len()const{return ni::gverts(*g_);}
  bool empty()const{return!len();}
  auto vertices()const{return nrange(len());}
  adj neighbors(int u)const{
    npre(0<=u&&u<len());
    return{this,u};
  }
  adj operator[](int u)const&{return neighbors(u);}
  adj from(int u)const&{return neighbors(u);}
  int edges()const{
    int n=0;
    nrep(u,len())
      n+=neighbors(u).len();
    return n;
  }
  auto arcs()const&{return ngraph_arcs_view<const ngraph_where_view>(*this);}
};
template<ngraph_like G,class P>auto ngraph_where(const G&g,P p){
  return ngraph_where_view<G,P>(g,move(p));
}
template<ngraph_like G,class P>auto ngraph_where(const G&&,P)=delete;

template<class D>struct npath_result{
  nvector<D>d;
  nvector<int>p;
  D bad{};
  int len()const{return d.len();}
  bool reach(int v)const{return 0<=v&&v<p.len()&&p[v]!=npos;}
  D dist(int v,D fallback)const{return reach(v)?d[v]:move(fallback);}
  const D&operator[](int v)const{return d[v];}
  nvector<int>path(int v)const{
    nvector<int>a;
    if(!reach(v))
      return a;
    for(;;v=p[v]){
      a.push(v);
      if(p[v]==v)
        break;
    }
    nreverse_inplace(a);
    return a;
  }
};
template<ngraph_like G>npath_result<int>nbfs_path(const G&g,int s){
  int n=ni::gverts(g);
  npre(0<=s&&s<n);
  npath_result<int>a{nvector<int>(n,npos),nvector<int>(n,npos),npos};
  ndeque<int>q;
  a.d[s]=0;
  a.p[s]=s;
  q.pushr(s);
  while(!q.empty()){
    int u=q.popl();
    nfor(e,g.neighbors(u)){
      int v=nedge_to(e);
      npre(0<=v&&v<n);
      if(a.p[v]==npos){
        a.d[v]=a.d[u]+1;
        a.p[v]=u;
        q.pushr(v);
      }
    }
  }
  return a;
}
template<class D=long long,ngraph_like G>
  requires is_num<D>&&(!same_as<remove_cv_t<D>,bool>)
npath_result<D>ndijkstra_path(const G&g,int s,D inf=nmin<D>{}.id()){
  int n=ni::gverts(g);
  npre(0<=s&&s<n&&D{}<=inf);
  npath_result<D>a{nvector<D>(n,inf),nvector<int>(n,npos),inf};
  priority_queue<pair<D,int>,vector<pair<D,int>>,greater<pair<D,int>>>q;
  a.d[s]=D{};
  a.p[s]=s;
  q.push({D{},s});
  while(!q.empty()){
    auto[x,u]=q.top();
    q.pop();
    if(x!=a.d[u])
      continue;
    nfor(e,g.neighbors(u)){
      int v=nedge_to(e);
      D w=ni::numcast<D>(nedge_weight(e));
      npre(0<=v&&v<n&&!(w<D{}));
      if(x<=inf&&w<=inf-x&&x+w<a.d[v]){
        a.d[v]=x+w;
        a.p[v]=u;
        q.push({a.d[v],v});
      }
    }
  }
  return a;
}
template<ngraph_like G>nvector<int>nbfs(const G&g,int s){
  return nbfs_path(g,s).d;
}
template<class D=long long,ngraph_like G>
  requires is_num<D>&&(!same_as<remove_cv_t<D>,bool>)
nvector<D>ndijkstra(const G&g,int s,D inf=nmin<D>{}.id()){
  return ndijkstra_path<D>(g,s,inf).d;
}

// 41_graph_alg
template<ngraph_like G>nmaybe<nvector<int>>ntoposort(const G&g){
  int n=ni::gverts(g);
  nvector<int>d(n,0),z;
  ndeque<int>q;
  nrep(u,n){
    decltype(auto)a=g.neighbors(u);
    nfor(x,a){
      int v=nedge_to(x);
      npre(v>=0&&v<n&&d[v]<INT_MAX);
      ++d[v];
    }
  }
  nrep(i,n)
    if(!d[i])
      q.pushr(i);
  while(!q.empty()){
    int u=q.popl();
    z.push(u);
    decltype(auto)a=g.neighbors(u);
    nfor(x,a){
      if(!--d[nedge_to(x)])
        q.pushr(nedge_to(x));
    }
  }
  return z.len()==n?nmaybe<nvector<int>>(move(z)):nmaybe<nvector<int>>{};
}
template<ngraph_like G>nmaybe<nvector<int>>ntopo(const G&g){
  return ntoposort(g);
}
template<ngraph_like G>nvector<int>ntopo(const G&g,nvector<int>f){
  auto z=ntoposort(g);
  return z?move(z.val()):move(f);
}

template<ngraph_like G>npartition nscc(const G&g){
  int n=ni::gverts(g),time=0,cc=0;
  nvector<int>dfn(n),low(n),st,bel(n,npos);
  nvector<unsigned char>in(n);
  auto dfs=[&](auto&&self,int u)->void{
    dfn[u]=low[u]=++time;
    st.push(u);
    in[u]=1;
    decltype(auto)a=g.neighbors(u);
    nfor(x,a){
      int v=nedge_to(x);
      npre(v>=0&&v<n);
      if(!dfn[v]){
        self(self,v);
        nchmin(low[u],low[v]);
      }else if(in[v])
        nchmin(low[u],dfn[v]);
    }
    if(low[u]==dfn[u])
      for(;;){
        int v=st.pop();
        in[v]=0;
        bel[v]=cc;
        if(v==u)
          break;
      }
    if(low[u]==dfn[u])
      ++cc;
  };
  nrep(i,n)
    if(!dfn[i])
      dfs(dfs,i);
  return npartition(move(bel));
}
template<ngraph_like G>npartition nscc_tarjan(const G&g){
  return nscc(g);
}

namespace ni{
struct tree_layout{
  vector<vector<int>>adjacency;
  nvector<int>parent,order;
};
template<ngraph_like G>tree_layout build_tree(const G&g,int root,bool symmetric){
  int n=gverts(g);
  npre(n>0&&root>=0&&root<n);
  tree_layout z{vector<vector<int>>(n),nvector<int>(n,npos),{}};
  nrep(u,n){
    decltype(auto)a=g.neighbors(u);
    nfor(x,a){
      int v=nedge_to(x);
      npre(v>=0&&v<n&&v!=u);
      z.adjacency[u].push_back(v);
    }
  }
  z.parent[root]=root;
  z.order.push(root);
  nrep(i,n){
    npre(i<z.order.len());
    int u=z.order[i];
    for(int v:z.adjacency[u])
      if(z.parent[v]==npos){
        z.parent[v]=u;
        z.order.push(v);
      }
  }
  long long down=0,up=0;
  nrep(u,n)
    for(int v:z.adjacency[u])
      if(z.parent[v]==u)
        ++down;
  else if(u!=root&&z.parent[u]==v)++up;
  else npre(false);
  npre(down==n-1LL&&(symmetric?up==n-1LL:(up==0||up==n-1LL)));
  return z;
}
}// namespace ni
class nlca{
  int n=0;
  nvector<nvector<int>>up;
  nvector<int>dep;

public:
  nlca()=default;
  template<ngraph_like G>explicit nlca(const G&g,int root=0):n(ni::gverts(g)),dep(n,npos){
    auto t=ni::build_tree(g,root,false);
    int lg=max(1,int(bit_width(unsigned(n))));
    up=nvector<nvector<int>>(lg,nvector<int>(n,root));
    dep[root]=0;
    nrep(i,t.order.len()){
      if(i){
        int v=t.order[i],p=t.parent[v];
        dep[v]=dep[p]+1;
        up[0][v]=p;
      }
    }
    for(int k=1;k<lg;++k)
      nrep(v,n)
        up[k][v]=up[k-1][up[k-1][v]];
  }
  int len()const{return n;}
  int depth(int v)const{
    npre(v>=0&&v<n);
    return dep[v];
  }
  int jump(int v,int k)const{
    npre(v>=0&&v<n&&k>=0);
    if(k>dep[v])
      return npos;
    for(int i=0;k;++i,k>>=1)
      if(k&1)
        v=up[i][v];
    return v;
  }
  int operator()(int a,int b)const{
    npre(a>=0&&a<n&&b>=0&&b<n);
    if(dep[a]<dep[b])
      swap(a,b);
    a=jump(a,dep[a]-dep[b]);
    if(a==b)
      return a;
    for(int k=up.len();k--;){
      if(up[k][a]!=up[k][b]){
        a=up[k][a];
        b=up[k][b];
      }
    }
    return up[0][a];
  }
  int distance(int a,int b)const{
    int c=(*this)(a,b);
    return dep[a]+dep[b]-2*dep[c];
  }
  int kth_on_path(int a,int b,int k)const{
    npre(k>=0);
    int c=(*this)(a,b),x=dep[a]-dep[c],y=dep[b]-dep[c],d=x+y;
    if(k>d)
      return npos;
    return k<=x?jump(a,k):jump(b,d-k);
  }
};

// 42_tree
template<ngraph_like G,class T,class M,class V,class L>
  requires copyable<T>
nvector<T>nreroot(const G&g,T id,M merge,V vertex,L lift,int root=0){
  int n=ni::gverts(g);
  if(!n)
    return{};
  auto t=ni::build_tree(g,root,true);
  nvector<T>down(n,id),up(n,id),ans(n,id);
  for(int k=n;k--;){
    int u=t.order[k];
    T z=id;
    for(int v:t.adjacency[u])
      if(t.parent[v]==u)
        z=invoke(merge,move(z),invoke(lift,down[v],v,u));
    down[u]=invoke(vertex,move(z),u);
  }
  nrep(k,n){
    int u=t.order[k],d=int(t.adjacency[u].size());
    nvector<T>x,p(d+1,id),s(d+1,id);
    x.reserve(d);
    for(int v:t.adjacency[u])
      x.push(v==t.parent[u]?up[u]:invoke(lift,down[v],v,u));
    nrep(i,d)
      p[i+1]=invoke(merge,p[i],x[i]);
    for(int i=d;i--;)
      s[i]=invoke(merge,x[i],s[i+1]);
    ans[u]=invoke(vertex,p[d],u);
    nrep(i,d){
      int v=t.adjacency[u][i];
      if(t.parent[v]==u)
        up[v]=invoke(lift,invoke(vertex,invoke(merge,p[i],s[i+1]),u),u,v);
    }
  }
  return ans;
}
struct nhld_segment{
  int l,r;
  bool rev;
};
class nhld{
  int n=0;
  nvector<int>par,dep,heavy,head,pos,inv,sz;

public:
  nhld()=default;
  template<ngraph_like G>
  explicit nhld(const G&g,int root=0)
      :n(ni::gverts(g)),par(n),dep(n),heavy(n,npos),head(n),pos(n),inv(n),sz(n,1){
    if(!n){
      npre(!root);
      return;
    }
    auto t=ni::build_tree(g,root,false);
    par=t.parent;
    nrep(i,n){
      if(i){
        int v=t.order[i];
        dep[v]=dep[par[v]]+1;
      }
    }
    for(int k=n;k--;){
      int u=t.order[k],best=0;
      for(int v:t.adjacency[u])
        if(par[v]==u){
          sz[u]+=sz[v];
          if(sz[v]>best){
            best=sz[v];
            heavy[u]=v;
          }
        }
    }
    nvector<pair<int,int>>st{{root,root}};
    int timer=0;
    while(!st.empty()){
      auto[u,h]=st.pop();
      for(;u!=npos;u=heavy[u]){
        head[u]=h;
        pos[u]=timer;
        inv[timer++]=u;
        for(int v:t.adjacency[u])
          if(par[v]==u&&v!=heavy[u])
            st.push(v,v);
      }
    }
    npre(timer==n);
  }
  int len()const{return n;}
  bool empty()const{return!n;}
  bool same(int a,int b)const{return a>=0&&a<n&&b>=0&&b<n;}
  int parent(int v)const{
    npre(v>=0&&v<n);
    return par[v];
  }
  int depth(int v)const{
    npre(v>=0&&v<n);
    return dep[v];
  }
  int position(int v)const{
    npre(v>=0&&v<n);
    return pos[v];
  }
  int vertex(int p)const{
    npre(p>=0&&p<n);
    return inv[p];
  }
  int lca(int a,int b,int fail=npos)const{
    if(!same(a,b))
      return fail;
    while(head[a]!=head[b]){
      if(dep[head[a]]<dep[head[b]])
        swap(a,b);
      a=par[head[a]];
    }
    return dep[a]<dep[b]?a:b;
  }
  nvector<nhld_segment>path(int a,int b,bool edge=false)const{
    nvector<nhld_segment>x,y;
    if(!same(a,b))
      return x;
    while(head[a]!=head[b])
      if(dep[head[a]]>=dep[head[b]]){
        x.push(nhld_segment{pos[head[a]],pos[a]+1,true});
        a=par[head[a]];
      }else{
        y.push(nhld_segment{pos[head[b]],pos[b]+1,false});
        b=par[head[b]];
      }
    if(dep[a]>=dep[b]){
      int l=pos[b]+edge;
      if(l<=pos[a])
        x.push(nhld_segment{l,pos[a]+1,true});
    }else{
      int l=pos[a]+edge;
      if(l<=pos[b])
        y.push(nhld_segment{l,pos[b]+1,false});
    }
    while(!y.empty())
      x.push(y.pop());
    return x;
  }
  pair<int,int>subtree(int v,bool edge=false)const{
    npre(v>=0&&v<n);
    return{pos[v]+edge,pos[v]+sz[v]};
  }
  template<class F>bool each(int a,int b,F f,bool edge=false)const{
    if(!same(a,b))
      return false;
    nfor(x,path(a,b,edge))
      invoke(f,x.l,x.r,x.rev);
    return true;
  }
};

template<class W=int>class nlca_binary{
  int n=0,lg=0;
  nvector<nvector<int>>up;
  nvector<int>dep,comp;
  nvector<W>dis;
  template<class X,class Y>static W add(X a,Y b){
    if constexpr(integral<W>)
      return ni::cadd(W(a),ni::numcast<W>(b));
    else
      return W(a)+W(b);
  }

public:
  nlca_binary()=default;
  template<ngraph_like G>explicit nlca_binary(const G&g,int root=0){
    build(g,root,[](const auto&e)->decltype(auto){return nedge_weight(e);});
  }
  template<ngraph_like G,class F>nlca_binary(const G&g,int root,F f){build(g,root,move(f));}
  template<ngraph_like G,class F>void build(const G&g,int root,F weight){
    n=ni::gverts(g);
    lg=max(1,int(bit_width(unsigned(max(1,n)))));
    up=nvector<nvector<int>>(lg,nvector<int>(n));
    dep=nvector<int>(n,npos);
    comp=nvector<int>(n,npos);
    dis=nvector<W>(n);
    if(!n){
      npre(!root);
      return;
    }
    npre(root>=0&&root<n);
    nvector<int>starts;
    starts.push(root);
    nrep(i,n)
      if(i!=root)
        starts.push(i);
    nfor(s,starts){
      if(dep[s]==npos){
        ndeque<int>q;
        dep[s]=0;
        comp[s]=s;
        up[0][s]=s;
        q.pushr(s);
        while(!q.empty()){
          int u=q.popl();
          decltype(auto)a=g.neighbors(u);
          nfor(e,a){
            int v=nedge_to(e);
            npre(v>=0&&v<n);
            if(dep[v]!=npos)
              continue;
            dep[v]=dep[u]+1;
            comp[v]=s;
            up[0][v]=u;
            dis[v]=add(dis[u],invoke(weight,e));
            q.pushr(v);
          }
        }
      }
    }
    for(int k=1;k<lg;++k)
      nrep(v,n)
        up[k][v]=up[k-1][up[k-1][v]];
  }
  int len()const{return n;}
  bool same(int a,int b)const{return a>=0&&a<n&&b>=0&&b<n&&comp[a]==comp[b];}
  int depth(int v)const{
    npre(v>=0&&v<n);
    return dep[v];
  }
  int jump(int v,int k,int fail=npos)const{
    if(v<0||v>=n||k<0||k>dep[v])
      return fail;
    for(int i=0;k;++i,k>>=1)
      if(k&1)
        v=up[i][v];
    return v;
  }
  int lca(int a,int b,int fail=npos)const{
    if(!same(a,b))
      return fail;
    if(dep[a]<dep[b])
      swap(a,b);
    a=jump(a,dep[a]-dep[b]);
    if(a==b)
      return a;
    for(int k=lg;k--;){
      if(up[k][a]!=up[k][b]){
        a=up[k][a];
        b=up[k][b];
      }
    }
    return up[0][a];
  }
  int operator()(int a,int b)const{
    int c=lca(a,b);
    npre(c!=npos);
    return c;
  }
  W dist(int a,int b,W fail)const{
    int c=lca(a,b);
    if(c==npos)
      return fail;
    if constexpr(integral<W>)
      return ni::icast<W>(__int128_t(dis[a])+dis[b]-2*__int128_t(dis[c]));
    else
      return dis[a]+dis[b]-W{2}*dis[c];
  }
  W dist(int a,int b)const{
    npre(same(a,b));
    return dist(a,b,W{});
  }
  int kth(int a,int b,int k,int fail=npos)const{
    if(k<0)
      return fail;
    int c=lca(a,b);
    if(c==npos)
      return fail;
    int x=dep[a]-dep[c],d=x+dep[b]-dep[c];
    if(k>d)
      return fail;
    return k<=x?jump(a,k):jump(b,d-k);
  }
};

// 43_graph_more
template<ngraph_like G>nvector<int>n01bfs(const G&g,int s){
  int n=ni::gverts(g);
  npre(0<=s&&s<n);
  nvector<int>d(n,npos);
  ndeque<int>q;
  d[s]=0;
  q.pushr(s);
  while(!q.empty()){
    int u=q.popl();
    nfor(e,g.neighbors(u)){
      int v=nedge_to(e),w=int(nedge_weight(e));
      npre(0<=v&&v<n&&(w==0||w==1));
      if(d[v]==npos||d[u]+w<d[v]){
        d[v]=d[u]+w;
        if(w)
          q.pushr(v);
        else
          q.pushl(v);
      }
    }
  }
  return d;
}

template<class W>struct nmst_result{
  W weight{},cost{};
  nvector<pair<int,int>>edges;
  nvector<int>edge;
  int components=0;

  bool connected()const{return components<=1;}
};

template<class D=long long,ngraph_like G>
  requires is_num<D>&&(!same_as<remove_cv_t<D>,bool>)
nmaybe<nmst_result<D>>nprim(const G&g,int root=0){
  int n=ni::gverts(g);
  if(!n)
    return nmst_result<D>{};
  npre(0<=root&&root<n);
  using item=tuple<D,int,int>;
  priority_queue<item,vector<item>,greater<item>>q;
  nvector<unsigned char>used(n);
  nmst_result<D>ans;
  ans.components=n;
  ans.edges.reserve(n-1);
  q.push({D{},root,npos});
  int seen=0;
  while(!q.empty()){
    auto[w,u,p]=q.top();
    q.pop();
    if(used[u])
      continue;
    used[u]=true;
    ++seen;
    if(p!=npos){
      ans.weight=ni::cadd(ans.weight,w);
      ans.cost=ans.weight;
      ans.edges.push(pair{p,u});
      --ans.components;
    }
    nfor(e,g.neighbors(u)){
      int v=nedge_to(e);
      npre(0<=v&&v<n);
      if(!used[v])
        q.push({ni::numcast<D>(nedge_weight(e)),v,u});
    }
  }
  if(seen!=n)
    return{};
  return ans;
}

template<ngraph_like G,class F,class W=uncv<invoke_result_t<F&,ni::gneighbor_t<G>>>>
  requires invocable<F&,ni::gneighbor_t<G>>
nmst_result<W>nkruskal(const G&g,F weight){
  struct E{
    int u,v,id;
    W w;
  };
  int n=ni::gverts(g);
  nvector<E>es;
  auto arcs=narcs(g);
  es.reserve(arcs.len());
  nfor(e,arcs)
    es.push(E{e.from,e.to,e.id,W(invoke(weight,e))});
  nsort(es,[](const E&a,const E&b){return a.w<b.w;});
  ndsu dsu(n);
  nmst_result<W>ans;
  ans.components=n;
  nfor(e,es){
    if(dsu.same(e.u,e.v))
      continue;
    dsu.merge(e.u,e.v);
    if constexpr(is_num<W>)
      ans.weight=ni::cadd(ans.weight,e.w);
    else
      ans.weight+=e.w;
    ans.cost=ans.weight;
    ans.edges.push(pair{e.u,e.v});
    ans.edge.push(e.id);
    --ans.components;
  }
  return ans;
}

template<ngraph_like G>auto nkruskal(const G&g){
  return nkruskal(g,[](const auto&e)->decltype(auto){return nedge_weight(e);});
}

namespace ni{

template<class C>
  requires integral<C>&&(!same_as<remove_cv_t<C>,bool>)
class flow_core{
  struct E{
    int to,rev;
    C cap,init;
  };
  nvector<nvector<E>>g;
  nvector<pair<int,int>>pos;
  nvector<int>level,it;
  bool ran=false;

  bool bfs(int s,int t){
    fill(level.begin(),level.end(),npos);
    ndeque<int>q;
    level[s]=0;
    q.pushr(s);
    while(!q.empty()){
      int u=q.popl();
      nfor(e,g[u]){
        if(e.cap>C{}&&level[e.to]==npos){
          level[e.to]=level[u]+1;
          q.pushr(e.to);
        }
      }
    }
    return level[t]!=npos;
  }

  C dfs(int u,int t,C f){
    if(u==t||f<=C{})
      return f;
    for(int&i=it[u];i<g[u].len();++i){
      E&e=g[u][i];
      if(e.cap<=C{}||level[e.to]!=level[u]+1)
        continue;
      C x=dfs(e.to,t,min(f,e.cap));
      if(x<=C{})
        continue;
      e.cap-=x;
      g[e.to][e.rev].cap=cadd(g[e.to][e.rev].cap,x);
      return x;
    }
    return C{};
  }

public:
  flow_core()=default;
  explicit flow_core(int n,int expected=0):g(n),level(n),it(n){
    npre(n>=0&&expected>=0);
    pos.reserve(expected);
  }

  int len()const{return g.len();}
  int vertices()const{return len();}
  int edges()const{return pos.len();}
  void reserve(int n){
    npre(n>=0);
    pos.reserve(n);
  }

  int add(int u,int v,C cap,C rev=C{}){
    npre(0<=u&&u<len()&&0<=v&&v<len());
    npre(cap>=C{}&&rev>=C{});
    int id=pos.len(),a=g[u].len(),b=g[v].len();
    pos.push(pair{u,a});
    g[u].push(E{v,b,cap,cap});
    g[v].push(E{u,a,rev,rev});
    return id;
  }

  C flow(int s,int t,C limit=limits<C>::max()){
    npre(0<=s&&s<len()&&0<=t&&t<len()&&s!=t);
    npre(limit>=C{});
    C total{};
    nfor(e,g[s]){
      total=cadd(total,e.cap);
    }
    (void)total;
    ran=true;
    C ans{};
    while(ans<limit&&bfs(s,t)){
      fill(it.begin(),it.end(),0);
      while(ans<limit){
        C x=dfs(s,t,limit-ans);
        if(x<=C{})
          break;
        ans=cadd(ans,x);
      }
    }
    return ans;
  }

  C operator()(int s,int t,C limit=limits<C>::max()){return flow(s,t,limit);}

  C used(int id)const{
    npre(0<=id&&id<pos.len());
    auto[u,i]=pos[id];
    return g[u][i].init-g[u][i].cap;
  }

  nvector<unsigned char>cut(int s)const{
    npre(0<=s&&s<len());
    nvector<unsigned char>seen(len());
    ndeque<int>q;
    seen[s]=true;
    q.pushr(s);
    while(!q.empty()){
      int u=q.popl();
      nfor(e,g[u]){
        if(e.cap>C{}&&!seen[e.to]){
          seen[e.to]=true;
          q.pushr(e.to);
        }
      }
    }
    return seen;
  }

  nvector<unsigned char>mincut(int s)const{
    npre(ran);
    return cut(s);
  }

  void reset(){
    nfor(a,g){
      nfor(e,a){
      e.cap=e.init;
    }
    }
    ran=false;
  }
};

}// namespace ni

template<class C>
  requires integral<C>&&(!same_as<remove_cv_t<C>,bool>)
using nflow_dinic=ni::flow_core<C>;

template<class C>using nmaxflow=nflow_dinic<C>;

template<class C>using nflow=nflow_dinic<C>;

// 44_matching
struct nbipartite_matching{
  int size=0;
  nvector<int>left,right;
};

template<ngraph_like G>nbipartite_matching nhopcroft_karp(const G&g,int nr){
  int nl=ni::gverts(g);
  npre(nr>=0);
  nbipartite_matching m{0,nvector<int>(nl,npos),nvector<int>(nr,npos)};
  nvector<int>d(nl);
  for(;;){
    fill(d.begin(),d.end(),npos);
    ndeque<int>q;
    for(int u=0;u<nl;++u){
      if(m.left[u]==npos){
        d[u]=0;
        q.pushr(u);
      }
    }
    bool path=false;
    while(!q.empty()){
      int u=q.popl();
      nfor(e,g.neighbors(u)){
        int v=nedge_to(e);
        npre(0<=v&&v<nr);
        int x=m.right[v];
        if(x==npos)
          path=true;
        else if(d[x]==npos){
          d[x]=d[u]+1;
          q.pushr(x);
        }
      }
    }
    if(!path)
      return m;
    auto dfs=[&](auto&&self,int u)->bool{
      nfor(e,g.neighbors(u)){
        int v=nedge_to(e),x=m.right[v];
        npre(0<=v&&v<nr);
        if(x!=npos&&(d[x]!=d[u]+1||!self(self,x)))
          continue;
        m.left[u]=v;
        m.right[v]=u;
        return true;
      }
      d[u]=npos;
      return false;
    };
    int add=0;
    for(int u=0;u<nl;++u)
      add+=m.left[u]==npos&&dfs(dfs,u);
    if(!add)
      return m;
    m.size+=add;
  }
}

struct nbicover{
  nvector<int>l,r;
};

class nbimatch_hopcroft{
  int nl=0,nr=0;
  nvector<nvector<int>>adj;
  nvector<int>lm,rm;
  bool solved=false;

public:
  nbimatch_hopcroft()=default;
  nbimatch_hopcroft(int l,int r):nl(l),nr(r),adj(l),lm(l,npos),rm(r,npos){npre(l>=0&&r>=0);}

  int add(int l,int r){
    npre(0<=l&&l<nl&&0<=r&&r<nr);
    solved=false;
    adj[l].push(r);
    return adj[l].len()-1;
  }

  int solve(){
    auto g=ngraph_view(nl,[&](int u)->const nvector<int>&{return adj[u];});
    auto m=nhopcroft_karp(g,nr);
    lm=move(m.left);
    rm=move(m.right);
    solved=true;
    return m.size;
  }

  int left(int u,int fallback=npos)const{
    npre(0<=u&&u<nl);
    return lm[u]==npos?fallback:lm[u];
  }

  int right(int v,int fallback=npos)const{
    npre(0<=v&&v<nr);
    return rm[v]==npos?fallback:rm[v];
  }

  nvector<pair<int,int>>pairs()const{
    npre(solved);
    nvector<pair<int,int>>a;
    for(int u=0;u<nl;++u)
      if(lm[u]!=npos)
        a.push(pair{u,lm[u]});
    return a;
  }

  nbicover mincover()const{
    npre(solved);
    nvector<unsigned char>sl(nl),sr(nr);
    ndeque<int>q;
    for(int u=0;u<nl;++u){
      if(lm[u]==npos){
        sl[u]=true;
        q.pushr(u);
      }
    }
    while(!q.empty()){
      int u=q.popl();
      nfor(v,adj[u]){
        if(lm[u]==v||sr[v])
          continue;
        sr[v]=true;
        int x=rm[v];
        if(x!=npos&&!sl[x]){
          sl[x]=true;
          q.pushr(x);
        }
      }
    }
    nbicover a;
    for(int u=0;u<nl;++u)
      if(!sl[u])
        a.l.push(u);
    for(int v=0;v<nr;++v)
      if(sr[v])
        a.r.push(v);
    return a;
  }
};

using nbimatch=nbimatch_hopcroft;

// 50_integer
template<class T>
concept ninteger=integral<T>&&(!same_as<remove_cv_t<T>,bool>);
template<ninteger T>constexpr uint_t<T>nmag(T x){
  using U=uint_t<T>;
  return is_signed_v<T>&&x<0?U{}-U(x):U(x);
}
template<ninteger T>constexpr uint_t<T>nabs(T x){
  return nmag(x);
}
template<ninteger T>constexpr uint_t<T>ngcd_euclid(T a,T b){
  auto x=nmag(a),y=nmag(b);
  while(y){
    auto z=x%y;
    x=y;
    y=z;
  }
  return x;
}
template<ninteger T>constexpr uint_t<T>ngcd(T a,T b){
  return ngcd_euclid(a,b);
}
template<ninteger T>constexpr uint_t<T>nlcm(T a,T b){
  using U=uint_t<T>;
  U x=nmag(a),y=nmag(b);
  if(!x||!y)
    return 0;
  x/=ngcd(a,b);
  npre(x<=limits<U>::max()/y);
  return x*y;
}
template<sint T>constexpr T nfloor_div(T a,T b){
  npre(b&&!(a==limits<T>::lowest()&&b==-1));
  T q=a/b,r=a%b;
  return q-(r&&((r<0)!=(b<0)));
}
template<sint T>constexpr T nceil_div(T a,T b){
  npre(b&&!(a==limits<T>::lowest()&&b==-1));
  T q=a/b,r=a%b;
  return q+(r&&((r<0)==(b<0)));
}
template<sint T>constexpr T nmodulo(T x,T m){
  npre(m>0);
  x%=m;
  return x<0?x+m:x;
}

template<ninteger T>
  requires(sizeof(T)<=8)
struct nextgcd_result{
  uint_t<T>gcd;
  __int128_t x,y;
};
template<ninteger T>
  requires(sizeof(T)<=8)
constexpr nextgcd_result<T>nextgcd(T a,T b){
  using U=uint_t<T>;
  U r=nmag(a),s=nmag(b);
  __int128 x=1,y=0,u=0,v=1;
  while(s){
    U q=r/s,z=r%s;
    r=s;
    s=z;
    auto nx=x-__int128(q)*u,ny=y-__int128(q)*v;
    x=u;
    u=nx;
    y=v;
    v=ny;
  }
  if constexpr(is_signed_v<T>){
    if(a<0)
      x=-x;
    if(b<0)
      y=-y;
  }
  return{r,x,y};
}
constexpr uint64_t nmulmod(uint64_t a,uint64_t b,uint64_t m){
  npre(m);
  return uint64_t(__uint128_t(a)*b%m);
}
constexpr uint64_t npowmod(uint64_t a,uint64_t e,uint64_t m){
  npre(m);
  uint64_t r=1%m;
  for(a%=m;e;e>>=1,a=nmulmod(a,a,m))
    if(e&1)
      r=nmulmod(r,a,m);
  return r;
}
constexpr bool nisprime(uint64_t n){
  if(n<2)
    return false;
  for(uint64_t p:{2ULL,3ULL,5ULL,7ULL,11ULL,13ULL,17ULL,19ULL,23ULL,29ULL,31ULL,37ULL})
    if(n%p==0)
      return n==p;
  uint64_t d=n-1;
  int s=countr_zero(d);
  d>>=s;
  for(uint64_t a:{2ULL,325ULL,9375ULL,28178ULL,450775ULL,9780504ULL,1795265022ULL})
    if(a%n){
      uint64_t x=npowmod(a,d,n);
      if(x==1||x==n-1)
        continue;
      int r=1;
      while(r<s&&(x=nmulmod(x,x,n))!=n-1)
        ++r;
      if(r==s)
        return false;
    }
  return true;
}
constexpr bool nisprime_miller(uint64_t n){
  return nisprime(n);
}
inline bool nisprime_trial(uint64_t n){
  if(n<2)
    return false;
  for(uint64_t d=2;d<=n/d;++d)
    if(n%d==0)
      return false;
  return true;
}
inline uint64_t npollard(uint64_t n){
  npre(n>1&&!nisprime(n));
  if(!(n&1))
    return 2;
  if(n%3==0)
    return 3;
  auto f=[n](uint64_t x,uint64_t c){
    return uint64_t((__uint128_t(x)*x+c)%n);
  };
  for(;;){
    uint64_t y=nrng_global(uint64_t(1),n),c=nrng_global(uint64_t(1),n),g=1,r=1,q=1,x=0,ys=0;
    while(g==1){
      x=y;
      nrep(i,r){
        y=f(y,c);
      }
      for(uint64_t k=0;k<r&&g==1;k+=128){
        ys=y;
        for(uint64_t i=0;i<min<uint64_t>(128,r-k);++i){
          y=f(y,c);
          q=nmulmod(q,x>y?x-y:y-x,n);
        }
        g=gcd(q,n);
      }
      r<<=1;
    }
    if(g==n)
      do{
        ys=f(ys,c);
        g=gcd(x>ys?x-ys:ys-x,n);
      }while(g==1);
    if(g!=n)
      return g;
  }
}
inline nvector<uint64_t>nfactor(uint64_t n){
  nvector<uint64_t>a,q;
  if(n>1)
    q.push(n);
  while(!q.empty()){
    uint64_t x=q.pop();
    if(nisprime(x))
      a.push(x);
    else{
      uint64_t d=npollard(x);
      q.push(d);
      q.push(x/d);
    }
  }
  nsort(a);
  return a;
}
inline nvector<uint64_t>nfactor_rho(uint64_t n){
  return nfactor(n);
}

class nprime_table{
public:
  int n=0;
  nvector<int>p,lp,phi,mu;
  nprime_table()=default;
  explicit nprime_table(int z):n(z),lp(z+1),phi(z+1),mu(z+1){
    npre(0<=z&&z<INT_MAX);
    if(z)
      phi[1]=mu[1]=1;
    for(int x=2;x<=z;++x){
      if(!lp[x]){
        lp[x]=x;
        p.push(x);
        phi[x]=x-1;
        mu[x]=-1;
      }
      nfor(d,p){
        if(d>lp[x]||1LL*x*d>z)
          break;
        int y=x*d;
        lp[y]=d;
        if(d==lp[x]){
          phi[y]=phi[x]*d;
          mu[y]=0;
        }else{
          phi[y]=phi[x]*(d-1);
          mu[y]=-mu[x];
        }
      }
    }
  }
  bool isprime(int x)const{return 2<=x&&x<=n&&lp[x]==x;}
  nvector<pair<int,int>>factor(int x)const{
    npre(0<x&&x<=n);
    nvector<pair<int,int>>a;
    while(x>1){
      int d=lp[x],e=0;
      do{
        x/=d;
        ++e;
      }while(x>1&&lp[x]==d);
      a.push(pair<int,int>{d,e});
    }
    return a;
  }
  nvector<int>divisors(int x)const{
    nvector<int>a{1};
    nfor(pe,factor(x)){
      int z=a.len(),pw=1;
      for(int e=1;e<=pe.second;++e){
        pw*=pe.first;
        nrep(i,z)
          a.push(a[i]*pw);
      }
    }
    nsort(a);
    return a;
  }
};
inline nvector<int>nprimes(int n){
  return nprime_table(n).p;
}

template<sint T=long long>class nfrac{
  using W=nwide_t<T>;
  using U=uint_t<W>;
  static U mag(W x){return x<0?U{}-U(x):U(x);}
  static U gcd0(U a,U b){
    while(b){
      U c=a%b;
      a=b;
      b=c;
    }
    return a;
  }
  static T narrow(W x){return ni::icast<T>(x);}
  void set(W a,W b){
    npre(b);
    U d=gcd0(mag(a),mag(b));
    a/=W(d);
    b/=W(d);
    if(b<0){
      npre(a!=limits<W>::lowest());
      a=-a;
      b=-b;
    }
    p=narrow(a);
    q=narrow(b);
  }

public:
  T p=0,q=1;
  constexpr nfrac()=default;
  constexpr nfrac(T x):p(x){}
  nfrac(T a,T b){set(W(a),W(b));}
  nfrac&operator+=(const nfrac&b){
    U d=gcd0(U(q),U(b.q));
    W x=W(b.q)/W(d),y=W(q)/W(d),u,v,num,den;
    npre(!__builtin_mul_overflow(W(p),x,&u));
    npre(!__builtin_mul_overflow(W(b.p),y,&v));
    npre(!__builtin_add_overflow(u,v,&num));
    npre(!__builtin_mul_overflow(y,W(b.q),&den));
    set(num,den);
    return*this;
  }
  nfrac&operator-=(const nfrac&b){return*this+=-b;}
  nfrac&operator*=(const nfrac&b){
    U x=gcd0(mag(W(p)),U(b.q)),y=gcd0(mag(W(b.p)),U(q));
    W num,den;
    npre(!__builtin_mul_overflow(W(p)/W(x),W(b.p)/W(y),&num));
    npre(!__builtin_mul_overflow(W(q)/W(y),W(b.q)/W(x),&den));
    set(num,den);
    return*this;
  }
  nmaybe<nfrac>trydiv(const nfrac&b)const{
    if(!b.p)
      return{};
    nfrac a=*this;
    a*=nfrac(b.q,b.p);
    return a;
  }
  nfrac&operator/=(const nfrac&b){
    auto a=trydiv(b);
    npre(a.ok());
    return*this=move(a.val());
  }
  nfrac operator+()const{return*this;}
  nfrac operator-()const{
    npre(p!=limits<T>::lowest());
    return{-p,q};
  }
  friend nfrac operator+(nfrac a,const nfrac&b){return a+=b;}
  friend nfrac operator-(nfrac a,const nfrac&b){return a-=b;}
  friend nfrac operator*(nfrac a,const nfrac&b){return a*=b;}
  friend nfrac operator/(nfrac a,const nfrac&b){return a/=b;}
  friend bool operator==(const nfrac&,const nfrac&)=default;
  friend strong_ordering operator<=>(const nfrac&a,const nfrac&b){
    W x=W(a.p)*b.q,y=W(b.p)*a.q;
    return x<y?strong_ordering::less:x>y?strong_ordering::greater:strong_ordering::equal;
  }
  T floor()const{return nfloor_div(p,q);}
  T ceil()const{return nceil_div(p,q);}
  explicit operator long double()const{return(long double)p/q;}
  friend ostream&operator<<(ostream&out,const nfrac&x){return out<<x.p<<'/'<<x.q;}
};

struct ncongruence{
  long long a=0,m=1;
  ncongruence()=default;
  ncongruence(long long x,long long mod):a(nmodulo(x,mod)),m(mod){npre(mod>0);}
  bool has(long long x)const{return(__int128_t(x)-a)%m==0;}
  nmaybe<long long>at(long long i)const{
    __int128_t x=__int128_t(a)+__int128_t(i)*m;
    return x<LLONG_MIN||x>LLONG_MAX?nmaybe<long long>{}:nmaybe<long long>(static_cast<long long>(x));
  }
  long long at(long long i,long long f)const{
    auto x=at(i);
    return x?x.val():f;
  }
  long long operator()(long long i)const{
    auto x=at(i);
    npre(x.ok());
    return x.val();
  }
  friend bool operator==(const ncongruence&,const ncongruence&)=default;
};
inline nmaybe<ncongruence>ncrt(ncongruence a,ncongruence b){
  auto e=nextgcd(a.m,b.m);
  __int128 d=__int128_t(b.a)-a.a;
  if(d%e.gcd)
    return{};
  __int128 m=__int128_t(a.m/e.gcd)*b.m;
  if(m>LLONG_MAX)
    return{};
  __int128 k=d/e.gcd*e.x%(b.m/e.gcd),x=(a.a+__int128_t(a.m)*k)%m;
  if(x<0)
    x+=m;
  return ncongruence(static_cast<long long>(x),static_cast<long long>(m));
}
inline ncongruence ncrt(ncongruence a,ncongruence b,ncongruence f){
  auto x=ncrt(a,b);
  return x?x.val():move(f);
}

// 51_modular
namespace ni{
template<class D>class modops{
protected:
  uint64_t v_=0;
  template<integral I>static constexpr uint64_t norm(I x){
    uint64_t m=D::mod();
    if constexpr(is_signed_v<I>){
      __int128 r=__int128(x)%m;
      return uint64_t(r<0?r+m:r);
    }else
      return uint64_t(__uint128_t(x)%m);
  }
  constexpr D&self(){return static_cast<D&>(*this);}
  constexpr const D&self()const{return static_cast<const D&>(*this);}

public:
  constexpr modops()=default;
  template<integral I>constexpr modops(I x):v_(norm(x)){}
  static constexpr D raw(uint64_t x){
    npre(x<D::mod());
    D a;
    a.v_=x;
    return a;
  }
  constexpr uint64_t val()const{return v_;}
  constexpr explicit operator uint64_t()const{return v_;}
  constexpr D&operator+=(D b){
    __uint128_t x=__uint128_t(v_)+b.v_;
    v_=uint64_t(x>=D::mod()?x-D::mod():x);
    return self();
  }
  constexpr D&operator-=(D b){
    v_=v_>=b.v_?v_-b.v_:D::mod()-(b.v_-v_);
    return self();
  }
  constexpr D&operator*=(D b){
    v_=nmulmod(v_,b.v_,D::mod());
    return self();
  }
  constexpr D pow(uint64_t e)const{return raw(npowmod(v_,e,D::mod()));}
  constexpr nmaybe<D>inverse()const{
    if(!v_)
      return{};
    auto e=nextgcd(D::mod(),v_);
    if(e.gcd!=1)
      return{};
    __int128 x=e.y%__int128(D::mod());
    if(x<0)
      x+=D::mod();
    return raw(uint64_t(x));
  }
  constexpr nmaybe<D>tryinv()const{return inverse();}
  constexpr D inv()const{
    auto x=inverse();
    npre(x.ok());
    return x.val();
  }
  constexpr D inv(D f)const{
    auto x=inverse();
    return x?x.val():move(f);
  }
  constexpr D&operator/=(D b){return*this*=b.inv();}
  constexpr D operator+()const{return self();}
  constexpr D operator-()const{return v_?raw(D::mod()-v_):self();}
  constexpr D&operator++(){return*this+=D(1);}
  constexpr D&operator--(){return*this-=D(1);}
  constexpr D operator++(int){
    D x=self();
    ++*this;
    return x;
  }
  constexpr D operator--(int){
    D x=self();
    --*this;
    return x;
  }
  friend constexpr D operator+(D a,D b){return a+=b;}
  friend constexpr D operator-(D a,D b){return a-=b;}
  friend constexpr D operator*(D a,D b){return a*=b;}
  friend constexpr D operator/(D a,D b){return a/=b;}
  friend constexpr bool operator==(const modops&,const modops&)=default;
  friend ostream&operator<<(ostream&o,D x){return o<<x.v_;}
  friend istream&operator>>(istream&i,D&x){
    long long v;
    i>>v;
    x=D(v);
    return i;
  }
};
}// namespace ni
template<uint64_t M>
  requires(M>0)
class nmodint:public ni::modops<nmodint<M>>{
  using B=ni::modops<nmodint<M>>;
  friend B;

public:
  using B::B;
  static constexpr uint64_t mod(){return M;}
};
template<int Tag=0>class nmod_dynamic:public ni::modops<nmod_dynamic<Tag>>{
  using B=ni::modops<nmod_dynamic<Tag>>;
  friend B;
  static inline uint64_t m_=1;

public:
  using B::B;
  static uint64_t mod(){return m_;}
  static void setmod(uint64_t m){
    npre(0<m&&m<=uint64_t(INT64_MAX));
    m_=m;
  }
};
template<uint64_t M>using nmod_static=nmodint<M>;
template<uint64_t M>using nmod=nmodint<M>;
template<int T=0>using ndmod=nmod_dynamic<T>;
template<int T>inline constexpr bool nadd_group<nmod_dynamic<T>> = true;
template<int T>
inline constexpr bool nsemiring_laws<nadd<nmod_dynamic<T>>,nmul<nmod_dynamic<T>>,nmod_dynamic<T>> = true;
template<int T>
inline constexpr bool naction_laws<naddsum_action<nmod_dynamic<T>>,nmod_dynamic<T>,nmod_dynamic<T>> = true;
template<uint64_t M>inline constexpr bool nadd_group<nmodint<M>> = true;
template<uint64_t M>inline constexpr bool nexact_field<nmodint<M>> = nisprime(M);
template<uint64_t M>inline constexpr bool nsemiring_laws<nadd<nmodint<M>>,nmul<nmodint<M>>,nmodint<M>> = true;
template<uint64_t M>inline constexpr bool naction_laws<naddsum_action<nmodint<M>>,nmodint<M>,nmodint<M>> = true;

template<class Mint>class ncomb{
  nvector<Mint>f_,g_;

public:
  explicit ncomb(int n=0):f_(n+1),g_(n+1){
    npre(0<=n&&n<INT_MAX);
    f_[0]=1;
    for(int i=1;i<=n;++i)
      f_[i]=f_[i-1]*Mint(i);
    g_[n]=f_[n].inv();
    for(int i=n;i;--i)
      g_[i-1]=g_[i]*Mint(i);
  }
  int len()const{return f_.len()-1;}
  Mint factorial(int n)const{
    npre(0<=n&&n<=len());
    return f_[n];
  }
  Mint choose(int n,int k)const{
    npre(0<=n&&n<=len());
    return k<0||n<k?Mint{}:f_[n]*g_[k]*g_[n-k];
  }
  Mint permute(int n,int k)const{
    npre(0<=n&&n<=len());
    return k<0||n<k?Mint{}:f_[n]*g_[n-k];
  }
};

// 52_comb
template<uintg T>
  requires(!same_as<remove_cv_t<T>,bool>)
class nsubmask_range{
  T m_{};

public:
  explicit constexpr nsubmask_range(T m):m_(m){npre(popcount(m)<=30);}
  constexpr int len()const{return int(T(1)<<popcount(m_));}
  constexpr bool empty()const{return false;}
  struct cursor{
    T m{},x{};
    int i=0;
    bool on=true;
    constexpr bool ok()const{return on;}
    constexpr T val()const{return x;}
    constexpr int idx()const{return i;}
    constexpr void next(){
      if(!x)
        on=false;
      else
        x=(x-1)&m;
      ++i;
    }
  };
  constexpr cursor enumerate()const{return{m_,m_};}
};
template<uintg T>
  requires(!same_as<remove_cv_t<T>,bool>)
constexpr auto nsubmasks(T m){
  return nsubmask_range<T>(m);
}
namespace ni{
template<class A>constexpr void nsubset_extent(const A&a){
  int n=nlen(a);
  npre(n>0&&has_single_bit(unsigned(n)));
}
template<bool Sup,bool Inv,class A>void subset_tf(A&&a){
  nsubset_extent(a);
  for(int b=1;b<nlen(a);b<<=1){
    nrep(m,nlen(a)){
      if(bool(m&b)!=Sup){
        if constexpr(Inv)
          a[m]-=a[m^b];
        else
          a[m]+=a[m^b];
      }
    }
  }
}
}// namespace ni
template<class A>
  requires nviewable<A&&>&&nreference_indexed<rmref<A>>&&
           requires(nref_t<rmref<A>>x,nvalue_t<rmref<A>>y){x+=y;}
void nzeta_subset(A&&a){
  ni::subset_tf<false,false>(a);
}
template<class A>
  requires nviewable<A&&>&&nreference_indexed<rmref<A>>&&
           requires(nref_t<rmref<A>>x,nvalue_t<rmref<A>>y){x-=y;}
void nmobius_subset(A&&a){
  ni::subset_tf<false,true>(a);
}
template<class A>
  requires nviewable<A&&>&&nreference_indexed<rmref<A>>&&
           requires(nref_t<rmref<A>>x,nvalue_t<rmref<A>>y){x+=y;}
void nzeta_superset(A&&a){
  ni::subset_tf<true,false>(a);
}
template<class A>
  requires nviewable<A&&>&&nreference_indexed<rmref<A>>&&
           requires(nref_t<rmref<A>>x,nvalue_t<rmref<A>>y){x-=y;}
void nmobius_superset(A&&a){
  ni::subset_tf<true,true>(a);
}
template<class A>
  requires nviewable<A&&>&&nreference_indexed<rmref<A>>&&
           requires(nvalue_t<rmref<A>>x,nref_t<rmref<A>>y,int n){
             y=x+x;
             y=x-x;
             y/=n;
           }
void nfwht_xor(A&&a,bool inv=false){
  ni::nsubset_extent(a);
  for(int w=1;w<nlen(a);w<<=1)
    for(int l=0;l<nlen(a);l+=w<<1)
      nrep(i,w){
        auto x=a[l+i],y=a[l+w+i];
        a[l+i]=x+y;
        a[l+w+i]=x-y;
      }
  if(inv)
    nrep(i,nlen(a))
      a[i]/=nlen(a);
}
namespace ni{
template<int Kind,nindexed A,nindexed B>auto nbitconv(const A&a,const B&b){
  npre(nlen(a)==nlen(b));
  auto x=ncollect(a),y=ncollect(b);
  if constexpr(Kind==0){
    nzeta_subset(x);
    nzeta_subset(y);
  }else if constexpr(Kind==1){
    nzeta_superset(x);
    nzeta_superset(y);
  }else{
    nfwht_xor(x);
    nfwht_xor(y);
  }
  nrep(i,x.len())
    x[i]*=y[i];
  if constexpr(Kind==0)
    nmobius_subset(x);
  else if constexpr(Kind==1)
    nmobius_superset(x);
  else
    nfwht_xor(x,true);
  return x;
}
}// namespace ni
template<nindexed A,nindexed B>auto nconv_or(const A&a,const B&b){
  return ni::nbitconv<0>(a,b);
}
template<nindexed A,nindexed B>auto nconv_and(const A&a,const B&b){
  return ni::nbitconv<1>(a,b);
}
template<nindexed A,nindexed B>auto nconv_xor(const A&a,const B&b){
  return ni::nbitconv<2>(a,b);
}

// 53_linear
template<class T>class nmatrix{
  int r_=0,c_=0;
  nvector<T>a_;
  static int vol(int r,int c){
    npre(r>=0&&c>=0&&(r==0||c<=INT_MAX/r));
    return r*c;
  }

public:
  using value_type=T;
  nmatrix()=default;
  nmatrix(int r,int c):r_(r),c_(c),a_(vol(r,c)){}
  nmatrix(int r,int c,const T&x):r_(r),c_(c),a_(vol(r,c),x){}
  nmatrix(initializer_list<initializer_list<T>>rows){
    npre(rows.size()<=size_t(INT_MAX));
    r_=int(rows.size());
    c_=r_?int(rows.begin()->size()):0;
    a_.reserve(vol(r_,c_));
    for(auto&row:rows){
      npre(row.size()==size_t(c_));
      for(auto&x:row)
        a_.push(x);
    }
  }
  int rows()const{return r_;}
  int cols()const{return c_;}
  int len()const{return a_.len();}
  bool empty()const{return a_.empty();}
  T*data(){return a_.data();}
  const T*data()const{return a_.data();}
  T*row_data(int i){
    npre(0<=i&&i<r_);
    return c_?a_.data()+ptrdiff_t(i)*c_:a_.data();
  }
  const T*row_data(int i)const{
    npre(0<=i&&i<r_);
    return c_?a_.data()+ptrdiff_t(i)*c_:a_.data();
  }
  T&operator[](int i){return a_[i];}
  const T&operator[](int i)const{return a_[i];}
  T&operator()(int i,int j){
    npre(0<=i&&i<r_&&0<=j&&j<c_);
    return a_[i*c_+j];
  }
  const T&operator()(int i,int j)const{
    npre(0<=i&&i<r_&&0<=j&&j<c_);
    return a_[i*c_+j];
  }
  auto view()&{return nview(data(),r_,c_);}
  auto view()const&{return nview(data(),r_,c_);}
  auto view()&&=delete;
  auto row(int i)&{return nrow(view(),i);}
  auto row(int i)const&{return nrow(view(),i);}
  auto row(int)&&=delete;
  auto column(int i)&{return ncolumn(view(),i);}
  auto column(int i)const&{return ncolumn(view(),i);}
  auto column(int)&&=delete;
  auto diagonal(int d=0)&{return ndiagonal(view(),d);}
  auto diagonal(int d=0)const&{return ndiagonal(view(),d);}
  auto diagonal(int=0)&&=delete;
  friend bool operator==(const nmatrix&,const nmatrix&)=default;
};
template<class A>
concept nmatrix_like=requires(const A&a){
  {a.rows()}->same_as<int>;
  {a.cols()}->same_as<int>;
  a(0,0);
};

template<class T,class Add=nadd<T>,class Mul=nmul<T>>
  requires nsemiring<Add,Mul,T>
nmatrix<T>nmatrix_identity(int n,Add add={},Mul mul={}){
  nmatrix<T>a(n,n,add.id());
  nrep(i,n)
    a(i,i)=mul.id();
  return a;
}

template<nmatrix_like A,nmatrix_like B,class T=uncv<decltype(declval<const A&>()(0,0))>,
    class Add=nadd<T>,class Mul=nmul<T>>
  requires same_as<T,uncv<decltype(declval<const B&>()(0,0))>>&&nsemiring<Add,Mul,T>
auto nmatmul(const A&a,const B&b,Add add={},Mul mul={}){
  npre(a.cols()==b.rows());
  nmatrix<T>c(a.rows(),b.cols(),add.id());
  nrep(i,a.rows())
    nrep(k,a.cols())
      nrep(j,b.cols())
        c(i,j)=add(move(c(i,j)),mul(a(i,k),b(k,j)));
  return c;
}

template<class T,class Add=nadd<T>,class Mul=nmul<T>>
  requires nsemiring<Add,Mul,T>
nmatrix<T>nmatpow(nmatrix<T>a,uint64_t e,Add add={},Mul mul={}){
  npre(a.rows()==a.cols());
  auto r=nmatrix_identity<T>(a.rows(),add,mul);
  for(;e;e>>=1){
    if(e&1)
      r=nmatmul(r,a,add,mul);
    if(e>>1)
      a=nmatmul(a,a,add,mul);
  }
  return r;
}

template<class T,class Add=nadd<T>,class Mul=nmul<T>>
  requires nmonoid<Add,T>&&nmonoid<Mul,T>
class nmat:public nmatrix<T>{
  using B=nmatrix<T>;

public:
  using B::B;
  nmat()=default;
  nmat(B x):B(move(x)){}
  static nmat eye(int n){return nmat(nmatrix_identity<T>(n,Add{},Mul{}));}
  T get(int i,int j,T f=Add{}.id())const{
    return 0<=i&&i<this->rows()&&0<=j&&j<this->cols()?(*this)(i,j):move(f);
  }
  nmat&operator+=(const nmat&b){
    npre(this->rows()==b.rows()&&this->cols()==b.cols());
    Add add;
    nrep(i,this->len())
      (*this)[i]=add(move((*this)[i]),b[i]);
    return*this;
  }
  friend nmat operator+(nmat a,const nmat&b){return a+=b;}
  friend nmat operator*(const nmat&a,const nmat&b){return nmat(nmatmul(a,b,Add{},Mul{}));}
  nmat&operator*=(const nmat&b){return*this=*this*b;}
  nmat pow(long long e)const{
    npre(e>=0);
    return nmat(nmatpow(B(*this),uint64_t(e),Add{},Mul{}));
  }
  nmat trans()const{
    nmat a(this->cols(),this->rows(),Add{}.id());
    nrep(i,this->rows())
      nrep(j,this->cols())
        a(j,i)=(*this)(i,j);
    return a;
  }
  friend bool operator==(const nmat&a,const nmat&b){
    return static_cast<const B&>(a)==static_cast<const B&>(b);
  }
};

template<nfield T>int nrref(nmatrix<T>&a,nvector<int>*p=nullptr){
  if(p)
    p->clear();
  int rank=0;
  for(int j=0;j<a.cols()&&rank<a.rows();++j){
    int q=rank;
    while(q<a.rows()&&a(q,j)==T{})
      ++q;
    if(q==a.rows())
      continue;
    if(q!=rank){
      nrep(k,a.cols())
        swap(a(rank,k),a(q,k));
    }
    T inv=T{1}/a(rank,j);
    for(int k=j;k<a.cols();++k)
      a(rank,k)*=inv;
    nrep(i,a.rows()){
      if(i!=rank&&a(i,j)!=T{}){
        T x=a(i,j);
        for(int k=j;k<a.cols();++k)
          a(i,k)-=x*a(rank,k);
      }
    }
    if(p)
      p->push(j);
    ++rank;
  }
  return rank;
}
template<nfield T>T ndeterminant(nmatrix<T>a){
  npre(a.rows()==a.cols());
  T ans{1};
  nrep(j,a.cols()){
    int q=j;
    while(q<a.rows()&&a(q,j)==T{})
      ++q;
    if(q==a.rows())
      return T{};
    if(q!=j){
      for(int k=j;k<a.cols();++k)
        swap(a(j,k),a(q,k));
      ans=-ans;
    }
    T x=a(j,j);
    ans*=x;
    for(int i=j+1;i<a.rows();++i){
      T y=a(i,j)/x;
      for(int k=j;k<a.cols();++k)
        a(i,k)-=y*a(j,k);
    }
  }
  return ans;
}
template<nfield T>T ndet(nmatrix<T>a){
  return ndeterminant(move(a));
}
template<nfield T>nmaybe<nmatrix<T>>ninverse(nmatrix<T>a){
  npre(a.rows()==a.cols());
  int n=a.rows();
  npre(n<=INT_MAX/2);
  nmatrix<T>b(n,2*n);
  nrep(i,n){
    nrep(j,n)
      b(i,j)=a(i,j);
    b(i,n+i)=T{1};
  }
  nrref(b);
  nrep(i,n){
    nrep(j,n){
      if(b(i,j)!=T(i==j))
        return{};
    }
  }
  nmatrix<T>r(n,n);
  nrep(i,n)
    nrep(j,n)
      r(i,j)=b(i,n+j);
  return r;
}
template<nfield T>nmatrix<T>ninverse(nmatrix<T>a,nmatrix<T>f){
  auto x=ninverse(move(a));
  return x?move(x.val()):move(f);
}
template<nfield T,class A,class M>T ndet(nmat<T,A,M>a){
  return ndeterminant(nmatrix<T>(move(a)));
}
template<nfield T,class A,class M>nmaybe<nmat<T,A,M>>ninverse(nmat<T,A,M>a){
  auto x=ninverse(nmatrix<T>(move(a)));
  return x?nmaybe<nmat<T,A,M>>(nmat<T,A,M>(move(x.val()))):nmaybe<nmat<T,A,M>>{};
}
template<nfield T,class A,class M>nmat<T,A,M>ninverse(nmat<T,A,M>a,nmat<T,A,M>f){
  auto x=ninverse(move(a));
  return x?move(x.val()):move(f);
}

template<class T>struct nlinear_solution{
  bool consistent=true;
  int rank=0;
  nvector<T>particular,one;
  nvector<nvector<T>>basis;
};
template<nfield T,nindexed B>nlinear_solution<T>ngauss(nmatrix<T>a,const B&v){
  npre(a.rows()==nlen(v));
  int r=a.rows(),c=a.cols(),rank=0;
  nvector<T>b=ncollect<T>(v);
  nvector<int>row(c,npos);
  for(int j=0;j<c&&rank<r;++j){
    int q=rank;
    while(q<r&&a(q,j)==T{})
      ++q;
    if(q==r)
      continue;
    if(q!=rank){
      for(int k=j;k<c;++k)
        swap(a(rank,k),a(q,k));
      swap(b[rank],b[q]);
    }
    T inv=T{1}/a(rank,j);
    for(int k=j;k<c;++k)
      a(rank,k)*=inv;
    b[rank]*=inv;
    nrep(i,r){
      if(i!=rank&&a(i,j)!=T{}){
        T x=a(i,j);
        for(int k=j;k<c;++k)
          a(i,k)-=x*a(rank,k);
        b[i]-=x*b[rank];
      }
    }
    row[j]=rank++;
  }
  nlinear_solution<T>x;
  x.rank=rank;
  for(int i=rank;i<r;++i)
    if(b[i]!=T{}){
      x.consistent=false;
      return x;
    }
  x.particular=nvector<T>(c);
  nrep(j,c)
    if(row[j]!=npos)
      x.particular[j]=b[row[j]];
  nrep(f,c){
    if(row[f]==npos){
      nvector<T>z(c);
      z[f]=T{1};
      nrep(j,c)
        if(row[j]!=npos)
          z[j]=-a(row[j],f);
      x.basis.push(move(z));
    }
  }
  x.one=x.particular;
  return x;
}
template<nfield T,nindexed B>nmaybe<nlinear_solution<T>>nlinear_solve(nmatrix<T>a,const B&b){
  npre(a.cols()<INT_MAX);
  auto x=ngauss(move(a),b);
  return x.consistent?nmaybe<nlinear_solution<T>>(move(x)):nmaybe<nlinear_solution<T>>{};
}
template<nfield T,class A,class M,nindexed B>
nlinear_solution<T>ngauss(nmat<T,A,M>a,const B&b){
  return ngauss(nmatrix<T>(move(a)),b);
}

// 54_poly
template<class T>struct nntt_info{
  static constexpr bool ok=false;
};
template<>struct nntt_info<nmodint<998244353>>{
  static constexpr bool ok=true;
  static constexpr uint64_t root=3;
};
template<>struct nntt_info<nmodint<1004535809>>:nntt_info<nmodint<998244353>>{};
template<>struct nntt_info<nmodint<469762049>>:nntt_info<nmodint<998244353>>{};
namespace ni{
template<class T>inline constexpr bool nstatic_modular=false;
template<uint64_t M>inline constexpr bool nstatic_modular<nmodint<M>> = true;
inline uint64_t nprimitive_root(uint64_t m){
  npre(2<=m&&m<=UINT32_MAX&&nisprime(m));
  if(m==2)
    return 1;
  uint64_t n=m-1,x=n;
  nvector<uint64_t>f;
  for(uint64_t p=2;p<=x/p;++p)
    if(x%p==0){
      f.push(p);
      while(x%p==0)
        x/=p;
    }
  if(x>1)
    f.push(x);
  for(uint64_t g=2;;++g){
    bool ok=true;
    nfor(p,f){
      ok&=npowmod(g,n/p,m)!=1;
    }
    if(ok)
      return g;
  }
}
template<uint64_t M>void nntt(nvector<nmodint<M>>&a,bool inv){
  int n=a.len();
  npre(n>0&&has_single_bit(unsigned(n))&&(M-1)%n==0);
  for(int i=1,j=0;i<n;++i){
    int b=n>>1;
    while(j&b){
      j^=b;
      b>>=1;
    }
    j^=b;
    if(i<j)
      swap(a[i],a[j]);
  }
  using Z=nmodint<M>;
  static const uint64_t root=nntt_info<Z>::ok?nntt_info<Z>::root:nprimitive_root(M);
  for(int w=2;w<=n;w<<=1){
    Z step=Z(root).pow((M-1)/w);
    if(inv)
      step=step.inv();
    for(int l=0;l<n;l+=w){
      Z r=1;
      nrep(i,w/2){
        Z x=a[l+i],y=a[l+i+w/2]*r;
        a[l+i]=x+y;
        a[l+i+w/2]=x-y;
        r*=step;
      }
    }
    if(w==n)
      break;
  }
  if(inv){
    Z z=Z(n).inv();
    nfor(x,a){
      x*=z;
    }
  }
}
}// namespace ni

template<nindexed A,nindexed B>auto nconv_naive(const A&a,const B&b){
  using T=nvalue_t<const A>;
  static_assert(same_as<T,nvalue_t<const B>>);
  if(!nlen(a)||!nlen(b))
    return nvector<T>{};
  npre(nlen(a)<=INT_MAX-nlen(b)+1);
  nvector<T>c(nlen(a)+nlen(b)-1);
  nrep(i,nlen(a))
    nrep(j,nlen(b))
      c[i+j]+=a[i]*b[j];
  return c;
}
template<nindexed A,nindexed B>
  requires ni::nstatic_modular<nvalue_t<const A>>&&nexact_field<nvalue_t<const A>>&&
           same_as<nvalue_t<const A>,nvalue_t<const B>>
auto nconv_ntt(const A&a,const B&b){
  using T=nvalue_t<const A>;
  if(!nlen(a)||!nlen(b))
    return nvector<T>{};
  npre(nlen(a)<=INT_MAX-nlen(b)+1);
  int z=nlen(a)+nlen(b)-1,n=nbitceil(z);
  npre(T::mod()<=UINT32_MAX&&(T::mod()-1)%n==0);
  nvector<T>x(n),y(n);
  nrep(i,nlen(a))
    x[i]=a[i];
  nrep(i,nlen(b))
    y[i]=b[i];
  ni::nntt(x,false);
  ni::nntt(y,false);
  nrep(i,n)
    x[i]*=y[i];
  ni::nntt(x,true);
  x.resize(z);
  return x;
}
template<nindexed A,nindexed B>auto nconv_auto(const A&a,const B&b){
  using T=nvalue_t<const A>;
  static_assert(same_as<T,nvalue_t<const B>>);
  if constexpr(ni::nstatic_modular<T>&&nexact_field<T>){
    long long z=1LL*nlen(a)+nlen(b)-1;
    if(nlen(a)&&nlen(b)&&min(nlen(a),nlen(b))>=32&&z<=(1<<30)){
      int n=nbitceil(int(z));
      if(T::mod()<=UINT32_MAX&&(T::mod()-1)%n==0)
        return nconv_ntt(a,b);
    }
  }
  return nconv_naive(a,b);
}
template<nindexed A,nindexed B>auto nconv(const A&a,const B&b){
  return nconv_auto(a,b);
}

template<nindexed A>auto npoly_derivative(const A&a){
  using T=nvalue_t<const A>;
  nvector<T>b(max(0,nlen(a)-1));
  for(int i=1;i<nlen(a);++i)
    b[i-1]=a[i]*T(i);
  return b;
}
template<nindexed A>
  requires floating_point<nvalue_t<const A>>||nfield<nvalue_t<const A>>
auto npoly_integral(const A&a){
  using T=nvalue_t<const A>;
  npre(nlen(a)<INT_MAX);
  nvector<T>b(nlen(a)+1);
  nrep(i,nlen(a))
    b[i+1]=a[i]/T(i+1);
  return b;
}
template<nindexed A,class X>auto npoly_evaluate(const A&a,const X&x){
  using T=nvalue_t<const A>;
  T y{};
  for(int i=nlen(a);i--;)
    y=y*x+a[i];
  return y;
}
template<nindexed A>
  requires floating_point<nvalue_t<const A>>||nfield<nvalue_t<const A>>
auto nfps_inverse(const A&a,int terms){
  using T=nvalue_t<const A>;
  npre(terms>=0);
  if(!terms)
    return nvector<T>{};
  npre(nlen(a)&&a[0]!=T{});
  nvector<T>b{T{1}/a[0]};
  while(b.len()<terms){
    int n=min(terms,2*b.len());
    nvector<T>x(n);
    nrep(i,min(n,nlen(a)))
      x[i]=a[i];
    auto f=nconv(x,b);
    f.resize(n);
    f[0]=T{2}-f[0];
    for(int i=1;i<n;++i)
      f[i]=-f[i];
    b=nconv(b,f);
    b.resize(n);
  }
  return b;
}

template<class T>class npoly{
public:
  using value_type=T;
  nvector<T>a;
  npoly()=default;
  npoly(initializer_list<T>x):a(x){norm();}
  explicit npoly(nvector<T>x):a(move(x)){norm();}
  int len()const{return a.len();}
  int deg()const{return len()-1;}
  bool empty()const{return a.empty();}
  void norm(){
    while(!a.empty()&&a.back()==T{})
      a.pop();
  }
  T operator[](int i)const{return 0<=i&&i<len()?a[i]:T{};}
  T&at(int i){return a[i];}
  const T&at(int i)const{return a[i];}
  template<class X>T operator()(const X&x)const{return npoly_evaluate(a,x);}
  npoly&operator+=(const npoly&b){
    if(len()<b.len())
      a.resize(b.len());
    nrep(i,b.len())
      a[i]+=b.a[i];
    norm();
    return*this;
  }
  npoly&operator-=(const npoly&b){
    if(len()<b.len())
      a.resize(b.len());
    nrep(i,b.len())
      a[i]-=b.a[i];
    norm();
    return*this;
  }
  npoly&operator*=(const npoly&b){
    a=nconv(a,b.a);
    norm();
    return*this;
  }
  friend npoly operator+(npoly a,const npoly&b){return a+=b;}
  friend npoly operator-(npoly a,const npoly&b){return a-=b;}
  friend npoly operator*(npoly a,const npoly&b){return a*=b;}
  friend bool operator==(const npoly&,const npoly&)=default;
  npoly deriv()const{return npoly(npoly_derivative(a));}
  npoly integral()const
    requires floating_point<T>||nfield<T>
  {
    return npoly(npoly_integral(a));
  }
  npoly cut(int n)const{
    npre(n>=0);
    nvector<T>b(min(n,len()));
    nrep(i,b.len())
      b[i]=a[i];
    return npoly(move(b));
  }
  npoly inv(int n)const
    requires floating_point<T>||nfield<T>
  {
    return npoly(nfps_inverse(a,n));
  }
  npoly log(int n)const
    requires floating_point<T>||nfield<T>
  {
    npre(n>=0&&(!n||(*this)[0]==T{1}));
    return n?(deriv()*inv(n)).cut(n-1).integral().cut(n):npoly{};
  }
  npoly exp(int n)const
    requires floating_point<T>||nfield<T>
  {
    npre(n>=0&&(!n||(*this)[0]==T{}));
    if(!n)
      return{};
    npoly b{T{1}};
    for(int z=1;z<n;){
      int m=min(n,2*z);
      npoly f=cut(m)-b.log(m);
      if(f.empty())
        f.a.resize(1);
      f.a[0]+=T{1};
      b=(b*f).cut(m);
      z=m;
    }
    return b.cut(n);
  }
};

template<nindexed A>auto nberlekamp(const A&s){
  using T=nvalue_t<const A>;
  nvector<T>c{T{1}},old{T{1}};
  int l=0,shift=1;
  T last{1};
  nrep(n,nlen(s)){
    T d=s[n];
    for(int i=1;i<=l;++i)
      d+=c[i]*s[n-i];
    if(d==T{}){
      ++shift;
      continue;
    }
    auto save=c;
    T k=d/last;
    if(c.len()<old.len()+shift)
      c.resize(old.len()+shift);
    nrep(i,old.len())
      c[i+shift]-=k*old[i];
    if(2*l<=n){
      l=n+1-l;
      old=move(save);
      last=d;
      shift=1;
    }
    else
      ++shift;
  }
  nvector<T>a(l);
  nrep(i,l)
    a[i]=-c[i+1];
  return a;
}
template<nindexed A,nindexed C>
  requires same_as<nvalue_t<const A>,nvalue_t<const C>>
auto nrec_nth(const A&init,const C&rec,uint64_t n)->nmaybe<nvalue_t<const A>>{
  using T=nvalue_t<const A>;
  int k=nlen(rec);
  if(n<uint64_t(nlen(init)))
    return init[int(n)];
  if(!k||nlen(init)<k)
    return{};
  npre(k<=INT_MAX/2);
  auto mul=[&](const nvector<T>&a,const nvector<T>&b){
    nvector<T>c(2*k-1);
    nrep(i,k){
      nrep(j,k){
        c[i+j]+=a[i]*b[j];
      }
    }
    for(int d=2*k-1;d-->k;)
      nrep(i,k)
        c[d-i-1]+=c[d]*rec[i];
    c.resize(k);
    return c;
  };
  nvector<T>a(k),b(k);
  a[0]=T{1};
  b[k==1?0:1]=k==1?rec[0]:T{1};
  for(;n;n>>=1){
    if(n&1)
      a=mul(a,b);
    if(n>>1)
      b=mul(b,b);
  }
  T x{};
  nrep(i,k){
    x+=a[i]*init[i];
  }
  return x;
}
template<nindexed A,nindexed C>
  requires same_as<nvalue_t<const A>,nvalue_t<const C>>
auto nrec_nth(const A&a,const C&c,uint64_t n,nvalue_t<const A>f){
  auto x=nrec_nth(a,c,n);
  return x?x.val():move(f);
}

// 55_game
template<uintg T=uint64_t>class nxorbasis{
  array<T,limits<T>::digits>b{};
  int n{};

public:
  int len()const{return n;}
  bool empty()const{return!n;}
  bool ins(T x){
    for(int i=int(b.size());i--;)
      if(x>>i&1){
        if(b[i])
          x^=b[i];
        else
          return b[i]=x,++n,true;
      }
    return false;
  }
  bool has(T x)const{
    for(int i=int(b.size());i--;)
      if(x>>i&1)
        x^=b[i];
    return!x;
  }
  T max(T x={})const{
    for(int i=int(b.size());i--;)
      nchmax(x,T(x^b[i]));
    return x;
  }
  T min_nonzero(T f={})const{
    for(T x:b)
      if(x)
        return x;
    return f;
  }
};

template<class P=long double>class nprob{
  nvector<P>w;
  static bool valid(P x){
    if constexpr(floating_point<P>)
      return isfinite(x)&&x>=0;
    else
      return x>=0;
  }

public:
  using value_type=P;
  nprob()=default;
  explicit nprob(int n,P x={}):w(n,move(x)){}
  nprob(initializer_list<P>x):w(x){}
  int len()const{return w.len();}
  bool empty()const{return w.empty();}
  P&operator[](int i){return w[i];}
  const P&operator[](int i)const{return w[i];}
  P get(int i,P f={})const{return w.get(i,move(f));}
  P sum()const{
    P z{};
    nfor(x,w){
      z+=x;
    }
    return z;
  }
  bool nonnegative()const{
    nfor(x,w){
      if(!valid(x))
        return false;
    }
    return true;
  }
  bool is_normalized(P total=P{1})const{
    P s=sum();
    if constexpr(floating_point<P>)
      return nonnegative()&&isfinite(s)&&s==total;
    else
      return nonnegative()&&s==total;
  }
  nprob&operator*=(P x){
    nfor(y,w){
      y*=x;
    }
    return*this;
  }
  friend nprob operator*(nprob a,P x){return a*=x;}
  friend nprob operator*(P x,nprob a){return a*=x;}
  template<class F>auto expect(F f)const{
    using R=uncv<invoke_result_t<F&,int>>;
    R z{};
    nrep(i,len())
      z+=w[i]*invoke(f,i);
    return z;
  }
  nmaybe<nprob>normalized_copy(P total=P{1})const{
    P s=sum();
    if(!nonnegative()||!(s>P{}))
      return{};
    if constexpr(floating_point<P>)
      if(!isfinite(s)||!isfinite(total))
        return{};
    nprob z=*this;
    nfor(x,z.w){
      x=x*total/s;
    }
    return z;
  }
  nmaybe<nprob>normalized(P total=P{1})const{return normalized_copy(total);}
  nprob&normalize(P total=P{1}){
    auto z=normalized_copy(total);
    npre(z);
    return*this=move(z.val());
  }
  int draw(nrng&r=nrng_global,int f=npos)const
    requires floating_point<P>
  {
    long double s=sum();
    if(!nonnegative()||!(s>0)||!isfinite(s))
      return f;
    long double x=ldexp((long double)(r()>>11),-53)*s;
    nrep(i,len()){
      if((x-=w[i])<0)
        return i;
    }
    return empty()?f:len()-1;
  }
  friend bool operator==(const nprob&,const nprob&)=default;
};
template<class P,class F>auto nexpect(const nprob<P>&p,F f){
  return p.expect(move(f));
}

template<uintg T=uint64_t>class nnim{
  T x{};

public:
  nvector<T>h;
  nnim()=default;
  template<nenumerable A>explicit nnim(const A&a){nfor(v,a)push(T(v));}
  int len()const{return h.len();}
  bool empty()const{return h.empty();}
  void push(T v){
    h.push(v);
    x^=v;
  }
  bool win()const{return x;}
  T nim_sum()const{return x;}
  nmaybe<pair<int,T>>winning()const{
    if(!x)
      return{};
    nrep(i,len()){
      T y=h[i]^x;
      if(y<h[i])
        return pair{i,y};
    }
    npre(false);
    return{};
  }
  pair<int,T>winning(pair<int,T>f)const{
    auto z=winning();
    return z?z.val():move(f);
  }
};

template<ngraph_like G>nmaybe<nvector<int>>nsg_dag(const G&g){
  auto o=ntoposort(g);
  if(!o)
    return{};
  int n=ni::gverts(g);
  nvector<int>sg(n),mark(n+1,npos);
  for(int p=o->len();p--;){
    int u=(*o)[p];
    nfor(e,g.neighbors(u)){
      int v=nedge_to(e);
      npre(0<=v&&v<n);
      if(sg[v]<=n)
        mark[sg[v]]=p;
    }
    int x=0;
    while(x<=n&&mark[x]==p)
      ++x;
    sg[u]=x;
  }
  return sg;
}
template<ngraph_like G>nvector<int>nsg_dag(const G&g,nvector<int>f){
  auto z=nsg_dag(g);
  return z?move(z.val()):move(f);
}
template<ngraph_like G>auto nsg(const G&g){
  return nsg_dag(g);
}
template<ngraph_like G>auto nsg(const G&g,nvector<int>f){
  return nsg_dag(g,move(f));
}

// 60_string
template<nindexed A>nvector<int>nprefix_function(const A&a){
  int n=nlen(a);
  nvector<int>p(n);
  for(int i=1;i<n;++i){
    int j=p[i-1];
    while(j&&a[i]!=a[j])
      j=p[j-1];
    p[i]=j+(a[i]==a[j]);
  }
  return p;
}
template<nindexed A>nvector<int>nz_function(const A&a){
  int n=nlen(a);
  nvector<int>z(n);
  for(int i=1,l=0,r=0;i<n;++i){
    if(i<r)
      z[i]=min(r-i,z[i-l]);
    while(i+z[i]<n&&a[z[i]]==a[i+z[i]])
      ++z[i];
    if(r<i+z[i]){
      l=i;
      r=i+z[i];
    }
  }
  if(n)
    z[0]=n;
  return z;
}
template<nindexed A,nindexed B>nvector<int>nkmp_find(const A&a,const B&b){
  int n=nlen(a),m=nlen(b);
  nvector<int>ans;
  if(!m){
    npre(n<INT_MAX);
    ans.reserve(n+1);
    for(int i=0;i<=n;++i)
      ans.push(i);
    return ans;
  }
  auto p=nprefix_function(b);
  int j=0;
  nrep(i,n){
    while(j&&a[i]!=b[j])
      j=p[j-1];
    if(a[i]==b[j])
      ++j;
    if(j==m){
      ans.push(i-m+1);
      j=p[j-1];
    }
  }
  return ans;
}
class npalindrome_index{
  nvector<int>odd,even;

public:
  npalindrome_index()=default;
  template<nindexed A>explicit npalindrome_index(const A&a):odd(nlen(a)),even(nlen(a)){
    int n=nlen(a);
    for(int i=0,l=0,r=-1;i<n;++i){
      int k=i>r?1:min(odd[l+r-i],r-i+1);
      while(0<=i-k&&i+k<n&&a[i-k]==a[i+k])
        ++k;
      odd[i]=k;
      if(r<i+k-1){
        l=i-k+1;
        r=i+k-1;
      }
    }
    for(int i=0,l=0,r=-1;i<n;++i){
      int k=i>r?0:min(even[l+r-i+1],r-i+1);
      while(0<=i-k-1&&i+k<n&&a[i-k-1]==a[i+k])
        ++k;
      even[i]=k;
      if(r<i+k-1){
        l=i-k;
        r=i+k-1;
      }
    }
  }
  int len()const{return odd.len();}
  int odd_radius(int i)const{
    npre(0<=i&&i<len());
    return odd[i];
  }
  int even_radius(int i)const{
    npre(0<=i&&i<len());
    return even[i];
  }
  bool pal(int l,int r)const{
    npre(0<=l&&l<=r&&r<=len());
    int n=r-l;
    if(!n)
      return true;
    int m=(l+r)/2;
    return n&1?odd[m]>=n/2+1:even[m]>=n/2;
  }
};
template<nindexed A>auto nmanacher(const A&a){
  return npalindrome_index(a);
}
template<nindexed A>auto nprefix(const A&a){
  return nprefix_function(a);
}
template<nindexed A>auto nzfunc(const A&a){
  return nz_function(a);
}
template<nindexed A,nindexed B>auto nkmp(const A&a,const B&b){
  return nkmp_find(a,b);
}
using nmanacher_result=npalindrome_index;

template<nindexed A,class C=nless<>>nvector<int>nsuffix_array(const A&a,C cmp={}){
  int n=nlen(a);
  nvector<int>sa(n),r(n),nr(n);
  iota(sa.begin(),sa.end(),0);
  nsort(sa,[&](int i,int j){return invoke(cmp,a[i],a[j]);});
  for(int i=1;i<n;++i)
    r[sa[i]]=r[sa[i-1]]+int(invoke(cmp,a[sa[i-1]],a[sa[i]])||invoke(cmp,a[sa[i]],a[sa[i-1]]));
  for(int w=1;n&&w<n&&r[sa.back()]+1<n;w<<=1){
    auto key=[&](int i){
      return pair{r[i],i+w<n?r[i+w]:npos};
    };
    nsort(sa,[&](int i,int j){return key(i)<key(j);});
    nr[sa[0]]=0;
    for(int i=1;i<n;++i)
      nr[sa[i]]=nr[sa[i-1]]+(key(sa[i-1])!=key(sa[i]));
    swap(r,nr);
    if(w>n/2)
      break;
  }
  return sa;
}
template<nindexed A>nvector<int>nlcp_array(const A&a,const nvector<int>&sa){
  int n=nlen(a);
  npre(sa.len()==n);
  nvector<int>r(n),lcp(n),seen(n);
  nrep(i,n){
    npre(0<=sa[i]&&sa[i]<n&&!seen[sa[i]]);
    seen[sa[i]]=1;
    r[sa[i]]=i;
  }
  for(int i=0,k=0;i<n;++i){
    int p=r[i];
    if(!p)
      continue;
    int j=sa[p-1];
    while(i+k<n&&j+k<n&&a[i+k]==a[j+k])
      ++k;
    lcp[p]=k;
    if(k)
      --k;
  }
  return lcp;
}

// 61_automata
namespace ni{
template<class A>
concept nautomaton_sequence=nindexed<A>&&integral<nvalue_t<const A>>;
template<class A>concept naseq=nautomaton_sequence<A>;
template<int A,integral T>int asymbol(T x){
  if constexpr(sint<T>)
    if(x<0)
      return npos;
  return __uint128_t(x)<A?int(x):npos;
}
}// namespace ni
struct nmatch{
  int l,r,id;
  friend bool operator==(const nmatch&,const nmatch&)=default;
};
template<int A>
  requires(A>0)
class ntrie{
  struct node{
    array<int,A>to;
    int par=npos,ch=npos,term=0,pass=0;
    node(int p=npos,int c=npos):par(p),ch(c){to.fill(npos);}
  };
  nvector<node>t{node{}};

public:
  int len()const{return t.len();}
  template<ni::naseq S>int add(const S&s){
    int v=0;
    npre(t[v].pass<INT_MAX);
    ++t[v].pass;
    nfor(x,s){
      int c=ni::asymbol<A>(x);
      npre(c!=npos);
      if(t[v].to[c]==npos){
        t[v].to[c]=t.len();
        t.push(v,c);
      }
      v=t[v].to[c];
      npre(t[v].pass<INT_MAX);
      ++t[v].pass;
    }
    npre(t[v].term<INT_MAX);
    ++t[v].term;
    return v;
  }
  template<ni::naseq S>int find(const S&s,int fail=npos)const{
    int v=0;
    nfor(x,s){
      int c=ni::asymbol<A>(x);
      if(c==npos||t[v].to[c]==npos)
        return fail;
      v=t[v].to[c];
    }
    return v;
  }
  template<ni::naseq S>int count(const S&s)const{
    int v=find(s);
    return v==npos?0:t[v].term;
  }
  template<ni::naseq S>int count_prefix(const S&s)const{
    int v=find(s);
    return v==npos?0:t[v].pass;
  }
  int parent(int v)const{
    npre(0<=v&&v<len());
    return t[v].par;
  }
  int symbol(int v)const{
    npre(0<=v&&v<len());
    return t[v].ch;
  }
};

template<int A>
  requires(A>0)
class nac{
  struct node{
    array<int,A>to;
    int fail=0,out=npos;
    nvector<int>ids;
    node(){to.fill(npos);}
  };
  nvector<node>t{node{}};
  nvector<int>lens;
  int cnt=0;
  bool built=false;

public:
  int len()const{return t.len();}
  int patterns()const{return cnt;}
  template<ni::naseq S>int add(const S&s){
    npre(!built&&nlen(s)>0&&cnt<INT_MAX);
    int v=0;
    nfor(x,s){
      int c=ni::asymbol<A>(x);
      npre(c!=npos);
      if(t[v].to[c]==npos){
        t[v].to[c]=t.len();
        t.push();
      }
      v=t[v].to[c];
    }
    t[v].ids.push(cnt);
    lens.push(nlen(s));
    return cnt++;
  }
  void build(){
    npre(!built);
    built=true;
    queue<int>q;
    nrep(c,A){
      int v=t[0].to[c];
      if(v==npos)
        t[0].to[c]=0;
      else
        q.push(v);
    }
    while(!q.empty()){
      int v=q.front();
      q.pop();
      int f=t[v].fail;
      t[v].out=t[f].ids.empty()?t[f].out:f;
      nrep(c,A){
        int u=t[v].to[c];
        if(u==npos)
          t[v].to[c]=t[f].to[c];
        else{
          t[u].fail=t[f].to[c];
          q.push(u);
        }
      }
    }
  }
  int step(int v,int c)const{
    npre(built&&0<=v&&v<len()&&0<=c&&c<A);
    return t[v].to[c];
  }
  template<ni::naseq S,class F>void match(const S&s,F&&f)const{
    npre(built);
    int v=0;
    nfori(i,x,s){
      int c=ni::asymbol<A>(x);
      npre(c!=npos);
      v=t[v].to[c];
      for(int u=v;u!=npos;u=t[u].out)
        nfor(id,t[u].ids)
          invoke(f,i,id);
    }
  }
  template<ni::naseq S>long long count(const S&s)const{
    long long z=0;
    match(s,[&](int,int){++z;});
    return z;
  }
  template<ni::naseq S,class F>void each(const S&s,F&&f)const{
    match(s,[&](int r,int id){invoke(f,r+1-lens[id],r+1,id);});
  }
  template<ni::naseq S>nvector<nmatch>matches(const S&s)const{
    nvector<nmatch>z;
    each(s,[&](int l,int r,int id){z.push(nmatch{l,r,id});});
    return z;
  }
};

// 70_geom
namespace ni{
template<class T>constexpr nwide_t<T>ngeom_widen(const T&x){
  using W=nwide_t<T>;
  if constexpr(is_num<T>)
    return numcast<W>(x);
  else
    return W(x);
}
}// namespace ni
template<class T>struct npoint{
  T x{},y{};
  npoint()=default;
  npoint(T x,T y):x(move(x)),y(move(y)){}
  template<class U>explicit operator npoint<U>()const{return{U(x),U(y)};}
  npoint&operator+=(const npoint&p){
    x+=p.x;
    y+=p.y;
    return*this;
  }
  npoint&operator-=(const npoint&p){
    x-=p.x;
    y-=p.y;
    return*this;
  }
  template<class U>npoint&operator*=(const U&s){
    x*=s;
    y*=s;
    return*this;
  }
  template<class U>npoint&operator/=(const U&s){
    x/=s;
    y/=s;
    return*this;
  }
  npoint operator+()const{return*this;}
  npoint operator-()const{return{-x,-y};}
  friend npoint operator+(npoint a,const npoint&b){return a+=b;}
  friend npoint operator-(npoint a,const npoint&b){return a-=b;}
  template<class U>friend npoint operator*(npoint a,const U&s){return a*=s;}
  template<class U>friend npoint operator*(const U&s,npoint a){return a*=s;}
  template<class U>friend npoint operator/(npoint a,const U&s){return a/=s;}
  friend auto operator<=>(const npoint&,const npoint&)=default;
};
template<class T>auto ndot(const npoint<T>&a,const npoint<T>&b){
  return ni::cadd(ni::cmul(ni::ngeom_widen(a.x),ni::ngeom_widen(b.x)),
      ni::cmul(ni::ngeom_widen(a.y),ni::ngeom_widen(b.y)));
}
template<class T>auto ncross(const npoint<T>&a,const npoint<T>&b){
  return ni::nchecked_sub(ni::cmul(ni::ngeom_widen(a.x),ni::ngeom_widen(b.y)),
      ni::cmul(ni::ngeom_widen(a.y),ni::ngeom_widen(b.x)));
}
template<class T>auto ncross(const npoint<T>&a,const npoint<T>&b,const npoint<T>&c){
  return ncross(b-a,c-a);
}
template<class T>auto norient(const npoint<T>&a,const npoint<T>&b,const npoint<T>&c){
  return ncross(a,b,c);
}
template<class T>auto ndist2(const npoint<T>&a,const npoint<T>&b){
  auto d=a-b;
  return ndot(d,d);
}
template<class X>int nsgn_eps(X x,long double e=0){
  if constexpr(uintg<X>)
    return x>0;
  else
    return x>e?1:x<-e?-1:0;
}
template<class X>int nsign(X x){
  return nsgn_eps(x);
}
template<class T>int norient(const npoint<T>&a,const npoint<T>&b,const npoint<T>&c,long double e){
  return nsgn_eps(norient(a,b,c),e);
}
template<class T>bool nonseg(const npoint<T>&a,const npoint<T>&b,const npoint<T>&p,long double e=0){
  if(norient(a,b,p,e))
    return false;
  return min(a.x,b.x)-e<=p.x&&p.x<=max(a.x,b.x)+e&&min(a.y,b.y)-e<=p.y&&p.y<=max(a.y,b.y)+e;
}
template<class T>bool non_segment(const npoint<T>&p,const npoint<T>&a,const npoint<T>&b){
  return nonseg(a,b,p);
}
template<class T>
bool nsegment_intersect(const npoint<T>&a,const npoint<T>&b,const npoint<T>&c,const npoint<T>&d,long double e){
  int x=norient(a,b,c,e),y=norient(a,b,d,e),z=norient(c,d,a,e),w=norient(c,d,b,e);
  if(x&&y&&z&&w)
    return x!=y&&z!=w;
  return(!x&&nonseg(a,b,c,e))||(!y&&nonseg(a,b,d,e))||(!z&&nonseg(c,d,a,e))||
         (!w&&nonseg(c,d,b,e));
}
template<class T>
bool nsegment_intersect(const npoint<T>&a,const npoint<T>&b,const npoint<T>&c,const npoint<T>&d){
  return nsegment_intersect(a,b,c,d,0);
}

template<class T>struct nline2{
  npoint<T>p,v;
  template<class U>auto operator()(const U&t)const{return p+v*t;}
};
template<class T>
nmaybe<npoint<long double>>nline_intersect(const nline2<T>&a,const nline2<T>&b,long double e=0){
  npoint<long double>u{(long double)a.v.x,(long double)a.v.y},v{(long double)b.v.x,(long double)b.v.y};
  npoint<long double>d{(long double)b.p.x-a.p.x,(long double)b.p.y-a.p.y};
  long double q=ncross(u,v);
  if(abs(q)<=e)
    return{};
  return npoint<long double>{(long double)a.p.x+u.x*ncross(d,v)/q,(long double)a.p.y+u.y*ncross(d,v)/q};
}
template<class T>
nmaybe<npoint<long double>>nline_intersection(
    const npoint<T>&a,const npoint<T>&b,const npoint<T>&c,const npoint<T>&d){
  return nline_intersect(nline2<T>{a,b-a},nline2<T>{c,d-c});
}

template<nindexed A>auto nconvex_hull(const A&a,bool keep=false){
  using P=nvalue_t<const A>;
  nvector<P>p=ncollect(a);
  nsort(p,[](const P&a,const P&b){return a.x!=b.x?a.x<b.x:a.y<b.y;});
  int z=0;
  nfor(x,p){
    if(!z||x!=p[z-1])
      p[z++]=x;
  }
  p.resize(z);
  if(z<=2)
    return p;
  bool line=true;
  for(int i=2;i<z;++i)
    line&=!norient(p[0],p[1],p[i]);
  if(line)
    return keep?p:nvector<P>{p.front(),p.back()};
  nvector<P>h;
  h.reserve(2*z);
  auto add=[&](const P&x,int base){
    while(h.len()>=base+2&&
          (keep?norient(h[h.len()-2],h.back(),x)<0:norient(h[h.len()-2],h.back(),x)<=0))
      h.pop();
    h.push(x);
  };
  nfor(x,p)
    add(x,0);
  int base=h.len()-1;
  for(int i=z-2;i>=0;--i)
    add(p[i],base);
  h.pop();
  return h;
}
template<nindexed A>auto npolygon_area2(const A&a){
  using P=nvalue_t<const A>;
  using W=nwide_t<uncv<decltype(declval<P>().x)>>;
  W s{};
  nrep(i,nlen(a)){
    int j=i+1==nlen(a)?0:i+1;
    s=ni::cadd(s,ncross(a[i],a[j]));
  }
  return s;
}
template<nindexed A>int npoint_in_poly(const A&a,const nvalue_t<const A>&p,long double e=0){
  bool in=false;
  nrep(i,nlen(a)){
    auto&u=a[i];
    auto&v=a[i+1==nlen(a)?0:i+1];
    if(nonseg(u,v,p,e))
      return 0;
    int o=norient(u,v,p,e);
    if((u.y<=p.y&&p.y<v.y&&o>0)||(v.y<=p.y&&p.y<u.y&&o<0))
      in=!in;
  }
  return in?1:-1;
}
template<nindexed A>auto nconvex_diameter2(const A&a){
  auto h=nconvex_hull(a);
  using P=nvalue_t<decltype(h)>;
  using W=decltype(ndist2(declval<P>(),declval<P>()));
  int n=h.len();
  if(n<2)
    return W{};
  if(n==2)
    return ndist2(h[0],h[1]);
  W ans{};
  int j=1;
  nrep(i,n){
    int k=(i+1)%n;
    while(norient(h[i],h[k],h[(j+1)%n])>norient(h[i],h[k],h[j]))
      j=(j+1)%n;
    nchmax(ans,ndist2(h[i],h[j]));
    nchmax(ans,ndist2(h[k],h[j]));
  }
  return ans;
}

// 71_opt
template<class T>struct nline{
  union{
    T m{};
    T slope;
  };
  union{
    T b{};
    T intercept;
  };
  using value_type=nwide_t<T>;
  value_type operator()(T x)const{
    return ni::cadd(ni::cmul(ni::ngeom_widen(m),ni::ngeom_widen(x)),ni::ngeom_widen(b));
  }
  friend bool operator==(const nline&,const nline&)=default;
};
template<class T>using nline_function=nline<T>;

template<sint T,class Better=nless<nwide_t<T>>>class nlichao{
  struct node{
    nline<T>f{};
    int l=npos,r=npos;
    bool used{};
  };
  T lo,hi;
  [[no_unique_address]]Better better;
  nvector<node>tr{node{}};
  int child(int p,bool right){
    int x=right?tr[p].r:tr[p].l;
    if(x==npos){
      x=tr.len();
      if(right)
        tr[p].r=x;
      else
        tr[p].l=x;
      tr.push();
    }
    return x;
  }
  void put(int p,T l,T r,nline<T>f){
    if(!tr[p].used){
      tr[p].f=f;
      tr[p].used=true;
      return;
    }
    T m=midpoint(l,r);
    bool a=invoke(better,f(l),tr[p].f(l)),b=invoke(better,f(m),tr[p].f(m));
    if(b)
      swap(f,tr[p].f);
    if(l==r)
      return;
    if(a!=b)
      put(child(p,0),l,m,f);
    else
      put(child(p,1),T(m+1),r,f);
  }
  void putseg(int p,T l,T r,T ql,T qr,nline<T>f){
    if(ql<=l&&r<=qr){
      put(p,l,r,f);
      return;
    }
    T m=midpoint(l,r);
    if(ql<=m)
      putseg(child(p,0),l,m,ql,qr,f);
    if(m<qr)
      putseg(child(p,1),T(m+1),r,ql,qr,f);
  }
  nmaybe<nwide_t<T>>get(int p,T l,T r,T x)const{
    nmaybe<nwide_t<T>>ans;
    if(tr[p].used)
      ans=tr[p].f(x);
    if(l==r)
      return ans;
    T m=midpoint(l,r);
    int q=x<=m?tr[p].l:tr[p].r;
    if(q==npos)
      return ans;
    auto z=x<=m?get(q,l,m,x):get(q,T(m+1),r,x);
    if(z&&(!ans||invoke(better,z.val(),ans.val())))
      ans=z.val();
    return ans;
  }

public:
  using line_type=nline<T>;
  using value_type=nwide_t<T>;
  nlichao(T l,T r,Better b={}):lo(l),hi(r),better(move(b)){npre(l<r);}
  int nodes()const{return tr.len();}
  void add(line_type f){put(0,lo,T(hi-1),f);}
  void add(T m,T b){add({m,b});}
  void add_segment(line_type f,T l,T r){
    npre(lo<=l&&l<=r&&r<=hi);
    if(l<r)
      putseg(0,lo,T(hi-1),l,T(r-1),f);
  }
  void add_segment(T m,T b,T l,T r){add_segment({m,b},l,r);}
  nmaybe<value_type>query(T x)const{
    npre(lo<=x&&x<hi);
    return get(0,lo,T(hi-1),x);
  }
};

template<class T,class Better=nless<nwide_t<T>>>
  requires is_num<T>&&(!same_as<remove_cv_t<T>,bool>)
class nlichao_static{
  struct node{
    nline<T>f{};
    bool used{};
  };
  nvector<node>tr;
  [[no_unique_address]]Better better;
  void put(int p,int l,int r,nline<T>f){
    if(!tr[p].used){
      tr[p]={f,true};
      return;
    }
    int m=(l+r)/2;
    bool a=invoke(better,f(x[l]),tr[p].f(x[l])),b=invoke(better,f(x[m]),tr[p].f(x[m]));
    if(b)
      swap(f,tr[p].f);
    if(r-l==1)
      return;
    if(a!=b)
      put(p*2,l,m,f);
    else
      put(p*2+1,m,r,f);
  }
  void putseg(int p,int l,int r,int ql,int qr,nline<T>f){
    if(ql<=l&&r<=qr){
      put(p,l,r,f);
      return;
    }
    int m=(l+r)/2;
    if(ql<m)
      putseg(p*2,l,m,ql,qr,f);
    if(m<qr)
      putseg(p*2+1,m,r,ql,qr,f);
  }

public:
  using line_type=nline<T>;
  using value_type=nwide_t<T>;
  nvector<T>x;
  nlichao_static():tr(1){}
  template<nenumerable A>explicit nlichao_static(const A&a,Better b={}):better(move(b)),x(ncollect<T>(a)){
    nsort(x);
    nunique(x);
    npre(x.len()<=(INT_MAX-1)/4);
    tr.resize(max(1,4*x.len()+1));
  }
  int len()const{return x.len();}
  bool empty()const{return x.empty();}
  bool hasx(const T&v)const{
    int i=nlower(x,v);
    return i<len()&&v==x[i];
  }
  void add(line_type f){
    if(!empty())
      put(1,0,len(),f);
  }
  void add(T m,T b){add({m,b});}
  void addidx(line_type f,int l,int r){
    npre(0<=l&&l<=r&&r<=len());
    if(l<r)
      putseg(1,0,len(),l,r,f);
  }
  void addseg(line_type f,T l,T r){addidx(f,nlower(x,l),nlower(x,r));}
  nmaybe<value_type>get(T v)const{
    int i=nlower(x,v);
    if(i==len()||v!=x[i])
      return{};
    nmaybe<value_type>ans;
    for(int p=1,l=0,r=len();;){
      if(tr[p].used){
        auto z=tr[p].f(v);
        if(!ans||invoke(better,z,ans.val()))
          ans=z;
      }
      if(r-l==1)
        break;
      int m=(l+r)/2;
      if(i<m){
        r=m;
        p*=2;
      }else{
        l=m;
        p=p*2+1;
      }
    }
    return ans;
  }
  value_type get(T v,value_type f)const{
    auto z=get(v);
    return z?z.val():move(f);
  }
  value_type operator()(T v,value_type f)const{return get(v,move(f));}
};

template<sint I,class F,class B=nless<>>I nunimodal_arg(I l,I r,F f,B better={}){
  npre(l<r);
  auto dist=[](I a,I b){
    return __uint128_t(b)-__uint128_t(a);
  };
  while(dist(l,r)>4){
    I d=I(dist(l,r)/3),a=I(__int128_t(l)+d),b=I(__int128_t(r)-1-d);
    if(invoke(better,invoke(f,b),invoke(f,a)))
      l=a+1;
    else
      r=b+1;
  }
  I ans=l;
  auto val=invoke(f,l);
  for(I x=l+1;x<r;++x){
    auto y=invoke(f,x);
    if(invoke(better,y,val)){
      ans=x;
      val=move(y);
    }
  }
  return ans;
}
template<floating_point T,class F>T nternary_min(T l,T r,F f,int it=100){
  npre(l<=r&&it>=0);
  nrep(_,it){
    T d=(r-l)/3,a=l+d,b=r-d;
    if(invoke(f,a)<invoke(f,b))
      r=b;
    else
      l=a;
  }
  return midpoint(l,r);
}

// 80_io
namespace ni{
template<class T>
inline constexpr bool nio_integer=
    (!same_as<remove_cv_t<T>,bool>)&&(is_integral_v<T>||same_as<T,__int128_t>||same_as<T,__uint128_t>);
template<class T>struct io_unsigned{
  using type=uint_t<T>;
};
template<>struct io_unsigned<__int128_t>{
  using type=__uint128_t;
};
template<>struct io_unsigned<__uint128_t>{
  using type=__uint128_t;
};
template<class T>using io_unsigned_t=typename io_unsigned<T>::type;
}// namespace ni
class ninput{
  static constexpr int C=1<<16;
  FILE*f_;
  array<unsigned char,C>b_{};
  int p_=0,n_=0;
  int get(){
    if(p_==n_){
      n_=int(fread(b_.data(),1,b_.size(),f_));
      p_=0;
      if(!n_)
        return EOF;
    }
    return b_[p_++];
  }
  int start(){
    int c;
    do
      c=get();
    while(c!=EOF&&c<=' ');
    return c;
  }

public:
  explicit ninput(FILE*f=stdin):f_(f){npre(f);}
  template<class T>
    requires ni::nio_integer<T>
  bool read(T&x){
    int c=start();
    if(c==EOF)
      return false;
    bool neg=c=='-';
    if(neg||c=='+')
      c=get();
    npre('0'<=c&&c<='9');
    __uint128_t z=0;
    do{
      unsigned d=unsigned(c-'0');
      npre(z<=(~__uint128_t{}-d)/10);
      z=z*10+d;
      c=get();
    }while('0'<=c&&c<='9');
    npre(c==EOF||c<=' ');
    if constexpr(is_signed_v<T>||same_as<T,__int128_t>){
      __uint128_t hi=__uint128_t(limits<T>::max()),lo=hi+1;
      npre(z<=(neg?lo:hi));
      x=neg?(z==lo?limits<T>::lowest():-T(z)):T(z);
    }else{
      using U=ni::io_unsigned_t<T>;
      npre(!neg&&z<=__uint128_t(limits<U>::max()));
      x=T(U(z));
    }
    return true;
  }
  bool read(string&x){
    int c=start();
    if(c==EOF)
      return false;
    x.clear();
    do{
      x+=char(c);
      c=get();
    }while(c!=EOF&&c>' ');
    return true;
  }
  bool read(char&x){
    int c=start();
    if(c==EOF)
      return false;
    x=char(c);
    return true;
  }
  template<class T>ninput&operator>>(T&x){
    npre(read(x));
    return*this;
  }
};
class noutput{
  static constexpr int C=1<<16;
  FILE*f_;
  array<char,C>b_{};
  int n_=0;
  void put(char c){
    if(n_==C)
      flush();
    b_[n_++]=c;
  }

public:
  explicit noutput(FILE*f=stdout):f_(f){npre(f);}
  noutput(const noutput&)=delete;
  noutput&operator=(const noutput&)=delete;
  ~noutput(){flush();}
  void flush(){
    if(n_){
      size_t z=fwrite(b_.data(),1,size_t(n_),f_);
      npre(z==size_t(n_));
      n_=0;
    }
  }
  void write(char x){put(x);}
  void write(string_view x){
    for(char c:x)
      put(c);
  }
  void write(const string&x){write(string_view(x));}
  void write(const char*x){write(string_view(x));}
  template<class T>
    requires ni::nio_integer<T>
  void write(T x){
    using U=ni::io_unsigned_t<T>;
    U z;
    if constexpr(is_signed_v<T>||same_as<T,__int128_t>){
      if(x<0){
        put('-');
        z=U{}-U(x);
      }else
        z=U(x);
    }else
      z=U(x);
    char s[64];
    int n=0;
    do{
      s[n++]=char('0'+z%10);
      z/=10;
    }while(z);
    while(n)
      put(s[--n]);
  }
  template<class T>noutput&operator<<(const T&x){
    write(x);
    return*this;
  }
};
inline ninput nin;
inline noutput nout;
template<class... T>bool nread(T&...x){
  return(nin.read(x)&&...);
}
template<class... T>void nprint(const T&...x){
  bool first=true;
  auto f=[&](const auto&v){
    if(!first)
      nout.write(' ');
    first=false;
    nout.write(v);
  };
  (f(x),...);
}
template<class... T>void nprintln(const T&...x){
  nprint(x...);
  nout.write('\n');
}
