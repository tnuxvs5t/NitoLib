#pragma once
#include <bits/stdc++.h>
using namespace std;
#if defined(NITORI_NANO_UNSAFE) || defined(NITORI_X_TEST_UNSAFE)
#define NITORI_NANO_UNSAFE_PROFILE 1
#else
#define NITORI_NANO_UNSAFE_PROFILE 0
#endif

namespace ni {

[[noreturn]] inline void contract_fail(const char* expression,
                  const char* file,
                  int line) {
  fprintf(stderr, "Nitori contract failed: %s (%s:%d)\n", expression, file, line);
  abort();
}
template<class Self>
struct ring_ops {
  friend constexpr Self operator+(Self left, Self right) { return left += right; }
  friend constexpr Self operator-(Self left, Self right) { return left -= right; }
  friend constexpr Self operator*(Self left, Self right) { return left *= right; }
  friend constexpr Self operator/(Self left, Self right) { return left /= right; }
};
}
#if NITORI_NANO_UNSAFE_PROFILE
#if defined(__GNUC__) || defined(__clang__)
#define npre(expression) ((expression) ? (void)0 : __builtin_unreachable())
#else
#define npre(expression) ((void)0)
#endif
#else
#define npre(expression) ((expression) ? (void)0 : ::ni::contract_fail(#expression, __FILE__, __LINE__))
#endif
#define nassert(expression) npre(expression)
#define npre_index(index, size) npre(0 <= (index) && (index) < (size))
#define npre_range(left, right, size) npre(0 <= (left) && (left) <= (right) && (right) <= (size))

inline constexpr int nversion = 20000;
inline constexpr bool nunsafe = NITORI_NANO_UNSAFE_PROFILE;
inline constexpr int npos = -1;
template<class T>
using nwide_t = conditional_t<is_integral_v<T>, __int128_t, long double>;
template<class T, class U>
constexpr T nchecked_number(U value) {
  if constexpr (is_integral_v<T> && is_integral_v<U>) {
    if constexpr (is_signed_v<T> && !is_signed_v<U>) {
      npre(value <= static_cast<U>(numeric_limits<T>::max()));
    } else if constexpr (!is_signed_v<T> && is_signed_v<U>) {
      npre(value >= 0);
      if (value >= 0)
        npre(static_cast<make_unsigned_t<U>>(value) <=
        static_cast<make_unsigned_t<U>>(numeric_limits<T>::max()));
    } else {
      npre(value >= numeric_limits<T>::lowest() && value <= numeric_limits<T>::max());
    }
  }
  return T(value);
}
template<class T>
constexpr T nchecked_add(T a, T b) {
  if constexpr (is_integral_v<T>) {
    T result;
    npre(!__builtin_add_overflow(a, b, &result));
    return result;
  } else {
    return a + b;
  }
}
template<class T>
constexpr T nchecked_sub(T a, T b) {
  if constexpr (is_integral_v<T>) {
    T result;
    npre(!__builtin_sub_overflow(a, b, &result));
    return result;
  } else {
    return a - b;
  }
}

template<class T>
constexpr T nchecked_mul(T a, T b) {
  if constexpr (is_integral_v<T>) {
    T result;
    npre(!__builtin_mul_overflow(a, b, &result));
    return result;
  } else {
    return a * b;
  }
}
template<class T>
inline constexpr T ninf = numeric_limits<T>::has_infinity
            ? numeric_limits<T>::infinity()
            : numeric_limits<T>::max();
template<class T>
inline constexpr T nninf = numeric_limits<T>::has_infinity
            ? -numeric_limits<T>::infinity()
            : (is_signed_v<T> ? numeric_limits<T>::lowest() : T{});
template<class T>
struct nmaybe : optional<T> {
  using optional<T>::optional;
  using optional<T>::operator=;
  template<class U>
  nmaybe& operator=(U&& value) {
    optional<T>::operator=(forward<U>(value));
    return *this;
  }
  bool ok() const { return this->has_value(); }
  explicit operator bool() const { return ok(); }
  template<class Self>
  decltype(auto) val(this Self&& self) {
    npre(self.ok());
    return self.optional<T>::operator*();
  }
  template<class Self>
  T val(this Self&& self, T fallback) {
    return self.ok() ? T(forward_like<Self>(*self)) : move(fallback);
  }
  decltype(auto) operator*(this auto&& self) { return self.val(); }
  auto operator->(this auto&& self) { return addressof(self.val()); }
};
template<class A, class B>
constexpr bool nchmin(A& a, B&& b) {
  if (b < a) {
    a = forward<B>(b);
    return true;
  }
  return false;
}
template<class A, class B>
constexpr bool nchmax(A& a, B&& b) {
  if (a < b) {
    a = forward<B>(b);
    return true;
  }
  return false;
}
template<class A>
concept nhas_len = requires(const A& value) { value.len(); };

template<class A>
concept nhas_size = requires(const A& value) { value.size(); };
template<class A>
constexpr int nlen(const A& value) {
  auto size = [&] {
    if constexpr (nhas_len<A>)
      return value.len();
    else
      return value.size();
  }();
  npre(size >= 0 && uintmax_t(size) <= uintmax_t(INT_MAX));
  return int(size);
}
constexpr int nbitceil(int value) {
  npre(0 <= value && value <= (1 << 30));
  return value <= 1 ? 1 : int(bit_ceil(unsigned(value)));
}
template<integral T>
int ni_nloop_count(T count) {
  if constexpr (signed_integral<T>) {
    if (count <= 0)
      return 0;
  } else if (count == 0) {
    return 0;
  }
  npre(uintmax_t(count) <= uintmax_t(INT_MAX));
  return int(count);
}
#define nrep(index, count) for (int index = 0, nrep_limit = ni_nloop_count((count)); index < nrep_limit; ++index)
#define nrrep(index, count) for (int index = ni_nloop_count((count)); index-- > 0;)

template<class T = void>
using nless = less<T>;
template<class T = void>
using ngreater = greater<T>;
template<class T = void>
using nequal = equal_to<T>;
using nidentity = identity;
enum class nlaw : unsigned {
  none = 0,
associative = 1U << 0,
identity = 1U << 1,
inverse = 1U << 2,
commutative = 1U << 3,
idempotent = 1U << 4,
};

constexpr nlaw operator|(nlaw a, nlaw b) {
  return nlaw(unsigned(a) | unsigned(b));
}
constexpr bool nhas_law(nlaw laws, nlaw law) {
  return (unsigned(laws) & unsigned(law)) == unsigned(law);
}
template<class O, nlaw Law>
concept ndeclares = requires { O::laws; } && nhas_law(O::laws, Law);
template<class O, class T>
concept nsemigroup = ndeclares<O, nlaw::associative>;
template<class O, class T>
concept nmonoid = nsemigroup<O, T> && ndeclares<O, nlaw::identity>;

template<class O, class T>
concept ngroup = nmonoid<O, T> && ndeclares<O, nlaw::inverse>;
template<class O, class T>
concept ncommutative_monoid = nmonoid<O, T> && ndeclares<O, nlaw::commutative>;
template<class Add, class Multiply, class T>
inline constexpr bool nsemiring_laws = false;
template<class Add, class Multiply, class T>
concept nsemiring = ncommutative_monoid<Add, T> && nmonoid<Multiply, T> &&
        nsemiring_laws<Add, Multiply, T>;
template<class T>
struct nadd {
  static constexpr nlaw laws = nlaw::associative | nlaw::identity |
                ((is_arithmetic_v<T> && !same_as<T, bool>)
                ? nlaw::inverse | nlaw::commutative
                : nlaw::none);
  T id() const { return T{}; }
  T operator()(T a, const T& b) const {
    return a += b;
  }
  T inv(T value) const {
    return -value;
  }
};
template<class T>
struct nmul {
  static constexpr nlaw laws = nlaw::associative | nlaw::identity;
  T id() const { return T(1); }
  T operator()(T a, const T& b) const {
    return a *= b;
  }
};

template<integral T>
  requires(!same_as<remove_cv_t<T>, bool>)
inline constexpr bool nsemiring_laws<nadd<T>, nmul<T>, T> = true;
template<class T>
struct nxor {
  static constexpr nlaw laws = nlaw::associative | nlaw::identity |
                nlaw::inverse | nlaw::commutative;
  T id() const { return T{}; }
  T operator()(T a, const T& b) const {
    return a ^= b;
  }
  T inv(T value) const { return value; }
};
template<class T>
struct nmin {
  static constexpr nlaw laws = nlaw::associative | nlaw::identity |
                nlaw::commutative | nlaw::idempotent;
  T id() const { return ninf<T>; }
  T operator()(const T& a, const T& b) const {
    return b < a ? b : a;
  }
};
template<class T>
struct nmax {
  static constexpr nlaw laws = nlaw::associative | nlaw::identity |
                nlaw::commutative | nlaw::idempotent;
  T id() const { return nninf<T>; }
  T operator()(const T& a, const T& b) const {
    return a < b ? b : a;
  }
};
template<class T>
struct naddsum_action {
  T tag_id() const { return T{}; }
  T compose(const T& newer, const T& older) const {
    return older + newer;
  }
  T apply(T sum, const T& delta, int length) const {
    return sum + delta * T(length);
  }
};

template<class A, class S, class F>
inline constexpr bool naction_laws = false;
template<class T>
inline constexpr bool naction_laws<naddsum_action<T>, T, T> =
is_integral_v<T> && !same_as<remove_cv_t<T>, bool>;
template<class A, class S, class F>
concept naction = naction_laws<A, S, F>;
template<class T>
inline constexpr bool nadd_group = is_arithmetic_v<T> && !same_as<remove_cv_t<T>, bool>;
template<class T>
inline constexpr bool nexact_field = false;

template<class T, class O = nmul<T>>
  requires nmonoid<O, T>
T npow(T base, long long exponent, O operation = {}) {
  uint64_t remaining = exponent < 0 ? uint64_t{} - uint64_t(exponent)
                : uint64_t(exponent);
  if (exponent < 0) {
    if constexpr (ngroup<O, T>)
      base = operation.inv(move(base));
    else
      npre(false);
  }
  T result = operation.id();
  while (remaining) {
    if (remaining & 1)
      result = operation(move(result), base);
    remaining >>= 1;
    if (remaining) {
      T copy = base;
      base = operation(move(copy), base);
    }
  }
  return result;
}
template<class T>
struct nvector : vector<T> {
  using vector<T>::vector;
  using vector<T>::operator=;
  int len() const {
    npre(this->size() <= size_t(INT_MAX));
    return int(this->size());
  }
  int cap() const {
    npre(this->capacity() <= size_t(INT_MAX));
    return int(this->capacity());
  }
  template<class... Args>
  T& push(Args&&... args) {
    this->emplace_back(forward<Args>(args)...);
    return this->back();
  }
  T pop() {
    npre(!this->empty());
    T value = move(this->back());
    this->pop_back();
    return value;
  }
  auto get(this auto&& self, int index) {
    using pointer = decltype(addressof(self[index]));
    return 0 <= index && index < self.len() ? addressof(self[index]) : pointer{};
  }
  T get(int index, T fallback) const { return get(index) ? (*this)[index] : move(fallback); }
  void del(int index) {
    npre_index(index, len());
    this->erase(this->begin() + index);
  }
  T swapdel(int index) {
    npre_index(index, len());
    T value = move((*this)[index]);
    if (index + 1 < len())
      (*this)[index] = move(this->back());
    this->pop_back();
    return value;
  }
};
template<class T, class O = nadd<T>>
  requires nmonoid<O, T> && copyable<T>
class nqueue_agg {
  struct node {
    T value;
    T aggregate;
  };
  [[no_unique_address]] O operation_;
  vector<node> left_, right_;
  void transfer() {
    if (!left_.empty())
      return;
    while (!right_.empty()) {
      T value = move(right_.back().value);
      right_.pop_back();
      T aggregate = left_.empty() ? value : operation_(value, left_.back().aggregate);
      left_.push_back({move(value), move(aggregate)});
    }
  }
public:
nqueue_agg() = default;
  explicit nqueue_agg(O operation) : operation_(move(operation)) {}
  int len() const {
    npre(left_.size() <= size_t(INT_MAX));
    npre(right_.size() <= size_t(INT_MAX) - left_.size());
    return int(left_.size() + right_.size());
  }
  bool empty() const {
    return left_.empty() && right_.empty();
  }
  void push(T value) {
    npre(len() < INT_MAX);
    T aggregate = right_.empty() ? value : operation_(right_.back().aggregate, value);
    right_.push_back({move(value), move(aggregate)});
  }
  const T& front() const {
    npre(!empty());
    return left_.empty() ? right_.front().value : left_.back().value;
  }
  T pop() {
    npre(!empty());
    transfer();
    T value = move(left_.back().value);
    left_.pop_back();
    return value;
  }
  T pop(T fallback) {
    return empty() ? move(fallback) : pop();
  }
  T fold() const {
    if (left_.empty())
      return right_.empty() ? operation_.id() : right_.back().aggregate;
    if (right_.empty())
      return left_.back().aggregate;
    return operation_(left_.back().aggregate, right_.back().aggregate);
  }
};
template<bool Rollback>
class ni_dsu {
  struct change {
    int large;
    int large_parent;
    int small;
    int small_parent;
  };
  mutable vector<int> parent_;
  conditional_t<Rollback, vector<change>, monostate> history_;
  static size_t checked_size(int n) {
    npre(n >= 0);
    return size_t(n);
  }
public:
explicit ni_dsu(int n = 0) : parent_(checked_size(n), -1) {}
  int len() const {
    return int(parent_.size());
  }
  int time() const requires Rollback {
    return int(history_.size());
  }
  int find(int vertex) const {
    npre_index(vertex, len());
    int original = vertex;
    while (parent_[vertex] >= 0)
      vertex = parent_[vertex];
    if constexpr (!Rollback) {
      while (original != vertex) {
        int next = parent_[original];
        parent_[original] = vertex;
        original = next;
      }
    }
    return vertex;
  }
  int operator()(int vertex) const requires(!Rollback) {
    return find(vertex);
  }
  int size(int vertex) const {
    return -parent_[find(vertex)];
  }
  bool same(int a, int b) const {
    return find(a) == find(b);
  }
  auto merge(int a, int b) {
    a = find(a);
    b = find(b);
    if (a == b) {
      if constexpr (Rollback)
        return false;
      else
        return a;
    }
    if (parent_[a] > parent_[b])
      swap(a, b);
    if constexpr (Rollback)
      history_.push_back({a, parent_[a], b, parent_[b]});
    parent_[a] += parent_[b];
    parent_[b] = a;
    if constexpr (Rollback)
      return true;
    else
      return a;
  }
  void undo() requires Rollback {
    npre(!history_.empty());
    auto change = history_.back();
    history_.pop_back();
    parent_[change.large] = change.large_parent;
    parent_[change.small] = change.small_parent;
  }
  void rollback(int checkpoint) requires Rollback {
    npre(0 <= checkpoint && checkpoint <= time());
    while (time() > checkpoint)
      undo();
  }
  nvector<int> partition() requires(!Rollback) {
    nvector<int> root_class(len(), npos), classes(len());
    int count = 0;
    nrep(vertex, len()) {
      int root = find(vertex);
      if (root_class[root] == npos)
        root_class[root] = count++;
      classes[vertex] = root_class[root];
    }
    return classes;
  }
};
using ndsu = ni_dsu<false>;
using nrollback_dsu = ni_dsu<true>;
using ndsu_rollback = nrollback_dsu;

template<class T>
concept ninteger = integral<T> && !same_as<remove_cv_t<T>, bool>;
template<ninteger T>
constexpr make_unsigned_t<T> nmag(T value) {
  using U = make_unsigned_t<T>;
  U encoded = U(value);
  if constexpr (is_signed_v<T>)
    return value < 0 ? U{} - encoded : encoded;
  else
    return encoded;
}
template<ninteger T>
constexpr make_unsigned_t<T> nabs(T value) { return nmag(value); }
template<ninteger T>
constexpr make_unsigned_t<T> ngcd_euclid(T a, T b) {
  using U = make_unsigned_t<T>;
  U x = nmag(a), y = nmag(b);
  while (y)
    tie(x, y) = pair{y, U(x % y)};
  return x;
}
template<ninteger T>
constexpr make_unsigned_t<T> ngcd_binary(T a, T b) {
  using U = make_unsigned_t<T>;
  U x = nmag(a), y = nmag(b);
  if (!x || !y)
    return x | y;
  int shift = countr_zero(x | y);
  x >>= countr_zero(x);
  do {
    y >>= countr_zero(y);
    if (y < x)
      swap(x, y);
    y -= x;
  } while (y);
  return x << shift;
}

template<ninteger T>
constexpr make_unsigned_t<T> ngcd(T a, T b) { return ngcd_binary(a, b); }
template<ninteger T>
constexpr make_unsigned_t<T> nlcm(T a, T b) {
  using U = make_unsigned_t<T>;
  U x = nmag(a), y = nmag(b);
  if (!x || !y)
    return 0;
  U d = ngcd(a, b);
  npre(x / d <= numeric_limits<U>::max() / y);
  return x / d * y;
}
template<signed_integral T>
constexpr T nfloor_div(T a, T b) {
  npre(b && !(a == numeric_limits<T>::lowest() && b == -1));
  T q = a / b, r = a % b;
  if (r && ((r < 0) != (b < 0)))
    --q;
  return q;
}
template<signed_integral T>
constexpr T nceil_div(T a, T b) {
  npre(b && !(a == numeric_limits<T>::lowest() && b == -1));
  T q = a / b, r = a % b;
  if (r && ((r < 0) == (b < 0)))
    ++q;
  return q;
}
template<signed_integral T>
constexpr T nmodulo(T value, T modulus) {
  npre(modulus > 0);
  T r = value % modulus;
  return r < 0 ? r + modulus : r;
}

template<ninteger T>
  requires(sizeof(T) <= sizeof(uint64_t))
struct nextgcd_result {
  make_unsigned_t<T> gcd;
  __int128_t x, y;
};
template<ninteger T>
  requires(sizeof(T) <= sizeof(uint64_t))
constexpr nextgcd_result<T> nextgcd(T a, T b) {
  using U = make_unsigned_t<T>;
  U old = nmag(a), current = nmag(b);
  __int128_t old_x = 1, x = 0, old_y = 0, y = 1;
  while (current) {
    U q = old / current;
    tie(old, current) = pair{current, U(old % current)};
    tie(old_x, x) = pair{x, old_x - __int128_t(q) * x};
    tie(old_y, y) = pair{y, old_y - __int128_t(q) * y};
  }
  if constexpr (is_signed_v<T>) {
    if (a < 0)
      old_x = -old_x;
    if (b < 0)
      old_y = -old_y;
  }
  return {old, old_x, old_y};
}
constexpr uint64_t nmulmod(uint64_t a, uint64_t b, uint64_t modulus) {
  npre(modulus);
  return uint64_t(__uint128_t(a) * b % modulus);
}
constexpr uint64_t npowmod(uint64_t base, uint64_t exponent, uint64_t modulus) {
  npre(modulus);
  uint64_t result = 1 % modulus;
  for (base %= modulus; exponent; exponent >>= 1) {
    if (exponent & 1)
      result = nmulmod(result, base, modulus);
    base = nmulmod(base, base, modulus);
  }
  return result;
}
constexpr bool nisprime(uint64_t value) {
  if (value < 2)
    return false;
  for (uint64_t prime : {2ULL, 3ULL, 5ULL, 7ULL, 11ULL, 13ULL, 17ULL,
          19ULL, 23ULL, 29ULL, 31ULL, 37ULL})
    if (value % prime == 0)
      return value == prime;
  uint64_t odd = value - 1;
  int shifts = countr_zero(odd);
  odd >>= shifts;
  for (uint64_t base : {2ULL, 325ULL, 9375ULL, 28178ULL, 450775ULL,
          9780504ULL, 1795265022ULL}) {
    if (base % value == 0)
      continue;
    uint64_t witness = npowmod(base, odd, value);
    if (witness == 1 || witness == value - 1)
      continue;
    bool passed = false;
    for (int round = 1; round < shifts; ++round) {
      witness = nmulmod(witness, witness, value);
      if (witness == value - 1) {
        passed = true;
        break;
      }
    }
    if (!passed)
      return false;
  }
  return true;
}

inline bool nisprime_trial(uint64_t value) {
  if (value < 2)
    return false;
  for (uint64_t d = 2; d <= value / d; ++d)
    if (value % d == 0)
      return false;
  return true;
}
inline uint64_t npollard(uint64_t value) {
  npre(value > 1 && !nisprime(value));
  if (!(value & 1))
    return 2;
  if (value % 3 == 0)
    return 3;
  for (uint64_t constant = 1;; ++constant) {
    uint64_t x = 2, y = 2, divisor = 1;
    auto step = [=](uint64_t z) { return (nmulmod(z, z, value) + constant) % value; };
    while (divisor == 1) {
      x = step(x);
      y = step(step(y));
      uint64_t difference = x > y ? x - y : y - x;
      divisor = gcd(difference, value);
    }
    if (divisor != value)
      return divisor;
  }
}
inline nvector<uint64_t> nfactor(uint64_t value) {
  nvector<uint64_t> result, pending;
  if (value > 1)
    pending.push(value);
  while (!pending.empty()) {
    uint64_t current = pending.pop();
    if (nisprime(current))
      result.push(current);
    else {
      uint64_t divisor = npollard(current);
      pending.push(divisor);
      pending.push(current / divisor);
    }
  }
  sort(result.begin(), result.end());
  return result;
}
inline nvector<uint64_t> nfactor_rho(uint64_t value) { return nfactor(value); }
inline nvector<int> nprimes(int limit) {
  npre(0 <= limit && limit < INT_MAX);
  nvector<int> result, least(limit + 1);
  for (int value = 2; value <= limit; ++value) {
    if (!least[value])
      least[value] = value, result.push(value);
    for (int i = 0; i < result.len() && result[i] <= least[value] &&
          1LL * result[i] * value <= limit; ++i)
      least[result[i] * value] = result[i];
  }
  return result;
}

template<signed_integral T = long long>
struct nfrac : ni::ring_ops<nfrac<T>> {
  using W = nwide_t<T>;
  T p = 0, q = 1;
  nfrac() = default;
  nfrac(T integer) : p(integer) {}
  nfrac(T numerator, T denominator) { assign(numerator, denominator); }
  static W absw(W value) { return value < 0 ? -value : value; }
  void assign(W numerator, W denominator) {
    npre(denominator);
    W divisor = gcd(absw(numerator), absw(denominator));
    numerator /= divisor;
    denominator /= divisor;
    if (denominator < 0)
      numerator = -numerator, denominator = -denominator;
    npre(numerator >= numeric_limits<T>::lowest() && numerator <= numeric_limits<T>::max());
    npre(denominator <= numeric_limits<T>::max());
    p = T(numerator);
    q = T(denominator);
  }
  nfrac& operator+=(const nfrac& other) {
    assign(W(p) * other.q + W(other.p) * q, W(q) * other.q);
    return *this;
  }
  nfrac& operator-=(const nfrac& other) { return *this += -other; }
  nfrac& operator*=(const nfrac& other) {
    assign(W(p) * other.p, W(q) * other.q);
    return *this;
  }
  nmaybe<nfrac> trydiv(const nfrac& other) const {
    if (!other.p)
      return {};
    nfrac result = *this;
    result *= nfrac(other.q, other.p);
    return result;
  }
  nfrac& operator/=(const nfrac& other) {
    auto result = trydiv(other);
    npre(result);
    return *this = move(result.val());
  }
  nfrac operator-() const { return {-p, q}; }
  friend strong_ordering operator<=>(const nfrac& a, const nfrac& b) {
    W left = W(a.p) * b.q, right = W(b.p) * a.q;
    return left < right ? strong_ordering::less : left > right ? strong_ordering::greater
                                : strong_ordering::equal;
  }
  friend bool operator==(const nfrac& a, const nfrac& b) {
    return a.p == b.p && a.q == b.q;
  }
  T floor() const { return nfloor_div(p, q); }
  T ceil() const { return nceil_div(p, q); }
};

struct ncongruence {
  long long a = 0, m = 1;
  ncongruence() = default;
  ncongruence(long long residue, long long modulus) : m(modulus) {
    npre(modulus > 0);
    a = nmodulo(residue, modulus);
  }
  bool has(long long value) const { return (__int128_t(value) - a) % m == 0; }
};
inline nmaybe<ncongruence> ncrt(ncongruence left, ncongruence right) {
  auto bezout = nextgcd(left.m, right.m);
  __int128_t difference = __int128_t(right.a) - left.a;
  if (difference % bezout.gcd)
    return {};
  __int128_t modulus = __int128_t(left.m / bezout.gcd) * right.m;
  if (modulus > numeric_limits<long long>::max())
    return {};
  __int128_t q = right.m / bezout.gcd;
  __int128_t multiplier = difference / bezout.gcd * bezout.x % q;
  __int128_t residue = (__int128_t(left.a) + __int128_t(left.m) * multiplier) % modulus;
  if (residue < 0)
    residue += modulus;
  return ncongruence(static_cast<long long>(residue), static_cast<long long>(modulus));
}

class nprime_table {
public:
int n = 0;
  nvector<int> p, lp, phi, mu;
  explicit nprime_table(int limit = 0) : n(limit), lp(n + 1), phi(n + 1), mu(n + 1) {
    npre(0 <= n && n < INT_MAX);
    if (n >= 1)
      phi[1] = mu[1] = 1;
    for (int value = 2; value <= n; ++value) {
      if (!lp[value])
        lp[value] = value, p.push(value), phi[value] = value - 1, mu[value] = -1;
      for (int i = 0; i < p.len() && p[i] <= lp[value] && 1LL * p[i] * value <= n; ++i) {
        int prime = p[i], product = prime * value;
        lp[product] = prime;
        if (prime == lp[value])
          phi[product] = phi[value] * prime, mu[product] = 0;
        else
          phi[product] = phi[value] * (prime - 1), mu[product] = -mu[value];
      }
    }
  }
  bool isprime(int value) const { return 2 <= value && value <= n && lp[value] == value; }
  nvector<pair<int, int>> factor(int value) const {
    npre(0 < value && value <= n);
    nvector<pair<int, int>> result;
    while (value > 1) {
      int prime = lp[value], count = 0;
      do
        value /= prime, ++count;
      while (value > 1 && lp[value] == prime);
      result.push(prime, count);
    }
    return result;
  }
};

namespace ni {
template<uint64_t M>
struct fixed_modulus {
  static constexpr uint64_t get() { return M; }
};

template<int Tag>
struct dynamic_modulus {
  static inline uint64_t value = 1;
  static uint64_t get() { return value; }
  static void setmod(uint64_t next) {
    npre(next > 0 && next <= uint64_t(INT64_MAX));
    value = next;
  }
};
}
template<class Self, class Modulus>
class nmod_base : public ni::ring_ops<Self> {
protected:
uint64_t value = 0;
  template<integral I>
  static constexpr uint64_t normalize(I input) {
    if constexpr (is_signed_v<I>) {
      __int128_t remainder = __int128_t(input) % __int128_t(Modulus::get());
      return uint64_t(remainder < 0 ? remainder + Modulus::get() : remainder);
    } else {
      return uint64_t(__uint128_t(input) % Modulus::get());
    }
  }
public:
nmod_base() = default;
  template<integral I>
  constexpr nmod_base(I input) : value(normalize(input)) {}
  static uint64_t mod() { return Modulus::get(); }
  static void setmod(uint64_t input)
    requires requires { Modulus::setmod(input); }
  {
    Modulus::setmod(input);
  }
  constexpr uint64_t val() const { return value; }
  explicit constexpr operator uint64_t() const { return value; }
  constexpr Self& operator+=(Self other) {
    value += other.value;
    if (value >= Modulus::get()) value -= Modulus::get();
    return static_cast<Self&>(*this);
  }
  constexpr Self& operator-=(Self other) {
    value = value >= other.value ? value - other.value : Modulus::get() - other.value + value;
    return static_cast<Self&>(*this);
  }
  constexpr Self& operator*=(Self other) {
    value = nmulmod(value, other.value, Modulus::get());
    return static_cast<Self&>(*this);
  }
  constexpr Self pow(uint64_t exponent) const {
    return raw(npowmod(value, exponent, Modulus::get()));
  }
  constexpr nmaybe<Self> inverse() const {
    if (!value) return {};
    auto result = nextgcd(Modulus::get(), value);
    if (result.gcd != 1) return {};
    __int128_t inverse = result.y % __int128_t(Modulus::get());
    if (inverse < 0) inverse += Modulus::get();
    return raw(uint64_t(inverse));
  }
  constexpr nmaybe<Self> tryinv() const { return inverse(); }
  constexpr Self inv() const {
    auto result = inverse();
    npre(result);
    return result.val();
  }
  constexpr Self inv(Self fallback) const {
    auto result = inverse();
    return result ? result.val() : move(fallback);
  }
  constexpr Self& operator/=(Self other) {
    return static_cast<Self&>(*this) *= other.inv();
  }
  constexpr Self operator-() const {
    return value ? raw(Modulus::get() - value) : static_cast<const Self&>(*this);
  }
  friend constexpr bool operator==(const Self& a, const Self& b) { return a.value == b.value; }
  static constexpr Self raw(uint64_t input) {
    npre(input < Modulus::get());
    Self result;
    result.value = input;
    return result;
  }
};
template<class Modulus>
class nmod_number : public nmod_base<nmod_number<Modulus>, Modulus> {
  using base = nmod_base<nmod_number<Modulus>, Modulus>;
public:
using base::base;
  static constexpr uint64_t mod() { return Modulus::get(); }
};
template<uint64_t Modulus>
  requires(Modulus > 0)
using nmodint = nmod_number<ni::fixed_modulus<Modulus>>;
template<int Tag = 0>
using nmod_dynamic = nmod_number<ni::dynamic_modulus<Tag>>;

template<class T>
concept nmod_value = requires(T value) {
  T::mod();
  value + value;
  -value;
};
template<class T>
  requires nmod_value<T>
struct nadd<T> {
  static constexpr nlaw laws = nlaw::associative | nlaw::identity |
                nlaw::inverse | nlaw::commutative;
  T id() const { return {}; }
  T operator()(T a, T b) const { return a + b; }
  T inv(T value) const { return -value; }
};
template<uint64_t Modulus>
using nmod = nmodint<Modulus>;
template<uint64_t Modulus>
using nmod_static = nmodint<Modulus>;
template<int Tag = 0>
using ndmod = nmod_dynamic<Tag>;
template<class T>
  requires nmod_value<T>
inline constexpr bool nadd_group<T> = true;
template<uint64_t Modulus>
inline constexpr bool nexact_field<nmodint<Modulus>> = nisprime(Modulus);
template<class T>
  requires nmod_value<T>
inline constexpr bool nsemiring_laws<nadd<T>, nmul<T>, T> = true;
template<class T>
  requires nmod_value<T>
inline constexpr bool naction_laws<naddsum_action<T>, T, T> = true;

template<class Mint>
class ncomb {
  nvector<Mint> factorial, inverse_factorial;
public:
explicit ncomb(int n = 0) : factorial(n + 1), inverse_factorial(n + 1) {
    npre(n >= 0 && n < INT_MAX);
    factorial[0] = Mint(1);
    for (int i = 1; i <= n; ++i)
      factorial[i] = factorial[i - 1] * Mint(i);
    inverse_factorial[n] = factorial[n].inverse().val();
    for (int i = n; i; --i)
      inverse_factorial[i - 1] = inverse_factorial[i] * Mint(i);
  }
  int len() const { return factorial.len() - 1; }
  Mint factorial_value(int n) const { return factorial[n]; }
  Mint choose(int n, int k) const {
    npre(0 <= n && n <= len());
    return k < 0 || k > n ? Mint{} : factorial[n] * inverse_factorial[k] * inverse_factorial[n - k];
  }
  Mint permute(int n, int k) const {
    npre(0 <= n && n <= len());
    return k < 0 || k > n ? Mint{} : factorial[n] * inverse_factorial[n - k];
  }
};
template<class T, class O = nadd<T>>
  requires ncommutative_monoid<O, T>
class nfenwick {
  O operation;
  int size = 0;
  nvector<T> tree;
public:
nfenwick() : tree(1, operation.id()) {}
  explicit nfenwick(int n, O operation = {})
  : operation(move(operation)), size(n), tree(size + 1, this->operation.id()) {
    npre(0 <= n && n < INT_MAX);
  }
  template<class A>
    requires requires(const A& source) { source[0]; }
  explicit nfenwick(const A& source, O operation = {}) : nfenwick(nlen(source), move(operation)) {
    nrep(i, size)
      tree[i + 1] = source[i];
    for (int i = 1; i <= size; ++i) {
      int next = i + (i & -i);
      if (next <= size)
        tree[next] = this->operation(tree[next], tree[i]);
    }
  }
  int len() const { return size; }
  bool empty() const { return !size; }
  const O& operation_value() const { return operation; }
  void clear() { fill(tree.begin(), tree.end(), operation.id()); }
  void add(int index, const T& value) {
    npre_index(index, size);
    for (++index; index <= size; index += index & -index)
      tree[index] = operation(tree[index], value);
  }
  T prefix(int right) const {
    npre(0 <= right && right <= size);
    T result = operation.id();
    for (; right; right -= right & -right)
      result = operation(tree[right], result);
    return result;
  }
  T fold(int left, int right) const
    requires ngroup<O, T>
  {
    npre_range(left, right, size);
    return operation(operation.inv(prefix(left)), prefix(right));
  }
  T get(int index) const
    requires ngroup<O, T>
  {
    return fold(index, index + 1);
  }
  template<class C = nless<>>
  int lower(const T& target, C less = {}) const {
    if (!less(operation.id(), target))
      return 0;
    int index = 0;
    T value = operation.id();
    for (int step = bit_floor(unsigned(size)); step; step >>= 1) {
      int next = index + step;
      if (next <= size) {
        T candidate = operation(value, tree[next]);
        if (less(candidate, target))
          index = next, value = move(candidate);
      }
    }
    return index == size ? npos : index;
  }
};
template<class T, class O = nadd<T>>
  requires nmonoid<O, T>
class nseg {
  O operation;
  int size = 0, base = 1;
  nvector<T> tree;
public:
nseg() : tree(2, operation.id()) {}
  explicit nseg(int n, O operation = {})
  : operation(move(operation)), size(n), base(nbitceil(n)), tree(base * 2, this->operation.id()) {
    npre(0 <= n && n <= (1 << 30));
  }
  template<class A>
    requires requires(const A& source) { source[0]; }
  explicit nseg(const A& source, O operation = {}) : nseg(nlen(source), move(operation)) {
    nrep(i, size)
      tree[base + i] = source[i];
    for (int i = base; --i;)
      tree[i] = this->operation(tree[i << 1], tree[i << 1 | 1]);
  }
  int len() const { return size; }
  bool empty() const { return !size; }
  const O& operation_value() const { return operation; }
  void clear() { fill(tree.begin(), tree.end(), operation.id()); }
  void set(int index, T value) {
    npre_index(index, size);
    int node = base + index;
    tree[node] = move(value);
    while (node >>= 1)
      tree[node] = operation(tree[node << 1], tree[node << 1 | 1]);
  }
  T get(int index) const {
    npre_index(index, size);
    return tree[base + index];
  }
  T fold(int left, int right) const {
    npre_range(left, right, size);
    T prefix = operation.id(), suffix = operation.id();
    for (int first = left + base, last = right + base; first < last;
      first >>= 1, last >>= 1) {
      if (first & 1)
        prefix = operation(prefix, tree[first++]);
      if (last & 1)
        suffix = operation(tree[--last], suffix);
    }
    return operation(prefix, suffix);
  }
  T fold() const { return size ? tree[1] : operation.id(); }
};
template<class T, class O = nadd<T>>
using nseg_iter = nseg<T, O>;
template<class S, class F, class M, class A>
class nlazyseg {
  [[no_unique_address]] M operation_;
  [[no_unique_address]] A action_;
  int size_ = 0;
  int base_ = 1;
  vector<S> tree_;
  vector<F> lazy_;
  vector<unsigned char> pending_;
  static int checked_size(int size) {
    npre(0 <= size && size <= (1 << 30));
    return size;
  }
  void put(int node, int length, const F& tag) {
    tree_[node] = action_.apply(move(tree_[node]), tag, length);
    if (pending_[node])
      lazy_[node] = action_.compose(tag, lazy_[node]);
    else {
      lazy_[node] = tag;
      pending_[node] = true;
    }
  }
  void push(int node, int left, int right) {
    if (!pending_[node] || right - left == 1)
      return;
    int middle = left + (right - left) / 2;
    put(node << 1, middle - left, lazy_[node]);
    put(node << 1 | 1, right - middle, lazy_[node]);
    lazy_[node] = action_.tag_id();
    pending_[node] = false;
  }
  void pull(int node) {
    tree_[node] = operation_(tree_[node << 1], tree_[node << 1 | 1]);
  }
  void apply0(int node, int left, int right, int query_left, int query_right,
      const F& tag) {
    if (query_left <= left && right <= query_right) {
      put(node, right - left, tag);
      return;
    }
    push(node, left, right);
    int middle = left + (right - left) / 2;
    if (query_left < middle)
      apply0(node << 1, left, middle, query_left, query_right, tag);
    if (middle < query_right)
      apply0(node << 1 | 1, middle, right, query_left, query_right, tag);
    pull(node);
  }
  S fold0(int node, int left, int right, int query_left, int query_right) {
    if (query_left <= left && right <= query_right)
      return tree_[node];
    push(node, left, right);
    int middle = left + (right - left) / 2;
    if (query_right <= middle)
      return fold0(node << 1, left, middle, query_left, query_right);
    if (middle <= query_left)
      return fold0(node << 1 | 1, middle, right, query_left, query_right);
    return operation_(fold0(node << 1, left, middle, query_left, query_right),
          fold0(node << 1 | 1, middle, right, query_left, query_right));
  }
  void set0(int node, int left, int right, int index, S value) {
    if (right - left == 1) {
      tree_[node] = move(value);
      lazy_[node] = action_.tag_id();
      pending_[node] = false;
      return;
    }
    push(node, left, right);
    int middle = left + (right - left) / 2;
    if (index < middle)
      set0(node << 1, left, middle, index, move(value));
    else
      set0(node << 1 | 1, middle, right, index, move(value));
    pull(node);
  }
public:
nlazyseg()
  : tree_(2, operation_.id()), lazy_(2, action_.tag_id()), pending_(2, false) {}
  explicit nlazyseg(int size, M operation = {}, A action = {})
  : operation_(move(operation)), action_(move(action)), size_(checked_size(size)),
  base_(nbitceil(size_)), tree_(size_t(2) * base_, operation_.id()),
  lazy_(size_t(2) * base_, action_.tag_id()), pending_(size_t(2) * base_, false) {}
  template<class V>
    requires requires(const V& value) {
      nlen(value);
      value[0];
    }
  explicit nlazyseg(const V& source, M operation = {}, A action = {})
  : nlazyseg(nlen(source), move(operation), move(action)) {
    nrep(index, size_)
      tree_[base_ + index] = source[index];
    for (int node = base_; --node > 0;)
      pull(node);
  }
  int len() const {
    return size_;
  }
  bool empty() const {
    return size_ == 0;
  }
  const M& operation() const {
    return operation_;
  }
  const A& action() const {
    return action_;
  }
  void clear() {
    fill(tree_.begin(), tree_.end(), operation_.id());
    fill(lazy_.begin(), lazy_.end(), action_.tag_id());
    fill(pending_.begin(), pending_.end(), false);
  }
  void apply(int left, int right, const F& tag) {
    npre_range(left, right, size_);
    if (left < right)
      apply0(1, 0, base_, left, right, tag);
  }
  S fold(int left, int right) {
    npre_range(left, right, size_);
    return left == right ? operation_.id() : fold0(1, 0, base_, left, right);
  }
  S fold() const {
    return size_ ? tree_[1] : operation_.id();
  }
  void set(int index, S value) {
    npre_index(index, size_);
    set0(1, 0, base_, index, move(value));
  }
  S get(int index) {
    npre_index(index, size_);
    return fold(index, index + 1);
  }
};

template<class T>
using nlazy_addsum = nlazyseg<T, T, nadd<T>, naddsum_action<T>>;
template<class T>
using nvector_stl = nvector<T>;

class nrng {
  uint64_t state_;
public:
explicit nrng(uint64_t seed = 0x243f6a8885a308d3ULL) : state_(seed) {}
  uint64_t operator()() {
    state_ += 0x9e3779b97f4a7c15ULL;
    uint64_t value = state_;
    value = (value ^ (value >> 30)) * 0xbf58476d1ce4e5b9ULL;
    value = (value ^ (value >> 27)) * 0x94d049bb133111ebULL;
    return value ^ (value >> 31);
  }
  template<integral I>
  I operator()(I bound) {
    npre(bound > 0);
    using U = make_unsigned_t<I>;
    return I((__uint128_t((*this)()) * U(bound)) >> 64);
  }
  template<integral I>
  I operator()(I first, I last) {
    npre(first < last);
    return I(first + (*this)(I(last - first)));
  }
};
inline nrng nrng_global;
inline mt19937 nrandom_engine;
void nseed(uint64_t seed) {
  nrng_global = nrng(seed);
  nrandom_engine.seed(uint32_t(seed));
}

template<class T, class C = nless<T>>
struct nheap {
  struct compare {
    C operation;
    bool operator()(const T& left, const T& right) const {
      return operation(right, left);
    }
  };
  priority_queue<T, vector<T>, compare> values;
  int len() const { return int(values.size()); }
  bool empty() const { return values.empty(); }
  void clear() {
    values = {};
  }
  void reserve(int) {}
  template<class... Args>
  T& push(Args&&... args) {
    values.emplace(forward<Args>(args)...);
    return const_cast<T&>(values.top());
  }
  const T& top() const {
    npre(!empty());
    return values.top();
  }
  T top(T fallback) const {
    return empty() ? move(fallback) : values.top();
  }
  T pop() {
    npre(!empty());
    T result = values.top();
    values.pop();
    return result;
  }
  T pop(T fallback) {
    return empty() ? move(fallback) : pop();
  }
};
template<class K, class V, class H = hash<K>, class E = equal_to<K>>
struct nmap_list {
  vector<pair<K, V>> values;
  E equal;
  int len() const { return int(values.size()); }
  bool empty() const { return values.empty(); }
  void reserve(int count) { values.reserve(count); }
  void clear() { values.clear(); }
  int find(const K& key) const {
    nrep(i, len())
      if (equal(values[i].first, key))
        return i;
    return npos;
  }
  bool has(const K& key) const { return find(key) != npos; }
  auto get(this auto&& self, const K& key) {
    int index = self.find(key);
    using pointer = decltype(addressof(self.values[index].second));
    return index == npos ? pointer{} : addressof(self.values[index].second);
  }
  V get(const K& key, V fallback) const {
    auto result = get(key);
    return result ? *result : move(fallback);
  }
  template<class X, class Y>
  bool ins(X&& key, Y&& value) {
    if (has(key))
      return false;
    values.emplace_back(forward<X>(key), forward<Y>(value));
    return true;
  }
  template<class X>
  V& set(const K& key, X&& value) {
    if (V* current = get(key))
      return *current = forward<X>(value);
    values.push_back({key, forward<X>(value)});
    return values.back().second;
  }
  int del(const K& key) {
    int i = find(key);
    if (i == npos)
      return 0;
    values[i] = move(values.back());
    values.pop_back();
    return 1;
  }
  decltype(auto) operator()(this auto&& self, const K& key) {
    auto result = self.get(key);
    npre(result);
    return *result;
  }
  decltype(auto) key(int index) const { return values[index].first; }
  decltype(auto) operator[](this auto&& self, int index) {
    return self.values[index].second;
  }
  auto entry(this auto&& self, int index) {
    return pair<decltype(self.key(index)), decltype(self[index])>{
      self.key(index), self[index]};
  }
};
template<class K, class V, class H = hash<K>, class E = equal_to<K>>
using nmap_flat = nmap_list<K, V, H, E>;
template<class K, class V, class H = hash<K>, class E = equal_to<K>>
using nmap_hash = nmap_list<K, V, H, E>;
template<class L, class R, class EL = nequal<>, class ER = nequal<>>
struct nrel {
  vector<pair<L, R>> edges;
  EL equal_left;
  ER equal_right;
  int len() const { return int(edges.size()); }
  bool empty() const { return edges.empty(); }
  bool has(const L& left, const R& right) const {
    for (const auto& edge : edges)
      if (equal_left(edge.first, left) && equal_right(edge.second, right))
        return true;
    return false;
  }
  bool add(const L& left, const R& right) {
    if (has(left, right))
      return false;
    edges.push_back({left, right});
    return true;
  }
  bool del(const L& left, const R& right) {
    nrep(i, len())
      if (equal_left(edges[i].first, left) && equal_right(edges[i].second, right)) {
        edges[i] = move(edges.back());
        edges.pop_back();
        return true;
      }
    return false;
  }
  nvector<R> image(const L& left) const {
    nvector<R> result;
    for (const auto& edge : edges)
      if (equal_left(edge.first, left))
        result.push(edge.second);
    return result;
  }
  nvector<L> preimage(const R& right) const {
    nvector<L> result;
    for (const auto& edge : edges)
      if (equal_right(edge.second, right))
        result.push(edge.first);
    return result;
  }
};

template<class A, class B, class H = hash<A>, class E = equal_to<A>>
struct npartial {
  nmap_list<A, B, H, E> values;
  int len() const { return values.len(); }
  bool empty() const { return values.empty(); }
  bool has(const A& key) const { return values.has(key); }
  auto to(this auto&& self, const A& key) { return self.values.get(key); }
  bool bind(const A& key, const B& value) { return values.ins(key, value); }
  B& set(const A& key, const B& value) { return values.set(key, value); }
  bool unbind(const A& key) { return values.del(key); }
  decltype(auto) operator()(this auto&& self, const A& key) { return self.values(key); }
};
template<class A, class B, class HA = hash<A>, class HB = hash<B>,
  class EA = equal_to<A>, class EB = equal_to<B>>
struct nbije {
  npartial<A, B, HA, EA> forward;
  npartial<B, A, HB, EB> backward;
  int len() const { return forward.len(); }
  bool hasl(const A& value) const { return forward.has(value); }
  bool hasr(const B& value) const { return backward.has(value); }
  const B* to(const A& value) const { return forward.to(value); }
  const A* from(const B& value) const { return backward.to(value); }
  bool bind(const A& left, const B& right) {
    if (hasl(left) || hasr(right))
      return to(left) && from(right) && *to(left) == right && *from(right) == left;
    forward.bind(left, right);
    backward.bind(right, left);
    return true;
  }
  void set(const A& left, const B& right) {
    unbindl(left);
    unbindr(right);
    npre(bind(left, right));
  }
  bool unbindl(const A& left) {
    auto right = to(left);
    if (!right)
      return false;
    B copy = *right;
    forward.unbind(left);
    backward.unbind(copy);
    return true;
  }
  bool unbindr(const B& right) {
    auto left = from(right);
    if (!left)
      return false;
    A copy = *left;
    backward.unbind(right);
    forward.unbind(copy);
    return true;
  }
  auto operator~() const {
    nbije<B, A, HB, HA, EB, EA> result;
    nrep(i, forward.len()) {
      const A& left = forward.values.key(i);
      result.bind(*forward.to(left), left);
    }
    return result;
  }
};
template<class A>
struct ncompress_result {
  nvector<A> values;
  int len() const { return values.len(); }
  int to(const A& value) const {
    int index = nlower(values, value);
    return index < len() && values[index] == value ? index : npos;
  }
  nmaybe<A> from(int index) const {
    return index < 0 || index >= len() ? nmaybe<A>{} : nmaybe<A>(values[index]);
  }
  const A& operator()(int index) const { return values[index]; }
  auto operator~() const {
    struct inverse {
      const ncompress_result* owner;
      const A* to(int index) const { return owner->from(index).ok() ? &owner->values[index] : nullptr; }
    };
    return inverse{this};
  }
};
template<class A>
ncompress_result<A> ncompress(const nvector<A>& source) {
  ncompress_result<A> result{source};
  sort(result.values.begin(), result.values.end());
  result.values.erase(unique(result.values.begin(), result.values.end()), result.values.end());
  return result;
}
enum class nbranch : unsigned char { left, take, right };

template<class S>
class nnode {
  const S* owner = nullptr;
  int handle = 0;
  uint64_t epoch = 0;
  nnode(const S* owner, int handle, uint64_t epoch)
  : owner(owner), handle(handle), epoch(epoch) {}
  friend S;
public:
using value_type = typename S::value_type;
  using info_type = typename S::info_type;
  nnode() = default;
  bool current() const { return owner && epoch == owner->nnode_epoch(); }
  bool ok() const { return current() && handle && owner->nnode_alive(handle); }
  explicit operator bool() const { return ok(); }
  const value_type& val() const {
    npre(ok());
    return owner->nnode_val(handle);
  }
  int count() const {
    npre(current());
    return owner->nnode_count(handle);
  }
  int len() const {
    npre(current());
    return owner->nnode_len(handle);
  }
  info_type info() const {
    npre(current());
    return owner->nnode_info(handle);
  }
  nnode left() const {
    npre(current());
    return {owner, owner->nnode_left(handle), epoch};
  }
  nnode right() const {
    npre(current());
    return {owner, owner->nnode_right(handle), epoch};
  }
};
template<class S>
concept nnode_tree = requires(const S& tree) {
  { tree.root() } -> same_as<nnode<S>>;
};
template<class S>
concept naugmented_tree = nnode_tree<S> && requires(const S& tree) {
  typename S::augment_type;
  tree.augment();
};
template<nnode_tree S, class F>
nnode<S> nwalk(const S& tree, F decide) {
  auto node = tree.root();
  while (node) {
    nbranch branch = invoke(decide, node);
    if (branch == nbranch::left)
      node = node.left();
    else if (branch == nbranch::right)
      node = node.right();
    else
      return node;
  }
  return node;
}
template<class A, class T>
concept naugment = copyable<typename A::info_type> && requires(
const A& augment, const T& value, int count, typename A::info_type info) {
  augment.id();
  augment.one(value, count);
  augment.op(info, info);
};

template<class T>
struct nempty_augment {
  using info_type = monostate;
  info_type id() const { return {}; }
  info_type one(const T&, int) const { return {}; }
  info_type op(info_type, info_type) const { return {}; }
};
template<class T, class C = nless<T>, bool Multi = false,
  class A = nempty_augment<T>, bool Splay = false, bool Nodes = true>
class nordered_tree {
public:
using value_type = T;
  using augment_type = A;
  using info_type = typename A::info_type;
  using node_view = nnode<nordered_tree>;
  static constexpr bool nnode_enabled = Nodes;
private:
struct node_data {
    T value{};
    int count = 1, left = 0, right = 0, size = 1;
    info_type info{};
  };
  map<T, int, C> counts;
  vector<node_data> nodes{{}};
  int root_handle = 0;
  C compare;
  A augmenter;
  mutable uint64_t epoch = 1;
  int size_of(int handle) const { return handle ? nodes[handle].size : 0; }
  info_type info_of(int handle) const {
    return handle ? nodes[handle].info : augmenter.id();
  }
  void pull(int handle) {
    auto& node = nodes[handle];
    node.size = size_of(node.left) + node.count + size_of(node.right);
    node.info = augmenter.op(
    augmenter.op(info_of(node.left), augmenter.one(node.value, node.count)),
    info_of(node.right));
  }
  int build(int left, int right) {
    if (left >= right)
      return 0;
    int middle = (left + right) / 2;
    auto iterator = counts.begin();
    advance(iterator, middle);
    int handle = int(nodes.size());
    nodes.push_back(node_data{iterator->first, iterator->second});
    nodes[handle].left = build(left, middle);
    nodes[handle].right = build(middle + 1, right);
    pull(handle);
    return handle;
  }
  void rebuild() {
    nodes.assign(1, {});
    root_handle = build(0, int(counts.size()));
    ++epoch;
  }
public:
nordered_tree() = default;
  explicit nordered_tree(C value) : compare(move(value)) {}
  explicit nordered_tree(A value) requires(!same_as<C, A>) : augmenter(move(value)) {}
  nordered_tree(C c, A a) : compare(move(c)), augmenter(move(a)) {}
  nordered_tree(initializer_list<T> values) {
    for (const T& value : values)
      ins(value);
  }
  int len() const { return size_of(root_handle); }
  bool empty() const { return counts.empty(); }
  bool has(const T& value) const {
    bool result = counts.contains(value);
    if constexpr (Splay)
      ++epoch;
    return result;
  }
  int count(const T& value) const {
    auto iterator = counts.find(value);
    if constexpr (Splay)
      ++epoch;
    return iterator == counts.end() ? 0 : iterator->second;
  }
  int ins(const T& value, int multiplicity = 1) {
    npre(multiplicity > 0);
    auto [iterator, inserted] = counts.emplace(value, multiplicity);
    if (!inserted) {
      if constexpr (!Multi)
        return 0;
      iterator->second += multiplicity;
    }
    rebuild();
    return multiplicity;
  }
  int del(const T& value, int multiplicity = 1) {
    npre(multiplicity > 0);
    auto iterator = counts.find(value);
    if (iterator == counts.end())
      return 0;
    int removed = Multi ? min(multiplicity, iterator->second) : 1;
    if (removed == iterator->second)
      counts.erase(iterator);
    else
      iterator->second -= removed;
    rebuild();
    return removed;
  }
  int rank(const T& value) const {
    int result = 0;
    for (auto iterator = counts.begin(); iterator != counts.lower_bound(value); ++iterator)
      result += iterator->second;
    return result;
  }
  nmaybe<T> lower(const T& value) const {
    auto iterator = counts.lower_bound(value);
    return iterator == counts.end() ? nmaybe<T>{} : nmaybe<T>(iterator->first);
  }
  nmaybe<T> upper(const T& value) const {
    auto iterator = counts.upper_bound(value);
    return iterator == counts.end() ? nmaybe<T>{} : nmaybe<T>(iterator->first);
  }
  nmaybe<T> kth(int index) const {
    if (index < 0 || index >= len())
      return {};
    for (const auto& [value, multiplicity] : counts) {
      if (index < multiplicity)
        return value;
      index -= multiplicity;
    }
    return {};
  }
  T operator[](int index) const {
    auto result = kth(index);
    npre(result.ok());
    return result.val();
  }
  nordered_tree& operator|=(const nordered_tree& other) {
    for (const auto& [value, count] : other.counts)
      ins(value, count);
    return *this;
  }
  nordered_tree& operator&=(const nordered_tree& other) {
    for (auto iterator = counts.begin(); iterator != counts.end();)
      if (!other.counts.contains(iterator->first))
        iterator = counts.erase(iterator);
      else
        ++iterator;
    rebuild();
    return *this;
  }
  nordered_tree& operator-=(const nordered_tree& other) {
    for (const auto& [value, count] : other.counts)
      del(value, count);
    return *this;
  }
  nordered_tree& operator^=(const nordered_tree& other) {
    for (const auto& [value, count] : other.counts)
      if (!del(value, count))
        ins(value, count);
    return *this;
  }
  friend nordered_tree operator|(nordered_tree a, const nordered_tree& b) { return a |= b; }
  friend nordered_tree operator&(nordered_tree a, const nordered_tree& b) { return a &= b; }
  friend nordered_tree operator-(nordered_tree a, const nordered_tree& b) { return a -= b; }
  friend nordered_tree operator^(nordered_tree a, const nordered_tree& b) { return a ^= b; }
  friend bool operator==(const nordered_tree& a, const nordered_tree& b) {
    return a.counts == b.counts;
  }
  const A& augment() const { return augmenter; }
  node_view root() const requires Nodes { return {this, root_handle, epoch}; }
  template<class F>
  node_view walk(F decide) const { return nwalk(*this, move(decide)); }
  template<class P>
  node_view first_prefix(P predicate) const {
    auto node = root();
    auto prefix = augmenter.id();
    while (node) {
      auto left = augmenter.op(prefix, node.left().info());
      if (invoke(predicate, left)) {
        node = node.left();
        continue;
      }
      auto through = augmenter.op(left, augmenter.one(node.val(), node.count()));
      if (invoke(predicate, through))
        return node;
      prefix = move(through);
      node = node.right();
    }
    return node;
  }
  template<class P>
  node_view last_suffix(P predicate) const {
    auto node = root();
    auto suffix = augmenter.id();
    while (node) {
      auto right = augmenter.op(node.right().info(), suffix);
      if (invoke(predicate, right)) {
        node = node.right();
        continue;
      }
      auto through = augmenter.op(augmenter.one(node.val(), node.count()), right);
      if (invoke(predicate, through))
        return node;
      suffix = move(through);
      node = node.left();
    }
    return node;
  }
  void clear() { counts.clear(); rebuild(); }
  uint64_t nnode_epoch() const { return epoch; }
  bool nnode_alive(int handle) const { return 0 < handle && handle < int(nodes.size()); }
  const T& nnode_val(int handle) const { return nodes[handle].value; }
  int nnode_count(int handle) const { return handle ? nodes[handle].count : 0; }
  int nnode_len(int handle) const { return size_of(handle); }
  info_type nnode_info(int handle) const { return info_of(handle); }
  int nnode_left(int handle) const { return handle ? nodes[handle].left : 0; }
  int nnode_right(int handle) const { return handle ? nodes[handle].right : 0; }
};
template<class T, class C = nless<T>, bool Multi = false,
  class A = nempty_augment<T>>
using nset_fhq = nordered_tree<T, C, Multi, A, false>;
template<class T, class C = nless<T>, bool Multi = false,
  class A = nempty_augment<T>>
using nset_splay = nordered_tree<T, C, Multi, A, true>;
template<class T, class C = nless<T>>
using nset = nset_fhq<T, C>;

template<class T, class C = nless<T>>
using nbag = nset_fhq<T, C, true>;
template<class T, class C = nless<T>>
using nset_stl = nordered_tree<T, C, false, nempty_augment<T>, false, false>;
template<class T>
struct ndeque : deque<T> {
  using deque<T>::deque;
  using deque<T>::operator=;
  int len() const { return int(this->size()); }
  template<class U>
  void pushl(U&& value) { this->push_front(forward<U>(value)); }
  template<class U>
  void pushr(U&& value) { this->push_back(forward<U>(value)); }
  T popl() {
    npre(!this->empty());
    T value = move(this->front());
    this->pop_front();
    return value;
  }
  T popl(T fallback) {
    return this->empty() ? move(fallback) : popl();
  }
  T popr() {
    npre(!this->empty());
    T value = move(this->back());
    this->pop_back();
    return value;
  }
  T popr(T fallback) {
    return this->empty() ? move(fallback) : popr();
  }
};
template<class T>
using ndeque_ring = ndeque<T>;
template<class T>
using ndeque_stl = ndeque<T>;

namespace ni {
template<class T>
struct hold {
  using value_type = remove_reference_t<T>;
  static constexpr bool borrowed = is_lvalue_reference_v<T>;
  using storage_type = conditional_t<borrowed, value_type*, value_type>;
  [[no_unique_address]] storage_type storage;
  hold(T&& value)
  : storage([&]() -> storage_type {
      if constexpr (borrowed)
        return addressof(value);
      else
        return forward<T>(value);
    }()) {}
  template<class Self>
  decltype(auto) get(this Self&& self) {
    if constexpr (borrowed)
      return *self.storage;
    else
      return (self.storage);
  }
};
template<class T>
hold(T&&) -> hold<T&&>;
template<class T>
struct cursor_base {
  hold<T> owner;
  int index = 0;
  cursor_base(T&& value) : owner(forward<T>(value)) {}
  bool ok() const { return index < nlen(owner.get()); }
  decltype(auto) val() { return owner.get()[index]; }
  int idx() const { return index; }
  void next() { ++index; }
};
}

template<class T, int Rank>
  requires(Rank > 0)
struct narray : nvector<T> {
  using coord_type = array<int, Rank>;
  using base = nvector<T>;
  coord_type shape_{};
  static int volume(const coord_type& shape) {
    long long result = 1;
    for (int extent : shape) {
      npre(extent >= 0);
      result *= extent;
      npre(result <= INT_MAX);
    }
    return int(result);
  }
  using base::base;
  narray() = default;
  explicit narray(coord_type shape) : base(volume(shape)), shape_(shape) {}
  narray(coord_type shape, const T& value)
  : base(volume(shape), value), shape_(shape) {}
  static constexpr int rank() { return Rank; }
  int dim(int axis, int fallback = npos) const {
    return 0 <= axis && axis < Rank ? shape_[axis] : fallback;
  }
  int pos(const coord_type& coordinate, int fallback = npos) const {
    int result = 0;
    nrep(axis, Rank) {
      if (coordinate[axis] < 0 || coordinate[axis] >= shape_[axis])
        return fallback;
      result = result * shape_[axis] + coordinate[axis];
    }
    return result;
  }
  template<class Self>
  decltype(auto) operator()(this Self&& self, const coord_type& coordinate) {
    int index = self.pos(coordinate);
    npre(index != npos);
    return self.base::operator[](index);
  }
  template<class Self, class... I>
    requires(sizeof...(I) == Rank)
  decltype(auto) operator()(this Self&& self, I... coordinate) {
    return self(coord_type{int(coordinate)...});
  }
};

namespace ni {
template<class T, bool Strided>
struct affine_access {
  T* data = nullptr;
  [[no_unique_address]] conditional_t<Strided, ptrdiff_t, monostate> step{};
  affine_access() = default;
  affine_access(T* data, ptrdiff_t stride = 1) : data(data) {
    if constexpr (Strided)
      step = stride;
  }
  T& operator()(int index) {
    if constexpr (Strided)
      return data[ptrdiff_t(index) * step];
    else
      return data[index];
  }
  ptrdiff_t stride() const {
    if constexpr (Strided)
      return step;
    else
      return 1;
  }
  T* raw_data() { return data; }
};
template<class T>
using contiguous_view = affine_access<T, false>;
template<class T>
using affine_view = affine_access<T, true>;

template<class T, bool Strided>
struct grid_access {
  T* data = nullptr;
  int row_count = 0;
  int column_count = 0;
  ptrdiff_t row_step = 0;
  ptrdiff_t column_step = 1;
  grid_access() = default;
  grid_access(T* data, int rows, int columns)
  : data(data), row_count(rows), column_count(columns), row_step(columns) {}
  grid_access(T* data, int rows, int columns, ptrdiff_t row_step,
      ptrdiff_t column_step)
  : data(data), row_count(rows), column_count(columns),
  row_step(row_step), column_step(column_step) {}
  T& operator()(int index) {
    return (*this)(index / column_count, index % column_count);
  }
  T& operator()(int row, int column) {
    return data[ptrdiff_t(row) * row_step + ptrdiff_t(column) * column_step];
  }
  int rows() const {
    return row_count;
  }
  int cols() const {
    return column_count;
  }
  T* raw_data() requires(!Strided) { return data; }
  T* row_data(int row) requires(!Strided) {
    return data + ptrdiff_t(row) * row_step;
  }
};
template<class T>
using grid_view = grid_access<T, false>;
template<class T>
using strided_grid_view = grid_access<T, true>;
template<class F, bool Grid>
struct indexed_access;
template<class F>
struct indexed_access<F, false> {
  F access;
  decltype(auto) operator()(int index) {
    return invoke(access, index);
  }
};

template<class F>
struct indexed_access<F, true> {
  F access;
  int row_count = 0;
  int column_count = 0;
  decltype(auto) operator()(int index) {
    return invoke(access, index / column_count, index % column_count);
  }
  decltype(auto) operator()(int row, int column) {
    return invoke(access, row, column);
  }
  int rows() const {
    return row_count;
  }
  int cols() const {
    return column_count;
  }
};
template<class F>
using indexed_view = indexed_access<F, false>;
template<class F>
using indexed_grid_view = indexed_access<F, true>;
template<class V>
struct view_iterator {
  V* owner;
  int index;
  using difference_type = int;
  using value_type = remove_cvref_t<decltype(declval<V&>()[0])>;
  using iterator_category = random_access_iterator_tag;
  decltype(auto) operator*() const {
    return (*owner)[index];
  }
  view_iterator& operator++() {
    ++index;
    return *this;
  }
  view_iterator operator++(int) {
    auto result = *this;
    ++*this;
    return result;
  }
  view_iterator& operator--() {
    --index;
    return *this;
  }
  view_iterator operator--(int) {
    auto result = *this;
    --*this;
    return result;
  }
  view_iterator& operator+=(int distance) {
    index += distance;
    return *this;
  }
  view_iterator& operator-=(int distance) {
    index -= distance;
    return *this;
  }
  decltype(auto) operator[](int distance) const {
    return (*owner)[index + distance];
  }
  friend view_iterator operator+(view_iterator it, int distance) {
    return it += distance;
  }
  friend view_iterator operator-(view_iterator it, int distance) {
    return it -= distance;
  }
  friend int operator-(view_iterator left, view_iterator right) {
    return left.index - right.index;
  }
  friend bool operator==(view_iterator left, view_iterator right) {
    return left.index == right.index;
  }
  friend auto operator<=>(view_iterator left, view_iterator right) {
    return left.index <=> right.index;
  }
};
}

template<class T, class F = ni::contiguous_view<T>>
struct nview {
  using element_type = T;
  using value_type = remove_cv_t<T>;
  using nview_tag = void;
  using nrange_tag = void;
  int size_ = 0;
  [[no_unique_address]] mutable F access_{};
  nview() = default;
  explicit nview(int size, auto access)
  : size_(size), access_(move(access)) {
    npre(size >= 0);
  }
  nview(int rows, int columns, auto access)
  : size_(rows * columns), access_{move(access), rows, columns} {
    npre(rows >= 0 && columns >= 0);
  }
  nview(T* data, int size)
    requires same_as<F, ni::contiguous_view<T>>
  : size_(size), access_{data} {
    npre(size >= 0 && (!size || data));
  }
  nview(T* data, int rows, int columns)
    requires same_as<F, ni::grid_view<T>>
  : size_(rows * columns), access_{data, rows, columns} {
    npre(rows >= 0 && columns >= 0);
    npre(!size_ || data);
  }
  nview(T* data, int rows, int columns, ptrdiff_t row_step, ptrdiff_t column_step)
    requires same_as<F, ni::strided_grid_view<T>>
  : size_(rows * columns),
  access_{data, rows, columns, row_step, column_step} {
    npre(rows >= 0 && columns >= 0);
    npre(!size_ || data);
  }
  template<size_t N>
  nview(T (&data)[N])
    requires same_as<F, ni::contiguous_view<T>>
  : size_(int(N)), access_{data} {}
  template<class U, class G>
    requires same_as<F, ni::contiguous_view<T>> &&
      same_as<G, ni::contiguous_view<U>> && is_const_v<T>
  nview(const nview<U, G>& other)
  : size_(other.len()), access_{other.data()} {}
  int len() const {
    return size_;
  }
  bool empty() const {
    return size_ == 0;
  }
  decltype(auto) operator[](int index) const {
    npre_index(index, size_);
    return access_(index);
  }
  template<class... I>
  decltype(auto) operator()(I... coordinate) const {
    return access_(coordinate...);
  }
  auto data() const requires requires(F& access) { access.raw_data(); } {
    return access_.raw_data();
  }
  auto row_data(int row) const requires requires(F& access) { access.row_data(row); } {
    return access_.row_data(row);
  }
  int rows() const requires requires(F& access) { access.rows(); } {
    return access_.rows();
  }
  int cols() const requires requires(F& access) { access.cols(); } {
    return access_.cols();
  }
  int dim(int axis, int fallback = npos) const
    requires requires(F& access) { access.rows(); access.cols(); } {
    return axis == 0 ? rows() : axis == 1 ? cols() : fallback;
  }
  using iterator = ni::view_iterator<nview>;
  iterator begin() {
    return {this, 0};
  }
  iterator end() {
    return {this, size_};
  }
  auto get(int index) const requires is_lvalue_reference_v<decltype((*this)[0])> {
    using pointer = add_pointer_t<remove_reference_t<decltype((*this)[0])>>;
    return 0 <= index && index < size_ ? addressof((*this)[index]) : pointer{};
  }
};
template<class T>
nview(T*, int) -> nview<T>;
template<class T, size_t N>
nview(T (&)[N]) -> nview<T>;
template<class T>
nview(T*, int, int) -> nview<T, ni::grid_view<T>>;
template<class T>
nview(T*, int, int, ptrdiff_t, ptrdiff_t)
  -> nview<T, ni::strided_grid_view<T>>;
template<class F>
nview(int, F)
  -> nview<remove_cvref_t<invoke_result_t<F&, int>>, ni::indexed_view<F>>;
template<class F>
nview(int, int, F)
  -> nview<remove_cvref_t<invoke_result_t<F&, int, int>>,
    ni::indexed_grid_view<F>>;
template<class A, class F>
auto nview_capture(A&& value, int size, F access) {
  auto source = ni::hold(forward<A>(value));
  return nview(size, [source = move(source), access = move(access)](int index) mutable
          -> decltype(auto) {
            return invoke(access, source.get(), index);
          });
}

template<class A>
concept nindexed = requires(A& value, const A& constant, int index) {
  { nlen(constant) } -> same_as<int>;
  value[index];
  constant[index];
};
template<class A>
using nindex_reference_t = decltype(declval<A&>()[0]);
template<class A>
using nindex_value_t = remove_cvref_t<nindex_reference_t<A>>;
template<class A>
concept nreference_indexed =
nindexed<A> && is_lvalue_reference_v<nindex_reference_t<A>>;
template<class A>
concept nswappable_indexed =
nreference_indexed<A> && requires(A& value) { swap(value[0], value[0]); };

template<class A>
concept ncontiguous_indexed =
nindexed<A> && requires(A& value) { value.data(); };
template<class A>
concept nresizable = requires(A& value, int size) { value.resize(size); };
template<class A>
concept nview_object = requires { typename remove_cvref_t<A>::nview_tag; };
template<class A>
concept nrange_object = requires { typename remove_cvref_t<A>::nrange_tag; };
template<class A>
concept nviewable_indexed =
nindexed<remove_reference_t<A>> &&
(is_lvalue_reference_v<A> || nrange_object<remove_cvref_t<A>> ||
nview_object<remove_cvref_t<A>>) &&
(!nrange_object<remove_cvref_t<A>> ||
constructible_from<remove_cvref_t<A>, A>);

template<class A>
  requires nviewable_indexed<A&&> && (!nview_object<remove_cvref_t<A>>)
auto nall(A&& value) {
  if constexpr (is_lvalue_reference_v<A&&>) {
    if constexpr (requires(A& item) { item.data(); })
      return nview(value.data(), nlen(value));
    else
      return nview(nlen(value), [&value](int index) -> decltype(auto) {
        return value[index];
      });
  } else {
    return nview(nlen(value),
        [value = forward<A>(value)](int index) mutable -> decltype(auto) {
            return value[index];
          });
  }
}
template<class T, class F>
auto nall(nview<T, F> value) {
  return value;
}
template<class T, class F>
auto nsub(nview<T, F> value, int left, int right) {
  npre(0 <= left && left <= right && right <= value.len());
  int size = right - left;
  if constexpr (same_as<F, ni::contiguous_view<T>>) {
    return nview<T>(size, ni::contiguous_view<T>{value.data() + left});
  } else if constexpr (same_as<F, ni::affine_view<T>>) {
    return nview<T, ni::affine_view<T>>(
    size, ni::affine_view<T>{value.data() +
                  ptrdiff_t(left) * value.access_.stride(),
                value.access_.stride()});
  } else {
    return nview(size, [value = move(value), left](int index) -> decltype(auto) {
      return value[left + index];
    });
  }
}
template<class A>
auto nsub(A& value, int left, int right) {
  return nsub(nall(value), left, right);
}
template<class T, class F>
auto nstride(nview<T, F> value, int first, int last, int step) {
  npre(step != 0);
  int size = value.len();
  long long distance = step > 0 ? static_cast<long long>(last) - first
              : static_cast<long long>(first) - last;
  if (step > 0)
    npre(0 <= first && first <= last && last <= size);
  else
    npre(-1 <= last && last <= first && first <= size);
  int count = int(distance / abs(step) + (distance % abs(step) != 0));
  npre(count >= 0);
  if constexpr (same_as<F, ni::contiguous_view<T>> ||
      same_as<F, ni::affine_view<T>>) {
    ptrdiff_t stride = value.access_.stride();
    return nview<T, ni::affine_view<T>>(
    count, ni::affine_view<T>{value.data() + ptrdiff_t(first) * stride,
                stride * step});
  } else {
    return nview(count,
        [value = move(value), first, step](int index) -> decltype(auto) {
            return value[first + index * step];
          });
  }
}

template<class A>
auto nstride(A& value, int first, int last, int step) {
  return nstride(nall(value), first, last, step);
}
template<class T, class F>
auto nreverse(nview<T, F> value) {
  if constexpr (same_as<F, ni::contiguous_view<T>> ||
      same_as<F, ni::affine_view<T>>) {
    ptrdiff_t stride = value.access_.stride();
    int size = value.len();
    return nview<T, ni::affine_view<T>>(
    size, ni::affine_view<T>{
          value.data() + (size ? ptrdiff_t(size - 1) * stride : 0), -stride});
  } else {
    int size = value.len();
    return nview(size, [value = move(value)](int index) -> decltype(auto) {
      return value[value.len() - 1 - index];
    });
  }
}
template<class A>
auto nreverse(A& value) {
  return nreverse(nall(value));
}
template<class T>
auto nrow(nview<T, ni::grid_view<T>> value, int row) {
  npre(0 <= row && row < value.rows());
  return nview(value.row_data(row), value.cols());
}
template<class A>
auto nrow(A&& matrix, int row) {
  npre(0 <= row && row < matrix.rows());
  int columns = matrix.cols();
  return nview_capture(forward<A>(matrix), columns,
          [row](auto& value, int column) -> decltype(auto) {
            return value(row, column);
          });
}

template<class A>
auto ncolumn(A&& matrix, int column) {
  npre(0 <= column && column < matrix.cols());
  int rows = matrix.rows();
  return nview_capture(forward<A>(matrix), rows,
          [column](auto& value, int row) -> decltype(auto) {
            return value(row, column);
          });
}
template<class A>
auto ndiagonal(A&& matrix, int offset = 0) {
  int rows = matrix.rows(), columns = matrix.cols();
  npre(-rows <= offset && offset <= columns);
  int first_row = max(0, -offset), first_column = max(0, offset);
  int size = min(rows - first_row, columns - first_column);
  return nview_capture(
  forward<A>(matrix), size,
  [first_row, first_column](auto& value, int index) -> decltype(auto) {
      return value(first_row + index, first_column + index);
    });
}
template<class A>
auto nproject(A&& value, auto projection) {
  auto view = nall(forward<A>(value));
  return nview(view.len(), [view = move(view), projection = move(projection)](int index)
              -> decltype(auto) {
    return invoke(projection, view[index]);
  });
}
template<class A, class F>
int ni_nfind_index(A&& value, F predicate, int fallback = npos) {
  auto&& sequence = forward<A>(value);
  nrep(index, nlen(sequence))
    if (invoke(predicate, sequence[index]))
      return index;
  return fallback;
}
template<class A, class F>
int ni_ncount_if(A&& value, F predicate) {
  auto&& sequence = forward<A>(value);
  int result = 0;
  nrep(index, nlen(sequence))
    result += invoke(predicate, sequence[index]);
  return result;
}

template<class A, class X, class P>
int nfind(const A& value, const X& target, P projection = {}, int fallback = npos) {
  return ni_nfind_index(value, [&](auto&& item) {
    return invoke(projection, forward<decltype(item)>(item)) == target;
  }, fallback);
}
template<class A, class X>
int nfind(const A& value, const X& target, int fallback = npos) {
  return nfind(value, target, nidentity{}, fallback);
}
template<class A, class X, class C, class P>
int ni_nbound(const A& value, const X& target, C compare, P projection, bool upper) {
  int left = 0, right = nlen(value);
  while (left < right) {
    int middle = midpoint(left, right);
    if (upper ? invoke(compare, target, invoke(projection, value[middle]))
      : !invoke(compare, invoke(projection, value[middle]), target))
      right = middle;
    else
      left = middle + 1;
  }
  return left;
}
template<class A, class X, class C = nless<>, class P = nidentity>
int nlower(const A& value, const X& target, C compare = {}, P projection = {}) {
  return ni_nbound(value, target, move(compare), move(projection), false);
}
template<class A, class X, class C = nless<>, class P = nidentity>
int nupper(const A& value, const X& target, C compare = {}, P projection = {}) {
  return ni_nbound(value, target, move(compare), move(projection), true);
}

template<class A, class X, class C = nless<>, class P = nidentity>
int nfind_sorted(const A& value, const X& target, C compare = {}, P projection = {},
      int fallback = npos) {
  int index = nlower(value, target, compare, projection);
  if (index == nlen(value))
    return fallback;
  auto&& current = invoke(projection, value[index]);
  return !invoke(compare, target, current) && !invoke(compare, current, target)
    ? index
    : fallback;
}
template<class A, class X, class C>
int nfind_sorted(const A& value, const X& target, C compare, int fallback) {
  return nfind_sorted(value, target, move(compare), nidentity{}, fallback);
}
template<class A, class C = nless<>, class P = nidentity>
void nsort(A&& value, C compare = {}, P projection = {}) {
  auto before = [&](int left, int right) {
    return invoke(compare, invoke(projection, value[left]),
        invoke(projection, value[right]));
  };
  auto sift = [&](int root, int count) {
    while (2 * root + 1 < count) {
      int child = 2 * root + 1;
      if (child + 1 < count && before(child, child + 1))
        ++child;
      if (!before(root, child))
        break;
      swap(value[root], value[child]);
      root = child;
    }
  };
  nrrep(root, nlen(value) / 2)
    sift(root, nlen(value));
  for (int count = nlen(value); count-- > 1;) {
    swap(value[0], value[count]);
    sift(0, count);
  }
}
template<class A, class X>
void nfill(A&& value, const X& fill_value) {
  nrep(index, nlen(value))
    value[index] = fill_value;
}
template<class D, class S, class P = nidentity>
void nassign(D&& destination, const S& source, P projection = {}) {
  int size = nlen(destination);
  auto cursor = nenumerate(source);
  if constexpr (nhas_len<S> || nhas_size<S>)
    npre(size == nlen(source));
  nrep(index, size) {
    npre(cursor.ok());
    destination[index] = invoke(projection, cursor.val());
    cursor.next();
  }
  npre(!cursor.ok());
}

template<class A, class B>
void nswap_ranges(A&& left, B&& right) {
  npre(nlen(left) == nlen(right));
  nrep(index, nlen(left))
    swap(left[index], right[index]);
}
template<class A>
void nreverse_inplace(A&& value, int left = 0, int right = npos) {
  if (right == npos)
    right = nlen(value);
  npre(0 <= left && left <= right && right <= nlen(value));
  while (left < --right)
    swap(value[left++], value[right]);
}
template<class A, class C = nless<>, class P = nidentity>
int nargmin(const A& value, C compare = {}, P projection = {}) {
  if (!nlen(value))
    return npos;
  int result = 0;
  for (int index = 1; index < nlen(value); ++index)
    if (invoke(compare, invoke(projection, value[index]),
      invoke(projection, value[result])))
      result = index;
  return result;
}
template<class A, class C = nless<>, class P = nidentity>
int nargmax(const A& value, C compare = {}, P projection = {}) {
  if (!nlen(value))
    return npos;
  int result = 0;
  for (int index = 1; index < nlen(value); ++index)
    if (invoke(compare, invoke(projection, value[result]),
      invoke(projection, value[index])))
      result = index;
  return result;
}
template<class A, class P = nidentity>
bool ncontains(A&& value, const auto& target, P projection = {}) {
  return nfind(forward<A>(value), target, move(projection)) != npos;
}

template<class A, class F, class P = nidentity>
int nfind_if(A&& value, F predicate, P projection = {}, int fallback = npos) {
  return ni_nfind_index(forward<A>(value), [&](auto&& item) {
    return invoke(predicate, invoke(projection, forward<decltype(item)>(item)));
  }, fallback);
}
template<class A, class P = nidentity>
int ncount(A&& value, const auto& target, P projection = {}) {
  return ni_ncount_if(forward<A>(value), [&](auto&& item) {
    return invoke(projection, forward<decltype(item)>(item)) == target;
  });
}
template<class A, class F, class P = nidentity>
int ncount_if(A&& value, F predicate, P projection = {}) {
  return ni_ncount_if(forward<A>(value), [&](auto&& item) {
    return invoke(predicate, invoke(projection, forward<decltype(item)>(item)));
  });
}
template<class A, class F, class P = nidentity>
bool nall_of(A&& value, F predicate, P projection = {}) {
  return ni_nfind_index(forward<A>(value), [&](auto&& item) {
    return !invoke(predicate, invoke(projection, forward<decltype(item)>(item)));
  }) == npos;
}
template<class A, class F, class P = nidentity>
bool nany_of(A&& value, F predicate, P projection = {}) {
  return ni_nfind_index(forward<A>(value), [&](auto&& item) {
    return invoke(predicate, invoke(projection, forward<decltype(item)>(item)));
  }) != npos;
}

template<class A, class F, class P = nidentity>
bool nnone_of(A&& value, F predicate, P projection = {}) {
  return !nany_of(forward<A>(value), move(predicate), move(projection));
}
template<class A, class P = nidentity,
  class O = nadd<remove_cvref_t<invoke_result_t<P&, decltype(declval<const A&>()[0])>>>>
auto nfold(const A& value, O operation = {}, P projection = {}) {
  using T = remove_cvref_t<invoke_result_t<P&, decltype(value[0])>>;
  T result = operation.id();
  nrep(index, nlen(value))
    result = operation(move(result), invoke(projection, value[index]));
  return result;
}
template<class A, class B, class E = nequal<>, class PA = nidentity, class PB = nidentity>
bool nsame(const A& left, const B& right, E equal = {}, PA lp = {}, PB rp = {}) {
  if (nlen(left) != nlen(right))
    return false;
  nrep(index, nlen(left))
    if (!invoke(equal, invoke(lp, left[index]), invoke(rp, right[index])))
      return false;
  return true;
}
template<class A, class O = nadd<nindex_value_t<const A>>>
auto nscan(const A& value, O operation = {}) {
  using T = nindex_value_t<const A>;
  nvector<T> result;
  result.reserve(nlen(value) + 1);
  result.push(operation.id());
  nrep(index, nlen(value))
    result.push(operation(result.back(), value[index]));
  return result;
}
template<class A, class O = nadd<nindex_value_t<const A>>>
auto nsuffix_scan(const A& value, O operation = {}) {
  using T = nindex_value_t<const A>;
  nvector<T> result(nlen(value) + 1);
  result[nlen(value)] = operation.id();
  nrrep(index, nlen(value))
    result[index] = operation(value[index], result[index + 1]);
  return result;
}

template<signed_integral I, class P>
constexpr I nfirst_true(I first, I last, P predicate) {
  npre(first <= last);
  while (first < last) {
    I middle = midpoint(first, last);
    if (predicate(middle))
      last = middle;
    else
      first = middle + 1;
  }
  return first;
}
template<signed_integral I, class P>
constexpr I nlast_true(I first, I last, P predicate) {
  npre(first <= last);
  while (first < last) {
    I middle = midpoint(first, last);
    if (predicate(middle))
      first = middle + 1;
    else
      last = middle;
  }
  return first - 1;
}
template<class A, class E = nequal<>, class P = nidentity>
int nunique_compact(A& value, E equal = {}, P projection = {}) {
  if (!nlen(value))
    return 0;
  int kept = 1;
  for (int index = 1; index < nlen(value); ++index)
    if (!invoke(equal, invoke(projection, value[kept - 1]),
        invoke(projection, value[index]))) {
      if (kept != index)
        value[kept] = move(value[index]);
      ++kept;
    }
  return kept;
}
template<class A, class E = nequal<>, class P = nidentity>
int nunique(A& value, E equal = {}, P projection = {}) {
  int kept = nunique_compact(value, move(equal), move(projection));
  value.resize(kept);
  return kept;
}
template<class A, class C = nless<>, class E = nequal<>, class P = nidentity>
int nsort_unique(A& value, C compare = {}, E equal = {}, P projection = {}) {
  nsort(value, move(compare), projection);
  return nunique(value, move(equal), move(projection));
}

template<signed_integral T>
struct nrange_t {
  T first = 0;
  T last = 0;
  T step = 1;
  using value_type = T;
  using nrange_tag = void;
  int len() const {
    if ((step > 0 && first >= last) || (step < 0 && first <= last))
      return 0;
    __int128 distance = step > 0 ? __int128(last) - first : __int128(first) - last;
    __int128 stride = step > 0 ? step : -__int128(step);
    __int128 count = distance / stride + (distance % stride != 0);
    npre(count <= INT_MAX);
    return int(count);
  }
  bool empty() const { return len() == 0; }
  int position(T value) const {
    __int128 distance = step > 0 ? __int128(value) - first : __int128(first) - value;
    __int128 stride = step > 0 ? step : -__int128(step);
    if (distance < 0 || distance % stride)
      return npos;
    __int128 index = distance / stride;
    return index < len() ? int(index) : npos;
  }
  T operator[](int index) const {
    npre_index(index, len());
    return T(__int128(first) + __int128(index) * step);
  }
  using cursor = ni::cursor_base<const nrange_t&>;
  cursor enumerate() const { return {*this}; }
};
template<signed_integral T>
auto nrange(T last) {
  return nrange_t<T>{0, last, 1};
}
template<signed_integral T>
auto nrange(T first, T last) {
  return nrange_t<T>{first, last, 1};
}
template<signed_integral T>
auto nrange(T first, T last, T step) {
  npre(step != 0);
  return nrange_t<T>{first, last, step};
}
template<class A>
int ni_nfor_len(const A& value) {
  if constexpr (integral<A>)
    return ni_nloop_count(value);
  else
    return nlen(value);
}

template<class A>
decltype(auto) ni_nfor_at(A& value, int index) {
  if constexpr (integral<A>)
    return index;
  else
    return value[index];
}

namespace ni {
template<class A>
using borrowed_cursor = cursor_base<A&>;
template<class A>
using owned_cursor = cursor_base<A>;
template<class A, bool WithIndex = false>
struct for_range {
  hold<A> source;
  explicit for_range(A&& value) : source(forward<A>(value)) {}
  int len() const { return ni_nfor_len(source.get()); }
  auto operator[](int index) {
    if constexpr (WithIndex) {
      using Reference = decltype(ni_nfor_at(source.get(), index));
      return pair<int, Reference>{index, ni_nfor_at(source.get(), index)};
    } else {
      return ni_nfor_at(source.get(), index);
    }
  }
  using iterator = view_iterator<for_range>;
  iterator begin() { return {this, 0}; }
  iterator end() { return {this, len()}; }
};

template<class A>
for_range(A&&) -> for_range<A&&>;
}
template<class A>
auto nenumerate(A&& value) {
  if constexpr (requires { forward<A>(value).enumerate(); })
    return forward<A>(value).enumerate();
  else if constexpr (integral<remove_cvref_t<A>>)
    return nrange(ni_nloop_count(value)).enumerate();
  else if constexpr (is_lvalue_reference_v<A>)
    return ni::borrowed_cursor<remove_reference_t<A>>{value};
  else
    return ni::owned_cursor<remove_cvref_t<A>>{forward<A>(value)};
}
#define nfor(value, sequence) for (auto&& value : ni::for_range((sequence)))
#define nfori(index, value, sequence) \
  for (auto&& [index, value] : ni::for_range<decltype((sequence)), true>((sequence)))
template<class T>
struct nplain {
  using type = remove_cvref_t<T>;
};
template<class A, class B>
struct nplain<pair<A, B>> {
  using type = pair<remove_cvref_t<A>, remove_cvref_t<B>>;
};

template<class T>
using nplain_t = typename nplain<remove_cvref_t<T>>::type;
template<class T = void, class A>
auto ncollect(A&& source) {
  using Raw = conditional_t<same_as<T, void>, nindex_value_t<const A>, T>;
  using Value = nplain_t<Raw>;
  nvector<Value> result;
  result.reserve(nlen(source));
  nfor(value, source)
    result.push(value);
  return result;
}
template<class T>
struct nrollback {
  struct change {
    T* target;
    T old_value;
  };
  vector<change> history;
  int time() const { return int(history.size()); }
  bool empty() const { return history.empty(); }
  void reserve(int count) { history.reserve(count); }
  void save(T& target) {
    history.push_back({addressof(target), target});
  }
  void assign(T& target, T value) {
    history.push_back({addressof(target), move(target)});
    target = move(value);
  }
  template<class F>
  decltype(auto) mutate(T& target, F mutation) {
    save(target);
    return mutation(target);
  }
  void undo() {
    npre(!history.empty());
    auto change = move(history.back());
    history.pop_back();
    *change.target = move(change.old_value);
  }
  void rollback(int checkpoint) {
    npre(0 <= checkpoint && checkpoint <= time());
    while (time() > checkpoint)
      undo();
  }
  void clear() { history.clear(); }
};
template<class T>
struct nscratch : nvector<T> {
  using base = nvector<T>;
  using base::base;
  int cap() const { return base::cap(); }
  nview<T> space(int count) {
    base::resize(count);
    return {base::data(), count};
  }
  nview<T> filled(int count, const T& value = T{}) {
    auto result = space(count);
    nrep(index, count)
      result[index] = value;
    return result;
  }
};
template<class T>
struct narena : nvector<T> {
  using base = nvector<T>;
  using base::base;
  using base::operator=;
  int mark() const { return base::len(); }
  template<class... Args>
  int make(Args&&... args) {
    int handle = base::len();
    base::push(forward<Args>(args)...);
    return handle;
  }
  void rollback(int checkpoint) {
    npre(0 <= checkpoint && checkpoint <= base::len());
    while (base::len() > checkpoint)
      base::pop();
  }
};

template<class T>
struct npool {
  vector<optional<T>> storage;
  vector<int> free_handles;
  int live = 0;
  int len() const { return live; }
  int cap() const { return int(storage.size()); }
  bool empty() const { return live == 0; }
  void reserve(int count) {
    storage.reserve(count);
    free_handles.reserve(count);
  }
  template<class... Args>
  int make(Args&&... args) {
    int handle;
    if (free_handles.empty()) {
      storage.emplace_back(in_place, forward<Args>(args)...);
      handle = int(storage.size());
    } else {
      handle = free_handles.back();
      free_handles.pop_back();
      storage[handle - 1].emplace(forward<Args>(args)...);
    }
    ++live;
    return handle;
  }
  void del(int handle) {
    npre(get(handle) != nullptr);
    storage[handle - 1].reset();
    free_handles.push_back(handle);
    --live;
  }
  decltype(auto) operator[](this auto&& self, int handle) {
    npre(self.get(handle) != nullptr);
    return **(self.storage.begin() + handle - 1);
  }
  auto get(this auto&& self, int handle) {
    using pointer = decltype(addressof(*self.storage[0]));
    return 0 < handle && handle <= self.cap() && self.storage[handle - 1]
      ? addressof(*self.storage[handle - 1])
      : pointer{};
  }
  void clear() {
    storage.clear();
    free_handles.clear();
    live = 0;
  }
};
template<class T>
using npool_dynamic = npool<T>;
template<class D, class E>
struct nfunc_t {
  [[no_unique_address]] mutable D domain;
  [[no_unique_address]] mutable E evaluator;
  using nrange_tag = void;
  using nfunction_tag = void;
  int len() const { return nlen(domain); }
  decltype(auto) key(int index) const {
    npre_index(index, len());
    return domain[index];
  }
  template<class X>
  int key_position(const X& value) const {
    if constexpr (requires { domain.position(value); }) {
      return domain.position(value);
    } else {
      nrep(index, len())
        if (domain[index] == value)
          return index;
      return npos;
    }
  }
private:
template<class F, class X>
  decltype(auto) call(F& function, const X& value) const {
    if constexpr (nindexed<F>) {
      int index = key_position(value);
      npre(index != npos);
      return function[index];
    } else {
      return invoke(function, value);
    }
  }
public:
int position(int index) const {
    if constexpr (requires { evaluator.get().source_position(index); })
      return evaluator.get().source_position(index);
    else
      return key_position(index);
  }
  decltype(auto) operator[](int index) const {
    if constexpr (requires { evaluator.get().at(index); })
      return evaluator.get().at(index);
    else
      return call(evaluator.get(), key(index));
  }
  template<class X>
  decltype(auto) operator()(X&& value) const {
    return call(evaluator.get(), value);
  }
  auto entry(int index) const {
    return pair<decltype(key(index)), decltype((*this)[index])>{
      key(index), (*this)[index]};
  }
};
template<class D, class E>
auto nfunc(D&& domain, E&& evaluator) {
  auto stored_domain = [&]() {
    if constexpr (is_lvalue_reference_v<D>)
      return remove_reference_t<D>(domain);
    else
      return forward<D>(domain);
  }();
  auto stored_evaluator = ni::hold(forward<E>(evaluator));
  return nfunc_t<decltype(stored_domain), decltype(stored_evaluator)>{
    move(stored_domain), move(stored_evaluator)};
}

namespace ni {

template<class G, class P>
struct gathered_evaluator {
  G function;
  P positions;
  template<class X>
  decltype(auto) operator()(this auto&& self, X&& value) {
    return self.function(forward<X>(value));
  }
  decltype(auto) at(this auto&& self, int index) {
    return self.function[self.positions[index]];
  }
  int source_position(int index) const {
    return int(positions[index]);
  }
};
}
template<class A>
concept ndiscrete = nindexed<A> && requires(A& value, const A& constant) {
  value.key(0);
  constant.key(0);
};
template<class A>
using nfunction_key_reference_t = decltype(declval<A&>().key(0));
template<class A>
using nfunction_key_t = remove_cvref_t<nfunction_key_reference_t<A>>;

template<class G>
auto nfunction_view(G function, auto projection) {
  int size = function.len();
  return nview(size, [function = move(function), projection = move(projection)](int index)
          -> decltype(auto) {
    return invoke(projection, function, index);
  });
}
template<class G>
auto nkeys(G function) {
  return nfunction_view(move(function), [](auto& value, int index) -> decltype(auto) {
    return value.key(index);
  });
}
template<class G>
auto nvalues(G function) {
  return nfunction_view(move(function), [](auto& value, int index) -> decltype(auto) {
    return value[index];
  });
}
template<class G>
auto nentries(G function) {
  return nfunction_view(move(function), [](auto& value, int index) {
    return value.entry(index);
  });
}
template<class G>
auto ntabulate(G function) {
  using Value = nindex_value_t<const G>;
  nvector<Value> result;
  result.reserve(function.len());
  nfor(value, function)
    result.push(value);
  return result;
}

#define nforkv(key, value, sequence)                                      \
  for (int nfunction_index = 0; nfunction_index < (sequence).len();       \
    ++nfunction_index)                                                 \
    if (auto&& [key, value] = (sequence).entry(nfunction_index); true)
template<class G, class D>
auto nrestrict(G function, D domain) {
  return nfunc(move(domain), [function = move(function)](auto value) -> decltype(auto) {
    return function(value);
  });
}
template<class Outer, class Inner>
auto ncompose(Outer outer, Inner inner) {
  return nmap_values(move(inner), [outer = move(outer)](auto value) {
    return outer(value);
  });
}
template<class G, class F>
auto nmap_values(G function, F transform) {
  auto keys = ncollect(nkeys(function));
  return nfunc(move(keys),
      [function = move(function), transform = move(transform)](auto value) {
          return transform(function(value));
        });
}
template<class G, class P>
auto ngather(G function, P positions) {
  nvector<nfunction_key_t<G>> selected_keys;
  selected_keys.reserve(nlen(positions));
  nfor(position, positions)
    selected_keys.push(function.key(position));
  using evaluator = ni::gathered_evaluator<G, P>;
  return nfunc(move(selected_keys), evaluator{move(function), move(positions)});
}
template<class G>
auto nsubfunc(G function, int left, int right) {
  npre(0 <= left && left <= right && right <= function.len());
  return ngather(move(function), nrange(left, right));
}

template<class G>
auto nblock(G function, int block, int width) {
  npre(block >= 0 && width > 0);
  long long left = 1LL * block * width;
  npre(left <= function.len());
  return nsubfunc(move(function), int(left), min(function.len(), int(left + width)));
}
template<class G>
auto nblocks(G function, int width) {
  npre(width > 0);
  int count = function.len() / width + (function.len() % width != 0);
  return nview(count, [function = move(function), width](int index) {
    return nblock(function, index, width);
  });
}
template<class G, class P, class A>
auto nbranch(G function, P predicate, A alternative) {
  auto keys = ncollect(nkeys(function));
  return nfunc(move(keys),
      [function = move(function), predicate = move(predicate),
      alternative = move(alternative)](auto value) -> decltype(auto) {
          if constexpr (invocable<A&, nfunction_key_reference_t<G>>)
            return invoke(predicate, value) ? invoke(alternative, value)
                          : function(value);
          else
            return invoke(predicate, value) ? alternative : function(value);
        });
}

namespace ni {
template<class S>
struct runs_function {
  S source;
  nvector<int> starts;
  int len() const { return starts.len(); }
  bool empty() const { return starts.empty(); }
  int key(int index) const {
    npre_index(index, len());
    return starts[index];
  }
  auto segment(int index) const {
    npre_index(index, len());
    int left = starts[index];
    int right = index + 1 < len() ? starts[index + 1] : source.len();
    return nsubfunc(source, left, right);
  }
  auto operator[](int index) const { return segment(index); }
  auto operator()(int start) const {
    int index = nfind(starts, start, nidentity{}, npos);
    npre(index != npos);
    return segment(index);
  }
};

}
template<class G, class P = nequal<>>
  requires ndiscrete<G>
auto nruns(G function, P together = {}) {
  nvector<int> starts;
  if (function.len()) {
    starts.push(0);
    for (int index = 1; index < function.len(); ++index)
      if (!invoke(together, function[index - 1], function[index]))
        starts.push(index);
  }
  return ni::runs_function<G>{move(function), move(starts)};
}
template<class A, class P = nequal<>>
  requires nindexed<A> && (!ndiscrete<A>)
auto nruns(A&& source, P together = {}) {
  int size = nlen(source);
  return nruns(nfunc(nrange(size), forward<A>(source)), move(together));
}
template<class Values, class Keys>
auto nanchors(Values values, Keys keys) {
  return nfunc(move(keys), move(values));
}
template<class T>
struct nmatrix : narray<T, 2> {
  using base = narray<T, 2>;
  using base::operator();
  using base::operator[];
  nmatrix() = default;
  nmatrix(int rows, int columns) : nmatrix(rows, columns, T{}) {}
  nmatrix(int rows, int columns, const T& value)
  : base({rows, columns}, value) {}
  nmatrix(initializer_list<initializer_list<T>> rows) {
    this->shape_ = {int(rows.size()), rows.size() ? int(rows.begin()->size()) : 0};
    npre(!this->shape_[0] || this->shape_[1] <= INT_MAX / this->shape_[0]);
    this->reserve(this->shape_[0] * this->shape_[1]);
    for (const auto& row : rows) {
      npre(int(row.size()) == cols());
      for (const T& value : row)
        this->push(value);
    }
  }
  int rows() const { return this->dim(0); }
  int cols() const { return this->dim(1); }
  auto row(this auto&& self, int index) {
    npre(0 <= index && index < self.rows());
    return nview(self.data() + index * self.cols(), self.cols());
  }
  auto column(this auto&& self, int index) { return ncolumn(self, index); }
  auto diagonal(this auto&& self, int offset = 0) {
    return ndiagonal(self, offset);
  }
};

template<class T, class O = nmin<T>>
  requires nmonoid<O, T>
struct nsparse : nvector<T> {
  using base = nvector<T>;
  using base::base;
  O operation;
  nsparse() = default;
  template<class A>
  nsparse(const A& source, O operation = {})
  : base(ncollect<T>(source)), operation(move(operation)) {}
  T fold(int left, int right) const {
    npre_range(left, right, base::len());
    T result = operation.id();
    for (int index = left; index < right; ++index)
      result = operation(move(result), base::operator[](index));
    return result;
  }
  T fold(int left, int right, T fallback) const {
    return left == right ? move(fallback) : fold(left, right);
  }
};
template<class T>
struct npotential_dsu {
  vector<int> parent;
  nvector<T> delta;
  explicit npotential_dsu(int n = 0) : parent(n, -1), delta(n) {
    npre(n >= 0);
  }
  int len() const { return int(parent.size()); }
  pair<int, T> root_potential(int vertex) {
    npre_index(vertex, len());
    if (parent[vertex] < 0)
      return {vertex, T{}};
    int next = parent[vertex];
    auto result = root_potential(next);
    delta[vertex] += result.second;
    parent[vertex] = result.first;
    return {parent[vertex], delta[vertex]};
  }
  int find(int vertex) { return root_potential(vertex).first; }
  int size(int vertex) { return -parent[find(vertex)]; }
  bool same(int left, int right) { return find(left) == find(right); }
  bool bind(int left, int right, T difference) {
    auto left_root = root_potential(left);
    auto right_root = root_potential(right);
    if (left_root.first == right_root.first)
      return right_root.second - left_root.second == difference;
    T right_root_delta = difference + left_root.second - right_root.second;
    if (parent[left_root.first] > parent[right_root.first]) {
      swap(left_root, right_root);
      right_root_delta = -right_root_delta;
    }
    parent[left_root.first] += parent[right_root.first];
    parent[right_root.first] = left_root.first;
    delta[right_root.first] = right_root_delta;
    return true;
  }
  nmaybe<T> diff(int left, int right) {
    auto left_root = root_potential(left);
    auto right_root = root_potential(right);
    if (left_root.first != right_root.first)
      return {};
    return right_root.second - left_root.second;
  }
  T diff(int left, int right, T fallback) {
    auto result = diff(left, right);
    return result ? result.val() : move(fallback);
  }
};
template<unsigned_integral T>
  requires(!same_as<remove_cv_t<T>, bool>)
struct nsubmask_range {
  T mask;
  int len() const { return 1 << popcount(mask); }
  bool empty() const { return false; }
  T operator[](int index) const {
    npre_index(index, len());
    T value = mask;
    while (index--)
      value = (value - 1) & mask;
    return value;
  }
  using cursor = ni::cursor_base<const nsubmask_range&>;
  cursor enumerate() const { return {*this}; }
};
template<unsigned_integral T>
  requires(!same_as<remove_cv_t<T>, bool>)
auto nsubmasks(T mask) {
  npre(popcount(mask) <= 30);
  return nsubmask_range<T>{mask};
}
template<class A>
void ni_subset_transform(A&& value, bool subset, bool inverse) {
  npre(has_single_bit(unsigned(nlen(value))));
  for (int bit = 1; bit < nlen(value); bit <<= 1)
    nrep(mask, nlen(value))
      if (bool(mask & bit) == subset) {
        int other = subset ? mask ^ bit : mask | bit;
        if (inverse)
          value[mask] -= value[other];
        else
          value[mask] += value[other];
      }
}

template<class A>
void nzeta_subset(A&& value) { ni_subset_transform(value, true, false); }
template<class A>
void nmobius_subset(A&& value) { ni_subset_transform(value, true, true); }
template<class A>
void nzeta_superset(A&& value) { ni_subset_transform(value, false, false); }
template<class A>
void nmobius_superset(A&& value) { ni_subset_transform(value, false, true); }
template<class A>
void nfwht_xor(A&& value, bool inverse = false) {
  npre(has_single_bit(unsigned(nlen(value))));
  for (int width = 1; width < nlen(value); width <<= 1)
    for (int first = 0; first < nlen(value); first += width << 1)
      nrep(offset, width) {
        auto left = value[first + offset], right = value[first + width + offset];
        value[first + offset] = left + right;
        value[first + width + offset] = left - right;
      }
  if (inverse)
    nrep(i, nlen(value))
      value[i] /= nlen(value);
}

template<class A, class B>
auto nconv_or(const A& left, const B& right) {
  npre(nlen(left) == nlen(right));
  auto a = ncollect(left), b = ncollect(right);
  nzeta_subset(a);
  nzeta_subset(b);
  nrep(i, a.len())
    a[i] *= b[i];
  nmobius_subset(a);
  return a;
}
template<class A, class B>
auto nconv_and(const A& left, const B& right) {
  npre(nlen(left) == nlen(right));
  auto a = ncollect(left), b = ncollect(right);
  nzeta_superset(a);
  nzeta_superset(b);
  nrep(i, a.len())
    a[i] *= b[i];
  nmobius_superset(a);
  return a;
}
template<class A, class B>
auto nconv_xor(const A& left, const B& right) {
  npre(nlen(left) == nlen(right));
  auto a = ncollect(left), b = ncollect(right);
  nfwht_xor(a);
  nfwht_xor(b);
  nrep(i, a.len())
    a[i] *= b[i];
  nfwht_xor(a, true);
  return a;
}

namespace ni {
template<class A>
concept nautomaton_sequence = nindexed<A> && integral<nindex_value_t<const A>>;

template<int Alphabet, integral I>
int automaton_symbol(I value) {
  if constexpr (signed_integral<I>)
    if (value < 0)
      return npos;
  return uintmax_t(value) < uintmax_t(Alphabet) ? int(value) : npos;
}
}

struct nmatch {
  int l, r, id;
  friend bool operator==(const nmatch&, const nmatch&) = default;
};
template<int Alphabet>
class ntrie {
  struct node {
    array<int, Alphabet> next;
    int parent = npos, symbol = npos, terminal = 0, passing = 0;
    node(int parent = npos, int symbol = npos) : parent(parent), symbol(symbol) {
      next.fill(npos);
    }
  };
  nvector<node> nodes{node{}};
public:
int len() const { return nodes.len(); }
  template<ni::nautomaton_sequence A>
  int add(const A& sequence) {
    int vertex = 0;
    ++nodes[vertex].passing;
    nfor(value, sequence) {
      int symbol = ni::automaton_symbol<Alphabet>(value);
      npre(symbol != npos);
      int next = nodes[vertex].next[symbol];
      if (next == npos) {
        next = nodes.len();
        nodes[vertex].next[symbol] = next;
        nodes.push(vertex, symbol);
      }
      vertex = next;
      ++nodes[vertex].passing;
    }
    ++nodes[vertex].terminal;
    return vertex;
  }
  template<ni::nautomaton_sequence A>
  int find(const A& sequence, int fallback = npos) const {
    int vertex = 0;
    nfor(value, sequence) {
      int symbol = ni::automaton_symbol<Alphabet>(value);
      if (symbol == npos || nodes[vertex].next[symbol] == npos)
        return fallback;
      vertex = nodes[vertex].next[symbol];
    }
    return vertex;
  }
  template<ni::nautomaton_sequence A>
  int count(const A& sequence) const {
    int vertex = find(sequence);
    return vertex == npos ? 0 : nodes[vertex].terminal;
  }
  template<ni::nautomaton_sequence A>
  int count_prefix(const A& sequence) const {
    int vertex = find(sequence);
    return vertex == npos ? 0 : nodes[vertex].passing;
  }
  int parent(int vertex) const {
    npre_index(vertex, len());
    return nodes[vertex].parent;
  }
  int symbol(int vertex) const {
    npre_index(vertex, len());
    return nodes[vertex].symbol;
  }
};
template<int Alphabet>
class nac {
  struct node {
    array<int, Alphabet> next;
    int failure = 0, output = npos;
    nvector<int> patterns;
    node() { next.fill(npos); }
  };
  nvector<node> nodes{node{}};
  nvector<int> lengths;
  int pattern_count = 0;
  bool built = false;
public:
int len() const { return nodes.len(); }
  int patterns() const { return pattern_count; }
  template<ni::nautomaton_sequence A>
  int add(const A& pattern) {
    npre(!built && nlen(pattern) > 0);
    int vertex = 0;
    nfor(value, pattern) {
      int symbol = ni::automaton_symbol<Alphabet>(value);
      npre(symbol != npos);
      int next = nodes[vertex].next[symbol];
      if (next == npos) {
        next = nodes.len();
        nodes[vertex].next[symbol] = next;
        nodes.push();
      }
      vertex = next;
    }
    nodes[vertex].patterns.push(pattern_count);
    lengths.push(nlen(pattern));
    return pattern_count++;
  }
  void build() {
    npre(!built);
    built = true;
    queue<int> pending;
    nrep(symbol, Alphabet) {
      int child = nodes[0].next[symbol];
      if (child == npos)
        nodes[0].next[symbol] = 0;
      else
        pending.push(child);
    }
    while (!pending.empty()) {
      int vertex = pending.front();
      pending.pop();
      int failure = nodes[vertex].failure;
      nodes[vertex].output = nodes[failure].patterns.empty()
                ? nodes[failure].output
                : failure;
      nrep(symbol, Alphabet) {
        int child = nodes[vertex].next[symbol];
        if (child == npos)
          nodes[vertex].next[symbol] = nodes[failure].next[symbol];
        else {
          nodes[child].failure = nodes[failure].next[symbol];
          pending.push(child);
        }
      }
    }
  }
  int step(int state, int symbol) const {
    npre(built && 0 <= state && state < len() && 0 <= symbol && symbol < Alphabet);
    return nodes[state].next[symbol];
  }
  template<ni::nautomaton_sequence A, class F>
  void match(const A& text, F&& callback) const {
    npre(built);
    int state = 0;
    nfori(position, value, text) {
      int symbol = ni::automaton_symbol<Alphabet>(value);
      npre(symbol != npos);
      state = nodes[state].next[symbol];
      for (int vertex = state; vertex != npos; vertex = nodes[vertex].output)
        nfor(id, nodes[vertex].patterns)
          invoke(callback, position, id);
    }
  }
  template<ni::nautomaton_sequence A>
  long long count(const A& text) const {
    long long result = 0;
    match(text, [&](int, int) { ++result; });
    return result;
  }
  template<ni::nautomaton_sequence A, class F>
  void each(const A& text, F&& callback) const {
    match(text, [&](int position, int id) {
      invoke(callback, position + 1 - lengths[id], position + 1, id);
    });
  }
  template<ni::nautomaton_sequence A>
  nvector<nmatch> matches(const A& text) const {
    nvector<nmatch> result;
    each(text, [&](int left, int right, int id) {
      result.push(nmatch{left, right, id});
    });
    return result;
  }
};

template<class W = int>
struct narc {
  int to;
  W w;
};
template<class W>
struct nedge {
  int from, to;
  W w;
  friend bool operator==(const nedge&, const nedge&) = default;
};
template<class E>
decltype(auto) nedge_to(const E& edge) {
  if constexpr (requires { edge.to; })
    return edge.to;
  else
    return (edge);
}
template<class E>
auto nedge_weight(const E& edge) {
  if constexpr (requires { edge.w; })
    return edge.w;
  else
    return 1;
}
template<class E>
int nedge_vertex(const E& edge) {
  return nchecked_number<int>(nedge_to(edge));
}

template<class G>
concept ngraph_like = requires(const G& graph) {
  { graph.vertices() } -> convertible_to<int>;
  graph.neighbors(0);
} && requires(const G& graph) {
  nlen(graph.neighbors(0));
  nedge_to(graph.neighbors(0)[0]);
};
template<class G, class F>
void ni_nfor_edges(const G& graph, F visit) {
  nrep(from, graph.vertices()) {
    const auto& adjacency = graph.neighbors(from);
    nrep(index, nlen(adjacency))
      invoke(visit, from, adjacency[index]);
  }
}
template<class W = int>
struct ngraph_list {
  nvector<nvector<int>> lists;
  nvector<narc<W>> storage;
  nvector<int> sources;
  explicit ngraph_list(int vertices = 0, int capacity = 0) : lists(vertices) {
    if (capacity > 0) {
      storage.reserve(capacity);
      sources.reserve(capacity);
    }
  }
  template<ngraph_like G>
  ngraph_list(const G& source) : ngraph_list(source.vertices()) {
    ni_nfor_edges(source, [this](int from, const auto& edge) {
      add(from, nedge_vertex(edge), W(nedge_weight(edge)));
    });
  }
  int vertices() const { return lists.len(); }
  int len() const { return vertices(); }
  int edges() const { return storage.len(); }
  int degree(int vertex) const { return lists[vertex].len(); }
  auto neighbors(this auto&& self, int vertex) {
    return nview(self.lists[vertex].len(), [&self, vertex](int index) -> decltype(auto) {
      return self.storage[self.lists[vertex][index]];
    });
  }
  int add(int from, int to, W weight = W(1)) {
    npre(0 <= from && from < vertices() && 0 <= to && to < vertices());
    int id = storage.len();
    storage.push(narc<W>{to, weight});
    sources.push(from);
    lists[from].push(id);
    return id;
  }
  void add2(int left, int right, W weight = W(1)) {
    add(left, right, weight);
    add(right, left, weight);
  }
  int find(int from, int to, int fallback = npos) const {
    nfor(id, lists[from])
      if (storage[id].to == to)
        return id;
    return fallback;
  }
  bool has(int from, int to) const { return find(from, to) != npos; }
  auto weight(this auto&& self, int id) {
    using pointer = decltype(addressof(self.storage[id].w));
    return 0 <= id && id < self.edges() ? addressof(self.storage[id].w) : pointer{};
  }
  W weight(int id, W fallback) const {
    auto result = weight(id);
    return result ? *result : fallback;
  }
  bool set(int id, W value) {
    if (auto result = weight(id)) {
      *result = value;
      return true;
    }
    return false;
  }
  struct arc_range {
    ngraph_list* graph;
    int len() const { return graph->edges(); }
    struct edge {
      int from, to;
      W& w;
    };
    edge operator[](int index) const {
      return {graph->sources[index], graph->storage[index].to, graph->storage[index].w};
    }
  };
  arc_range arcs_view() { return {this}; }
  arc_range arcs() { return {this}; }
  ngraph_list reverse() const {
    ngraph_list result(vertices());
    ni_nfor_edges(*this, [&result](int from, const auto& edge) {
      result.add(edge.to, from, edge.w);
    });
    return result;
  }
};
template<class W>
struct ngraph_view {
  int count;
  W next;
  int vertices() const { return count; }
  auto neighbors(int vertex) const { return invoke(next, vertex); }
};
template<class W>
ngraph_view(int, W) -> ngraph_view<W>;

template<class W = int>
using ngraph_forward = ngraph_list<W>;
template<class W = int>
using ngraph = ngraph_forward<W>;
template<class W = int>
using ngraph_csr = ngraph_list<W>;
template<class G>
ngraph_list(const G&)
  -> ngraph_list<remove_cvref_t<decltype(nedge_weight(declval<const G&>().neighbors(0)[0]))>>;
template<class G>
auto nvertices(const G& graph) {
  return nrange(graph.vertices());
}
template<ngraph_like G>
auto narcs(const G& graph) {
  using W = remove_cvref_t<decltype(nedge_weight(graph.neighbors(0)[0]))>;
  nvector<nedge<W>> result;
  ni_nfor_edges(graph, [&result](int from, const auto& edge) {
    result.push(nedge<W>{from, nedge_vertex(edge), W(nedge_weight(edge))});
  });
  return result;
}

template<class D>
struct ngraph_path_result {
  nvector<D> distance;
  nvector<int> parent;
  D operator[](int vertex) const { return distance[vertex]; }
  bool reach(int vertex) const {
    return 0 <= vertex && vertex < distance.len() && parent[vertex] != npos;
  }
  D dist(int vertex, D fallback) const {
    return reach(vertex) ? distance[vertex] : fallback;
  }
  nvector<int> path(int vertex) const {
    if (!reach(vertex))
      return {};
    nvector<int> result;
    for (int current = vertex;; current = parent[current]) {
      result.push(current);
      if (parent[current] == current)
        break;
    }
    reverse(result.begin(), result.end());
    return result;
  }
};
template<class G>
auto nbfs_path(const G& graph, int source) {
  int vertices = nchecked_number<int>(graph.vertices());
  npre(0 <= source && source < vertices);
  ngraph_path_result<int> result{nvector<int>(vertices, npos),
              nvector<int>(vertices, npos)};
  queue<int> pending;
  result.distance[source] = 0;
  result.parent[source] = source;
  pending.push(source);
  while (!pending.empty()) {
    int from = pending.front();
    pending.pop();
    nfor(edge, graph.neighbors(from)) {
      int to = nedge_vertex(edge);
      npre_index(to, vertices);
      if (result.parent[to] == npos) {
        result.parent[to] = from;
        result.distance[to] = result.distance[from] + 1;
        pending.push(to);
      }
    }
  }
  return result;
}
template<class D = long long, class G>
auto ndijkstra_path(const G& graph, int source,
        D infinity = numeric_limits<D>::max()) {
  npre(!is_floating_point_v<D> || isfinite(infinity));
  int vertices = nchecked_number<int>(graph.vertices());
  npre(0 <= source && source < vertices);
  ngraph_path_result<D> result{nvector<D>(vertices, infinity),
              nvector<int>(vertices, npos)};
  priority_queue<pair<D, int>, vector<pair<D, int>>, greater<pair<D, int>>> pending;
  result.distance[source] = 0;
  result.parent[source] = source;
  pending.push({0, source});
  while (!pending.empty()) {
    auto [value, from] = pending.top();
    pending.pop();
    if (value != result.distance[from])
      continue;
    nfor(edge, graph.neighbors(from)) {
      int to = nedge_vertex(edge);
      npre_index(to, vertices);
      D next = value + nchecked_number<D>(nedge_weight(edge));
      if (next < result.distance[to]) {
        result.distance[to] = next;
        result.parent[to] = from;
        pending.push({next, to});
      }
    }
  }
  return result;
}
template<class G>
auto nbfs(const G& graph, int source) {
  return nbfs_path(graph, source).distance;
}
template<class D = long long, class G>
auto ndijkstra(const G& graph, int source,
    D infinity = numeric_limits<D>::max()) {
  return ndijkstra_path(graph, source, infinity).distance;
}

template<class G>
auto n01bfs(const G& graph, int source) {
  int n = nchecked_number<int>(graph.vertices());
  npre(0 <= source && source < n);
  nvector<int> distance(n, npos);
  deque<int> pending;
  distance[source] = 0;
  pending.push_back(source);
  while (!pending.empty()) {
    int from = pending.front();
    pending.pop_front();
    nfor(edge, graph.neighbors(from)) {
      int to = nedge_vertex(edge);
      int weight = nchecked_number<int>(nedge_weight(edge));
      npre(0 <= to && to < n && (weight == 0 || weight == 1));
      int next = distance[from] + weight;
      if (distance[to] == npos || next < distance[to]) {
        distance[to] = next;
        (weight ? pending.push_back(to) : pending.push_front(to));
      }
    }
  }
  return distance;
}
template<class G>
nmaybe<nvector<int>> ntoposort(const G& graph) {
  int n = nchecked_number<int>(graph.vertices());
  nvector<int> degree(n);
  nrep(from, n)
    nfor(edge, graph.neighbors(from))
      ++degree[nedge_vertex(edge)];
  queue<int> pending;
  nrep(vertex, n)
    if (!degree[vertex])
      pending.push(vertex);
  nvector<int> order;
  while (!pending.empty()) {
    int from = pending.front();
    pending.pop();
    order.push(from);
    nfor(edge, graph.neighbors(from)) {
      int to = nedge_vertex(edge);
      if (!--degree[to])
        pending.push(to);
    }
  }
  return order.len() == n ? nmaybe<nvector<int>>(move(order))
            : nmaybe<nvector<int>>{};
}
template<class G>
auto ntopo(const G& graph) {
  return ntoposort(graph);
}
template<class G>
auto ntopo(const G& graph, nvector<int> fallback) {
  auto result = ntoposort(graph);
  return result ? result.val() : move(fallback);
}

struct nscc_result {
  nvector<int> component;
  int classes() const {
    return component.empty()
      ? 0
      : *max_element(component.begin(), component.end()) + 1;
  }
  bool same(int left, int right) const {
    return component[left] == component[right];
  }
};

template<class G>
nscc_result nscc(const G& graph) {
  int n = nchecked_number<int>(graph.vertices());
  nvector<nvector<int>> reverse(n);
  nrep(from, n)
    nfor(edge, graph.neighbors(from))
      reverse[nedge_vertex(edge)].push(from);
  nvector<char> used(n);
  nvector<int> order;
  auto visit = [&](auto&& self, int vertex) -> void {
    if (used[vertex])
      return;
    used[vertex] = true;
    nfor(edge, graph.neighbors(vertex))
      self(self, nedge_vertex(edge));
    order.push(vertex);
  };
  nrep(vertex, n)
    visit(visit, vertex);
  nvector<int> component(n, npos);
  int classes = 0;
  auto paint = [&](auto&& self, int vertex) -> void {
    if (component[vertex] != npos)
      return;
    component[vertex] = classes;
    nfor(to, reverse[vertex])
      self(self, to);
  };
  nrrep(i, order.len())
    if (component[order[i]] == npos) {
      paint(paint, order[i]);
      ++classes;
    }
  return {move(component)};
}
template<class G>
auto nscc_tarjan(const G& graph) {
  return nscc(graph);
}
template<class G>
auto nscc_kosaraju(const G& graph) {
  return nscc(graph);
}

namespace ni {

struct rooted_order {
  nvector<int> parent, depth, order;
};

template<class G>
rooted_order root_order(const G& graph, int root, bool check = false,
        bool allow_self = false) {
  int n = nchecked_number<int>(graph.vertices());
  npre(0 <= root && root < n);
  rooted_order result{nvector<int>(n, npos), nvector<int>(n), {}};
  result.parent[root] = root;
  result.order.push(root);
  for (int index = 0; index < result.order.len(); ++index) {
    int from = result.order[index];
    nfor(edge, graph.neighbors(from)) {
      int to = nedge_vertex(edge);
      npre_index(to, n);
      if (result.parent[to] == npos) {
        result.parent[to] = from;
        result.depth[to] = result.depth[from] + 1;
        result.order.push(to);
      } else if (check) {
        npre((allow_self && to == from) || to == result.parent[from]);
      }
    }
  }
  npre(!check || result.order.len() == n);
  return result;
}
}

struct nlca {
  nvector<int> parent, depth;
  template<class G>
  explicit nlca(const G& graph, int root = 0)
  : parent(), depth() {
    auto rooted = ni::root_order(graph, root, true);
    parent = move(rooted.parent);
    depth = move(rooted.depth);
  }
  int operator()(int left, int right) const {
    npre(parent[left] != npos && parent[right] != npos);
    while (depth[left] > depth[right])
      left = parent[left];
    while (depth[right] > depth[left])
      right = parent[right];
    while (left != right) {
      left = parent[left];
      right = parent[right];
    }
    return left;
  }
  int distance(int left, int right) const {
    int common = (*this)(left, right);
    return depth[left] + depth[right] - 2 * depth[common];
  }
  int jump(int vertex, int steps) const {
    npre_index(vertex, parent.len());
    if (steps < 0 || steps > depth[vertex])
      return npos;
    while (steps--)
      vertex = parent[vertex];
    return vertex;
  }
  int kth_on_path(int from, int to, int index) const {
    int common = (*this)(from, to);
    int left = depth[from] - depth[common];
    return index <= left ? jump(from, index)
            : jump(to, distance(from, to) - index);
  }
  int kth(int from, int to, int index) const {
    return kth_on_path(from, to, index);
  }
  int dist(int from, int to) const {
    return distance(from, to);
  }
};
template<class D = int>
struct nlca_binary : nlca {
  nvector<D> root_distance;
  template<class G>
  explicit nlca_binary(const G& graph, int root = 0)
  : nlca(graph, root), root_distance(parent.len()) {
    nrep(from, parent.len()) {
      if (from == root)
        continue;
      nfor(edge, graph.neighbors(parent[from]))
        if (nedge_to(edge) == from) {
          root_distance[from] = root_distance[parent[from]] +
                  nchecked_number<D>(nedge_weight(edge));
          break;
        }
    }
  }
  int lca(int left, int right) const {
    return (*this)(left, right);
  }
  D dist(int left, int right) const {
    int common = lca(left, right);
    return root_distance[left] + root_distance[right] -
    2 * root_distance[common];
  }
  int kth(int left, int right, int index) const {
    return kth_on_path(left, right, index);
  }
};

struct nhld_segment {
  int l, r;
  bool rev;
};

class nhld {
  int vertex_count = 0;
  nvector<int> parent, depth, heavy, head, position_, inverse, subtree_size;
public:
nhld() = default;
  template<class G>
  explicit nhld(const G& graph, int root = 0)
  : vertex_count(nchecked_number<int>(graph.vertices())),
  parent(vertex_count, npos), depth(vertex_count),
  heavy(vertex_count, npos), head(vertex_count),
  position_(vertex_count), inverse(vertex_count),
  subtree_size(vertex_count, 1) {
    npre(vertex_count > 0 && 0 <= root && root < vertex_count);
    auto rooted = ni::root_order(graph, root, true, true);
    parent = move(rooted.parent);
    depth = move(rooted.depth);
    auto order = move(rooted.order);
    nrrep(i, order.len()) {
      int from = order[i];
      nfor(edge, graph.neighbors(from)) {
        int to = nedge_vertex(edge);
        if (parent[to] == from) {
          subtree_size[from] += subtree_size[to];
          if (heavy[from] == npos ||
          subtree_size[to] > subtree_size[heavy[from]])
            heavy[from] = to;
        }
      }
    }
    nvector<pair<int, int>> pending{{root, root}};
    int timer = 0;
    while (!pending.empty()) {
      auto [from, chain] = pending.pop();
      for (int vertex = from; vertex != npos; vertex = heavy[vertex]) {
        head[vertex] = chain;
        position_[vertex] = timer;
        inverse[timer++] = vertex;
        nfor(edge, graph.neighbors(vertex)) {
          int to = nedge_vertex(edge);
          if (parent[to] == vertex && to != heavy[vertex])
            pending.push(pair<int, int>{to, to});
        }
      }
    }
    npre(timer == vertex_count);
  }
  int len() const {
    return vertex_count;
  }
  int vertex(int index) const {
    npre(0 <= index && index < vertex_count);
    return inverse[index];
  }
  int position_of(int vertex) const {
    npre_index(vertex, vertex_count);
    return position_[vertex];
  }
  int pos(int vertex) const {
    return position_of(vertex);
  }
  int position(int vertex) const {
    return position_of(vertex);
  }
  int lca(int left, int right) const {
    npre(0 <= left && left < vertex_count &&
    0 <= right && right < vertex_count);
    while (head[left] != head[right]) {
      if (depth[head[left]] > depth[head[right]])
        left = parent[head[left]];
      else
        right = parent[head[right]];
    }
    return depth[left] < depth[right] ? left : right;
  }
  pair<int, int> subtree_interval(int vertex) const {
    return {position_[vertex], position_[vertex] + subtree_size[vertex]};
  }
  pair<int, int> subtree(int vertex) const {
    return subtree_interval(vertex);
  }
  nvector<nhld_segment> path(int from, int to, bool edges = false) const {
    nvector<nhld_segment> left, right;
    while (head[from] != head[to]) {
      if (depth[head[from]] >= depth[head[to]]) {
        left.push(nhld_segment{position_[head[from]], position_[from] + 1, true});
        from = parent[head[from]];
      } else {
        right.push(nhld_segment{position_[head[to]], position_[to] + 1, false});
        to = parent[head[to]];
      }
    }
    if (depth[from] >= depth[to])
      left.push(nhld_segment{position_[to] + int(edges), position_[from] + 1, true});
    else
      right.push(nhld_segment{position_[from] + int(edges), position_[to] + 1, false});
    nvector<nhld_segment> result;
    nfor(segment, left)
      if (segment.l < segment.r)
        result.push(segment);
    while (!right.empty()) {
      auto segment = right.pop();
      if (segment.l < segment.r)
        result.push(segment);
    }
    return result;
  }
};
template<class G, class S, class Merge, class Vertex, class Lift>
auto nreroot(const G& graph, S identity, Merge merge, Vertex vertex, Lift lift,
    int root = 0) {
  int n = graph.vertices();
  if (!n)
    return nvector<S>{};
  auto rooted = ni::root_order(graph, root);
  auto parent = move(rooted.parent);
  auto order = move(rooted.order);
  nvector<S> down(n, identity), up(n, identity), answer(n, identity);
  nrrep(i, order.len()) {
    int from = order[i];
    S aggregate = identity;
    nfor(edge, graph.neighbors(from)) {
      int to = nedge_to(edge);
      if (parent[to] == from)
        aggregate = merge(move(aggregate), lift(down[to], to, from));
    }
    down[from] = vertex(move(aggregate), from);
  }
  nfor(from, order) {
    auto&& adjacency = graph.neighbors(from);
    nvector<S> contribution;
    nrep(i, nlen(adjacency)) {
      int to = nedge_to(adjacency[i]);
      contribution.push(to == parent[from] ? up[from]
                      : lift(down[to], to, from));
    }
    nvector<S> prefix(contribution.len() + 1, identity);
    nvector<S> suffix(contribution.len() + 1, identity);
    nrep(i, contribution.len())
      prefix[i + 1] = merge(prefix[i], contribution[i]);
    nrrep(i, contribution.len())
      suffix[i] = merge(contribution[i], suffix[i + 1]);
    answer[from] = vertex(prefix.back(), from);
    nrep(i, nlen(adjacency)) {
      int child = nedge_to(adjacency[i]);
      if (parent[child] != from)
        continue;
      S without = merge(prefix[i], suffix[i + 1]);
      up[child] = lift(vertex(move(without), from), from, child);
    }
  }
  return answer;
}
template<class W>
struct nmst_result {
  W weight{};
  nvector<nedge<W>> edges, edge;
  int components = 0;
  bool connected() const { return components == 1; }
};
template<class W = long long, class G>
nmaybe<nmst_result<W>> nprim(const G& graph) {
  int n = graph.vertices();
  if (!n)
    return nmst_result<W>{};
  nvector<char> used(n);
  priority_queue<pair<W, pair<int, int>>, vector<pair<W, pair<int, int>>>,
      greater<pair<W, pair<int, int>>>> pending;
  nmst_result<W> result;
  nrep(start, n) {
    if (used[start])
      continue;
    ++result.components;
    pending.push({0, {start, -1}});
    while (!pending.empty()) {
      auto [weight, vertices] = pending.top();
      pending.pop();
      auto [from, edge_id] = vertices;
      if (used[from])
        continue;
      used[from] = true;
      if (edge_id >= 0) {
        if constexpr (is_integral_v<W>)
          result.weight = nchecked_add(result.weight, weight);
        else
          result.weight += weight;
        result.edges.push(nedge<W>{0, from, weight});
      }
      nfor(edge, graph.neighbors(from)) {
        if (!used[nedge_to(edge)])
          pending.push({W(nedge_weight(edge)), {nedge_to(edge), 0}});
      }
    }
  }
  result.edge = result.edges;
  return result.components == 1 ? nmaybe<nmst_result<W>>(move(result))
              : nmaybe<nmst_result<W>>{};
}

struct nmatching_result {
  int size = 0;
  nvector<int> left;
  nvector<int> right;
};

template<ngraph_like G>
nmatching_result nhopcroft_karp(const G& graph, int right_vertices) {
  int left_vertices = graph.vertices();
  npre(right_vertices >= 0);
  nvector<nvector<int>> adjacency(left_vertices);
  ni_nfor_edges(graph, [&](int left, const auto& edge) {
    int right = nedge_to(edge);
    npre(0 <= right && right < right_vertices);
    adjacency[left].push(right);
  });
  nmatching_result result{0, nvector<int>(left_vertices, npos),
            nvector<int>(right_vertices, npos)};
  nvector<int> distance(left_vertices), next(left_vertices);
  for (;;) {
    fill(distance.begin(), distance.end(), npos);
    deque<int> queue;
    nrep(left, left_vertices) {
      if (result.left[left] == npos) {
        distance[left] = 0;
        queue.push_back(left);
      }
    }
    int shortest = INT_MAX;
    while (!queue.empty()) {
      int left = queue.front();
      queue.pop_front();
      if (distance[left] + 1 > shortest)
        continue;
      nfor(right, adjacency[left]) {
        int next_left = result.right[right];
        if (next_left == npos)
          shortest = min(shortest, distance[left] + 1);
        else if (distance[next_left] == npos && distance[left] + 1 < shortest) {
          distance[next_left] = distance[left] + 1;
          queue.push_back(next_left);
        }
      }
    }
    if (shortest == INT_MAX)
      break;
    fill(next.begin(), next.end(), 0);
    int augmented = 0;
    nrep(root, left_vertices) {
      if (result.left[root] != npos || distance[root] != 0)
        continue;
      nvector<int> stack{root};
      nvector<int> via_right{npos};
      bool found = false;
      while (!stack.empty() && !found) {
        int left = stack.back();
        while (next[left] < adjacency[left].len()) {
          int right = adjacency[left][next[left]++];
          int next_left = result.right[right];
          if (next_left == npos) {
            if (distance[left] + 1 != shortest)
              continue;
            result.left[left] = right;
            result.right[right] = left;
            for (int depth = stack.len() - 1; depth > 0; --depth) {
              int parent = stack[depth - 1];
              int parent_right = via_right[depth];
              result.left[parent] = parent_right;
              result.right[parent_right] = parent;
            }
            found = true;
            ++augmented;
            break;
          }
          if (distance[next_left] == distance[left] + 1) {
            stack.push(next_left);
            via_right.push(right);
            break;
          }
        }
        if (!found && !stack.empty() &&
        next[stack.back()] == adjacency[stack.back()].len()) {
          distance[stack.back()] = npos;
          stack.pop_back();
          via_right.pop_back();
        }
      }
    }
    if (!augmented)
      break;
    result.size += augmented;
  }
  return result;
}

struct nbicover {
  nvector<int> l;
  nvector<int> r;
};

class nbimatch_hopcroft {
  int left_vertices_ = 0;
  int right_vertices_ = 0;
  nvector<nvector<int>> adjacency_;
  nvector<int> left_match_;
  nvector<int> right_match_;
  bool solved_ = false;
public:
nbimatch_hopcroft() = default;
  nbimatch_hopcroft(int left_vertices, int right_vertices)
  : left_vertices_(left_vertices), right_vertices_(right_vertices),
  adjacency_(left_vertices), left_match_(left_vertices, npos),
  right_match_(right_vertices, npos) {
    npre(left_vertices >= 0 && right_vertices >= 0);
  }
  int add(int left, int right) {
    npre(0 <= left && left < left_vertices_ && 0 <= right && right < right_vertices_);
    solved_ = false;
    adjacency_[left].push(right);
    return adjacency_[left].len() - 1;
  }
  int solve() {
    auto graph = ngraph_view(left_vertices_,
              [this](int left) -> const nvector<int>& {
                  return adjacency_[left];
                });
    auto result = nhopcroft_karp(graph, right_vertices_);
    left_match_ = move(result.left);
    right_match_ = move(result.right);
    solved_ = true;
    return result.size;
  }
  int left(int vertex, int fallback = npos) const {
    npre(0 <= vertex && vertex < left_vertices_);
    return left_match_[vertex] == npos ? fallback : left_match_[vertex];
  }
  int right(int vertex, int fallback = npos) const {
    npre(0 <= vertex && vertex < right_vertices_);
    return right_match_[vertex] == npos ? fallback : right_match_[vertex];
  }
  nvector<pair<int, int>> pairs() const {
    npre(solved_);
    nvector<pair<int, int>> result;
    nrep(left, left_vertices_)
      if (left_match_[left] != npos)
        result.push(left, left_match_[left]);
    return result;
  }
  nbicover mincover() const {
    npre(solved_);
    nvector<unsigned char> reachable_left(left_vertices_, false);
    nvector<unsigned char> reachable_right(right_vertices_, false);
    deque<int> queue;
    nrep(left, left_vertices_) {
      if (left_match_[left] == npos) {
        reachable_left[left] = true;
        queue.push_back(left);
      }
    }
    while (!queue.empty()) {
      int left = queue.front();
      queue.pop_front();
      nfor(right, adjacency_[left]) {
        if (left_match_[left] == right || reachable_right[right])
          continue;
        reachable_right[right] = true;
        int next_left = right_match_[right];
        if (next_left != npos && !reachable_left[next_left]) {
          reachable_left[next_left] = true;
          queue.push_back(next_left);
        }
      }
    }
    nbicover result;
    nrep(left, left_vertices_)
      if (!reachable_left[left])
        result.l.push(left);
    nrep(right, right_vertices_)
      if (reachable_right[right])
        result.r.push(right);
    return result;
  }
};
using nbimatch = nbimatch_hopcroft;
template<class T>
struct npoint {
  T x{}, y{};
  friend constexpr auto operator<=>(const npoint&, const npoint&) = default;
  friend constexpr npoint operator+(npoint a, const npoint& b) {
    a.x += b.x;
    a.y += b.y;
    return a;
  }
  friend constexpr npoint operator-(npoint a, const npoint& b) {
    a.x -= b.x;
    a.y -= b.y;
    return a;
  }
  friend constexpr npoint operator-(const npoint& a) { return {-a.x, -a.y}; }
  template<class U> friend constexpr npoint operator*(npoint a, U scale) {
    a.x *= scale;
    a.y *= scale;
    return a;
  }
  template<class U> friend constexpr npoint operator*(U scale, npoint a) {
    return a * scale;
  }
  template<class U> friend constexpr npoint operator/(npoint a, U scale) {
    a.x /= scale;
    a.y /= scale;
    return a;
  }
};

template<class T>
constexpr nwide_t<T> ndot(const npoint<T>& a, const npoint<T>& b) {
  using W = nwide_t<T>;
  return nchecked_add(nchecked_mul(nchecked_number<W>(a.x), nchecked_number<W>(b.x)),
        nchecked_mul(nchecked_number<W>(a.y), nchecked_number<W>(b.y)));
}
template<class T>
constexpr nwide_t<T> ncross(const npoint<T>& a, const npoint<T>& b) {
  using W = nwide_t<T>;
  return nchecked_sub(nchecked_mul(nchecked_number<W>(a.x), nchecked_number<W>(b.y)),
          nchecked_mul(nchecked_number<W>(a.y), nchecked_number<W>(b.x)));
}
template<class T>
constexpr nwide_t<T> ncross(const npoint<T>& a, const npoint<T>& b, const npoint<T>& c) {
  return ncross(b - a, c - a);
}
template<class T>
constexpr nwide_t<T> ndist2(const npoint<T>& a, const npoint<T>& b) {
  return ndot(a - b, a - b);
}
template<class T>
constexpr int nsgn_eps(T value, long double epsilon = 0) {
  if constexpr (is_floating_point_v<T>)
    return value > epsilon ? 1 : value < -epsilon ? -1 : 0;
  else
    return (value > 0) - (value < 0);
}

template<class T>
constexpr int nsign(T value) { return nsgn_eps(value); }
template<class T>
constexpr int norient(const npoint<T>& a, const npoint<T>& b, const npoint<T>& c,
        long double epsilon = 0) {
  return nsgn_eps(ncross(a, b, c), epsilon);
}
template<class T>
constexpr bool nonseg(const npoint<T>& a, const npoint<T>& b, const npoint<T>& p,
        long double epsilon = 0) {
  if (norient(a, b, p, epsilon))
    return false;
  return min(a.x, b.x) - epsilon <= p.x && p.x <= max(a.x, b.x) + epsilon &&
  min(a.y, b.y) - epsilon <= p.y && p.y <= max(a.y, b.y) + epsilon;
}
template<class T>
constexpr bool nsegment_intersect(const npoint<T>& a, const npoint<T>& b,
              const npoint<T>& c, const npoint<T>& d) {
  int x = norient(a, b, c), y = norient(a, b, d);
  int z = norient(c, d, a), w = norient(c, d, b);
  return (x * y < 0 && z * w < 0) || (!x && nonseg(a, b, c)) ||
  (!y && nonseg(a, b, d)) || (!z && nonseg(c, d, a)) ||
  (!w && nonseg(c, d, b));
}
template<class T>
struct nline2 {
  npoint<T> p, v;
  template<class U>
  auto operator()(U scale) const { return p + v * scale; }
};

template<class T>
nmaybe<npoint<long double>> nline_intersection(const npoint<T>& a, const npoint<T>& b,
                      const npoint<T>& c, const npoint<T>& d) {
  npoint<long double> ab{static_cast<long double>(b.x) - a.x,
          static_cast<long double>(b.y) - a.y};
  npoint<long double> cd{static_cast<long double>(d.x) - c.x,
          static_cast<long double>(d.y) - c.y};
  long double denominator = ncross(ab, cd);
  if (!denominator)
    return {};
  npoint<long double> ac{static_cast<long double>(c.x) - a.x,
          static_cast<long double>(c.y) - a.y};
  long double scale = ncross(ac, cd) / denominator;
  return npoint<long double>{static_cast<long double>(a.x) + scale * ab.x,
            static_cast<long double>(a.y) + scale * ab.y};
}
template<class T>
nmaybe<npoint<long double>> nline_intersect(const nline2<T>& a, const nline2<T>& b) {
  return nline_intersection(a.p, a.p + a.v, b.p, b.p + b.v);
}
template<class A>
auto nconvex_hull(const A& source, bool keep_collinear = false) {
  using P = remove_cvref_t<decltype(source[0])>;
  nvector<P> points;
  nfor(point, source)
    points.push(point);
  nsort(points, [](const P& a, const P& b) { return a.x != b.x ? a.x < b.x : a.y < b.y; });
  points.erase(unique(points.begin(), points.end()), points.end());
  if (points.len() <= 2)
    return points;
  bool collinear = true;
  for (int i = 2; i < points.len(); ++i)
    collinear &= !norient(points[0], points[1], points[i]);
  if (collinear)
    return keep_collinear ? points : nvector<P>{points.front(), points.back()};
  nvector<P> hull;
  auto add = [&](const P& point) {
    while (hull.len() >= 2 &&
    (keep_collinear ? norient(hull[hull.len() - 2], hull.back(), point) < 0
            : norient(hull[hull.len() - 2], hull.back(), point) <= 0))
      hull.pop();
    hull.push(point);
  };
  nfor(point, points)
    add(point);
  int lower = hull.len();
  for (int i = points.len() - 2; i >= 0; --i) {
    while (hull.len() > lower &&
    (keep_collinear ? norient(hull[hull.len() - 2], hull.back(), points[i]) < 0
            : norient(hull[hull.len() - 2], hull.back(), points[i]) <= 0))
      hull.pop();
    hull.push(points[i]);
  }
  hull.pop();
  return hull;
}
template<class A>
auto npolygon_area2(const A& polygon) {
  using P = remove_cvref_t<decltype(polygon[0])>;
  using W = nwide_t<remove_cvref_t<decltype(P{}.x)>>;
  W result{};
  nrep(i, nlen(polygon))
    result = nchecked_add(result, ncross(polygon[i], polygon[(i + 1) % nlen(polygon)]));
  return result;
}
template<class A>
int npoint_in_poly(const A& polygon, const remove_cvref_t<decltype(polygon[0])>& point,
      long double epsilon = 0) {
  bool inside = false;
  nrep(i, nlen(polygon)) {
    const auto& a = polygon[i];
    const auto& b = polygon[(i + 1) % nlen(polygon)];
    if (nonseg(a, b, point, epsilon))
      return 0;
    int side = norient(a, b, point, epsilon);
    if ((a.y <= point.y && point.y < b.y && side > 0) ||
    (b.y <= point.y && point.y < a.y && side < 0))
      inside = !inside;
  }
  return inside ? 1 : -1;
}

template<class A>
auto nconvex_diameter2(const A& source) {
  auto hull = nconvex_hull(source);
  using P = remove_cvref_t<decltype(hull[0])>;
  using W = decltype(ndist2(declval<P>(), declval<P>()));
  W answer{};
  nrep(i, hull.len())
    for (int j = i + 1; j < hull.len(); ++j)
      nchmax(answer, ndist2(hull[i], hull[j]));
  return answer;
}

namespace ni {
template<class T>
concept nio_integer = !same_as<remove_cv_t<T>, bool> &&
        (integral<T> || same_as<T, __int128_t> ||
        same_as<T, __uint128_t>);
template<class T>
using nio_unsigned_t = conditional_t<same_as<T, __int128_t> ||
                  same_as<T, __uint128_t>,
                __uint128_t, make_unsigned_t<T>>;
}

class ninput {
  FILE* file;
  int get() const { return getc(file); }
  int first() const {
    int c;
    do
      c = get();
    while (c != EOF && c <= ' ');
    return c;
  }
public:
explicit ninput(FILE* file = stdin) : file(file) { npre(file); }
  template<class T>
    requires ni::nio_integer<T>
  bool read(T& value) {
    int c = first();
    if (c == EOF)
      return false;
    bool negative = c == '-';
    if (negative || c == '+')
      c = get();
    npre('0' <= c && c <= '9');
    __uint128_t magnitude = 0;
    do {
      unsigned digit = unsigned(c - '0');
      npre(magnitude <= (~__uint128_t{} - digit) / 10);
      magnitude = magnitude * 10 + digit;
      c = get();
    } while ('0' <= c && c <= '9');
    npre(c == EOF || c <= ' ');
    if constexpr (is_signed_v<T> || same_as<T, __int128_t>) {
      __uint128_t positive = __uint128_t(numeric_limits<T>::max());
      __uint128_t limit = positive + 1;
      npre(magnitude <= (negative ? limit : positive));
      value = negative && magnitude == limit
          ? numeric_limits<T>::lowest()
          : negative ? -T(magnitude) : T(magnitude);
    } else {
      npre(!negative && magnitude <= __uint128_t(numeric_limits<T>::max()));
      value = T(magnitude);
    }
    return true;
  }
  bool read(string& value) {
    int c = first();
    if (c == EOF)
      return false;
    value.clear();
    do {
      value.push_back(char(c));
      c = get();
    } while (c != EOF && c > ' ');
    return true;
  }
  bool read(char& value) {
    int c = first();
    if (c == EOF)
      return false;
    value = char(c);
    return true;
  }
  template<class T>
  ninput& operator>>(T& value) {
    npre(read(value));
    return *this;
  }
};

class noutput {
  FILE* file;
  void put(char value) {
    npre(putc(value, file) != EOF);
  }
public:
explicit noutput(FILE* file = stdout) : file(file) { npre(file); }
  noutput(const noutput&) = delete;
  noutput& operator=(const noutput&) = delete;
  ~noutput() { flush(); }
  void flush() { npre(fflush(file) == 0); }
  void write(char value) { put(value); }
  void write(string_view value) {
    npre(fwrite(value.data(), 1, value.size(), file) == value.size());
  }
  void write(const string& value) { write(string_view(value)); }
  void write(const char* value) { write(string_view(value)); }
  template<class T>
    requires ni::nio_integer<T>
  void write(T value) {
    using U = ni::nio_unsigned_t<T>;
    U magnitude;
    if constexpr (is_signed_v<T> || same_as<T, __int128_t>) {
      if (value < 0) {
        put('-');
        magnitude = U{} - U(value);
      } else {
        magnitude = U(value);
      }
    } else {
      magnitude = U(value);
    }
    char digits[64];
    int count = 0;
    do {
      digits[count++] = char('0' + magnitude % 10);
      magnitude /= 10;
    } while (magnitude);
    while (count)
      put(digits[--count]);
  }
  template<class T>
  noutput& operator<<(const T& value) {
    write(value);
    return *this;
  }
};
inline ninput nin;
inline noutput nout;

template<class... T>
bool nread(T&... value) { return (nin.read(value) && ...); }
template<class... T>
void nprint(const T&... value) {
  bool first = true;
  auto put = [&](const auto& item) {
    if (!exchange(first, false))
      nout.write(' ');
    nout << item;
  };
  (put(value), ...);
}
template<class... T>
void nprintln(const T&... value) {
  nprint(value...);
  nout.write('\n');
}
template<class A>
nvector<int> nprefix_function(const A& sequence) {
  int n = nlen(sequence);
  nvector<int> result(n);
  for (int i = 1; i < n; ++i) {
    int border = result[i - 1];
    while (border && !(sequence[i] == sequence[border]))
      border = result[border - 1];
    if (sequence[i] == sequence[border])
      ++border;
    result[i] = border;
  }
  return result;
}
template<class A>
nvector<int> nz_function(const A& sequence) {
  int n = nlen(sequence);
  nvector<int> result(n);
  for (int i = 1, left = 0, right = 0; i < n; ++i) {
    if (i < right)
      result[i] = min(right - i, result[i - left]);
    while (i + result[i] < n && sequence[result[i]] == sequence[i + result[i]])
      ++result[i];
    if (right < i + result[i])
      left = i, right = i + result[i];
  }
  if (n)
    result[0] = n;
  return result;
}

template<class Text, class Pattern>
nvector<int> nkmp_find(const Text& text, const Pattern& pattern) {
  int n = nlen(text), m = nlen(pattern);
  nvector<int> result;
  if (!m) {
    npre(n < INT_MAX);
    result.reserve(n + 1);
    nrep(i, n + 1)
      result.push(i);
    return result;
  }
  auto prefix = nprefix_function(pattern);
  for (int i = 0, matched = 0; i < n; ++i) {
    while (matched && !(text[i] == pattern[matched]))
      matched = prefix[matched - 1];
    if (text[i] == pattern[matched])
      ++matched;
    if (matched == m) {
      result.push(i - m + 1);
      matched = prefix[matched - 1];
    }
  }
  return result;
}

struct nmanacher_result {
  nvector<int> odd, even;
  int len() const { return odd.len(); }
  int odd_radius(int center) const {
    npre(0 <= center && center < len());
    return odd[center];
  }
  int even_radius(int center) const {
    npre(0 <= center && center < len());
    return even[center];
  }
  bool pal(int left, int right) const {
    npre_range(left, right, len());
    int length = right - left;
    if (!length)
      return true;
    int center = left + length / 2;
    return length & 1 ? odd[center] > length / 2 : even[center] >= length / 2;
  }
};
template<class A>
auto nmanacher(const A& sequence) {
  int n = nlen(sequence);
  nmanacher_result result{nvector<int>(n), nvector<int>(n)};
  for (int i = 0, left = 0, right = -1; i < n; ++i) {
    int mirror = i > right ? 0 : left + right - i;
    int radius = i > right ? 1 : min(result.odd[mirror], right - i + 1);
    while (0 <= i - radius && i + radius < n && sequence[i - radius] == sequence[i + radius])
      ++radius;
    result.odd[i] = radius;
    if (right < i + radius - 1)
      left = i - radius + 1, right = i + radius - 1;
  }
  for (int i = 0, left = 0, right = -1; i < n; ++i) {
    int mirror = i > right ? 0 : left + right - i + 1;
    int radius = i > right ? 0 : min(result.even[mirror], right - i + 1);
    while (0 <= i - radius - 1 && i + radius < n &&
    sequence[i - radius - 1] == sequence[i + radius])
      ++radius;
    result.even[i] = radius;
    if (right < i + radius - 1)
      left = i - radius, right = i + radius - 1;
  }
  return result;
}
template<class A>
auto nprefix(const A& sequence) { return nprefix_function(sequence); }
template<class A>
auto nzfunc(const A& sequence) { return nz_function(sequence); }

template<class Text, class Pattern>
auto nkmp(const Text& text, const Pattern& pattern) { return nkmp_find(text, pattern); }
using nmanacher_index = nmanacher_result;
template<class A>
nvector<int> nsuffix_array(const A& sequence) {
  int n = nlen(sequence);
  nvector<int> suffix(n), rank(n), next_rank(n);
  iota(suffix.begin(), suffix.end(), 0);
  nsort(suffix, [&](int a, int b) { return sequence[a] < sequence[b]; });
  for (int i = 1; i < n; ++i)
    rank[suffix[i]] = rank[suffix[i - 1]] +
          int(sequence[suffix[i - 1]] != sequence[suffix[i]]);
  for (int length = 1; length < n && rank[suffix.back()] + 1 < n; length <<= 1) {
    nsort(suffix, [&](int a, int b) {
      pair<int, int> x{rank[a], a + length < n ? rank[a + length] : npos};
      pair<int, int> y{rank[b], b + length < n ? rank[b + length] : npos};
      return x < y;
    });
    next_rank[suffix[0]] = 0;
    for (int i = 1; i < n; ++i) {
      int a = suffix[i - 1], b = suffix[i];
      next_rank[b] = next_rank[a] +
          int(pair{rank[a], a + length < n ? rank[a + length] : npos} !=
            pair{rank[b], b + length < n ? rank[b + length] : npos});
    }
    swap(rank, next_rank);
    if (length > n / 2)
      break;
  }
  return suffix;
}
template<class A>
nvector<int> nlcp_array(const A& sequence, const nvector<int>& suffix) {
  int n = nlen(sequence);
  npre(suffix.len() == n);
  nvector<int> rank(n), result(n);
  nvector<char> seen(n);
  nrep(i, n) {
    npre(0 <= suffix[i] && suffix[i] < n && !seen[suffix[i]]);
    seen[suffix[i]] = true;
    rank[suffix[i]] = i;
  }
  for (int start = 0, common = 0; start < n; ++start) {
    int position = rank[start];
    if (!position)
      continue;
    int previous = suffix[position - 1];
    while (start + common < n && previous + common < n &&
    sequence[start + common] == sequence[previous + common])
      ++common;
    result[position] = common;
    if (common)
      --common;
  }
  return result;
}
template<class T>
concept nexact_field_element = nexact_field<T>;

namespace ni {
template<class T, class L, class R, class Add, class Mul>
nmatrix<T> matmul(const L& left, const R& right, Add add, Mul multiply) {
  npre(left.cols() == right.rows());
  nmatrix<T> result(left.rows(), right.cols(), add.id());
  nrep(i, left.rows())
    nrep(k, left.cols())
      nrep(j, right.cols())
        result(i, j) = add(result(i, j),
              multiply(left(i, k), right(k, j)));
  return result;
}
template<class T, class Add, class Mul>
nmatrix<T> mateye(int size, Add add, Mul multiply) {
  nmatrix<T> result(size, size, add.id());
  nrep(i, size)
    result(i, i) = multiply.id();
  return result;
}
}
template<class T, class Add = nadd<T>, class Mul = nmul<T>>
nmatrix<T> nmatrix_identity(int size, Add add = {}, Mul multiply = {}) {
  npre(size >= 0);
  return ni::mateye<T>(size, move(add), move(multiply));
}

template<class A, class B>
  requires requires(const A& a) { a.rows(); a.cols(); a(0, 0); } &&
    nsemiring<nadd<remove_cvref_t<decltype(declval<const A&>()(0, 0))>>,
        nmul<remove_cvref_t<decltype(declval<const A&>()(0, 0))>>,
        remove_cvref_t<decltype(declval<const A&>()(0, 0))>>
auto nmatmul(const A& left, const B& right) {
  using T = remove_cvref_t<decltype(left(0, 0))>;
  return ni::matmul<T>(left, right, nadd<T>{}, nmul<T>{});
}
template<class T, class Add, class Mul>
nmatrix<T> nmatmul(const nmatrix<T>& left, const nmatrix<T>& right,
      Add add, Mul multiply) {
  return ni::matmul<T>(left, right, move(add), move(multiply));
}
template<class T, class Add = nadd<T>, class Mul = nmul<T>>
nmatrix<T> nmatpow(nmatrix<T> base, uint64_t exponent, Add add = {}, Mul multiply = {}) {
  npre(base.rows() == base.cols());
  auto result = nmatrix_identity<T>(base.rows(), add, multiply);
  while (exponent) {
    if (exponent & 1)
      result = nmatmul(result, base, add, multiply);
    exponent >>= 1;
    if (exponent)
      base = nmatmul(base, base, add, multiply);
  }
  return result;
}
template<class T, class Add = nadd<T>, class Mul = nmul<T>>
struct nmat : nmatrix<T> {
  using base = nmatrix<T>;
  using nmatrix<T>::nmatrix;
  nmat(const base& value) : base(value) {}
  nmat(base&& value) : base(move(value)) {}
  static nmat eye(int size) {
    Add add;
    Mul multiply;
    return nmat(ni::mateye<T>(size, add, multiply));
  }
  T get(int row, int column, T fallback = Add{}.id()) const {
    return 0 <= row && row < this->rows() && 0 <= column && column < this->cols()
      ? (*this)(row, column) : move(fallback);
  }
  friend nmat operator*(const nmat& left, const nmat& right) {
    return nmat(ni::matmul<T>(left, right, Add{}, Mul{}));
  }
  friend nmat operator*(const nmat& left, const base& right) {
    return left * nmat(right);
  }
  friend nmat operator+(nmat left, const nmat& right) {
    npre(left.rows() == right.rows() && left.cols() == right.cols());
    nrep(i, left.len())
      left[i] = Add{}(left[i], right[i]);
    return left;
  }
  nmat& operator*=(const nmat& other) { return *this = *this * other; }
  nmat trans() const {
    nmat result(this->cols(), this->rows(), Add{}.id());
    nrep(i, this->rows())
      nrep(j, this->cols())
        result(j, i) = (*this)(i, j);
    return result;
  }
  friend bool operator==(const nmat& left, const nmat& right) {
    if (left.rows() != right.rows() || left.cols() != right.cols())
      return false;
    nrep(i, left.len())
      if (left[i] != right[i])
        return false;
    return true;
  }
};
template<nexact_field_element T>
T ndeterminant(nmatrix<T> matrix) {
  npre(matrix.rows() == matrix.cols());
  T result = T{1};
  nrep(column, matrix.cols()) {
    int pivot = column;
    while (pivot < matrix.rows() && matrix(pivot, column) == T{})
      ++pivot;
    if (pivot == matrix.rows())
      return {};
    if (pivot != column) {
      for (int j = column; j < matrix.cols(); ++j)
        swap(matrix(column, j), matrix(pivot, j));
      result = -result;
    }
    T value = matrix(column, column);
    result *= value;
    for (int i = column + 1; i < matrix.rows(); ++i) {
      T factor = matrix(i, column) / value;
      for (int j = column; j < matrix.cols(); ++j)
        matrix(i, j) -= factor * matrix(column, j);
    }
  }
  return result;
}

template<nexact_field_element T>
T ndet(nmatrix<T> matrix) { return ndeterminant(move(matrix)); }
template<nexact_field_element T>
nmaybe<nmatrix<T>> ninverse(nmatrix<T> matrix) {
  npre(matrix.rows() == matrix.cols());
  int size = matrix.rows();
  nmatrix<T> result(size, size, T{});
  nrep(i, size)
    result(i, i) = T{1};
  nrep(column, size) {
    int pivot = column;
    while (pivot < size && matrix(pivot, column) == T{})
      ++pivot;
    if (pivot == size)
      return {};
    if (pivot != column)
      nrep(j, size) {
        swap(matrix(column, j), matrix(pivot, j));
        swap(result(column, j), result(pivot, j));
      }
    T scale = T{1} / matrix(column, column);
    nrep(j, size) {
      matrix(column, j) *= scale;
      result(column, j) *= scale;
    }
    nrep(i, size)
      if (i != column && matrix(i, column) != T{}) {
        T factor = matrix(i, column);
        nrep(j, size) {
          matrix(i, j) -= factor * matrix(column, j);
          result(i, j) -= factor * result(column, j);
        }
      }
  }
  return result;
}
template<class T>
struct nlinear_solution {
  bool consistent = true;
  int rank = 0;
  nvector<T> particular, one;
  nvector<nvector<T>> basis;
};

namespace ni {
template<class T>
nlinear_solution<T> gaussian(nmatrix<T> matrix, int columns) {
  int rows = matrix.rows(), rank = 0;
  nvector<int> pivot(columns, npos);
  for (int column = 0; column < columns && rank < rows; ++column) {
    int row = rank;
    while (row < rows && matrix(row, column) == T{})
      ++row;
    if (row == rows)
      continue;
    for (int j = column; j <= columns; ++j)
      swap(matrix(rank, j), matrix(row, j));
    T scale = T{1} / matrix(rank, column);
    for (int j = column; j <= columns; ++j)
      matrix(rank, j) *= scale;
    nrep(i, rows)
      if (i != rank && matrix(i, column) != T{}) {
        T factor = matrix(i, column);
        for (int j = column; j <= columns; ++j)
          matrix(i, j) -= factor * matrix(rank, j);
      }
    pivot[column] = rank++;
  }
  nlinear_solution<T> result;
  result.rank = rank;
  for (int row = rank; row < rows; ++row)
    if (matrix(row, columns) != T{}) {
      result.consistent = false;
      return result;
    }
  result.particular.resize(columns);
  nrep(column, columns)
    if (pivot[column] != npos)
      result.particular[column] = matrix(pivot[column], columns);
  nrep(free, columns)
    if (pivot[free] == npos) {
      nvector<T> direction(columns);
      direction[free] = T{1};
      nrep(column, columns)
        if (pivot[column] != npos)
          direction[column] = -matrix(pivot[column], free);
      result.basis.push(move(direction));
    }
  result.one = result.particular;
  return result;
}

template<class T, class B>
nmatrix<T> augmented(nmatrix<T> matrix, const B& values) {
  int rows = matrix.rows(), columns = matrix.cols();
  nmatrix<T> result(rows, columns + 1);
  nrep(row, rows) {
    nrep(column, columns)
      result(row, column) = matrix(row, column);
    result(row, columns) = values[row];
  }
  return result;
}
}
template<nexact_field_element T, class B>
nmaybe<nlinear_solution<T>> nlinear_solve(nmatrix<T> matrix, const B& values) {
  npre(matrix.rows() == nlen(values) && matrix.cols() < INT_MAX);
  int columns = matrix.cols();
  auto result = ni::gaussian(ni::augmented(move(matrix), values), columns);
  return result.consistent ? nmaybe<nlinear_solution<T>>(move(result))
            : nmaybe<nlinear_solution<T>>{};
}
template<nexact_field_element T, class B>
nlinear_solution<T> ngauss(nmatrix<T> matrix, const B& values) {
  npre(matrix.rows() == nlen(values) && matrix.cols() < INT_MAX);
  int columns = matrix.cols();
  return ni::gaussian(ni::augmented(move(matrix), values), columns);
}
template<class A, class B>
auto nzip(A&& left_source, B&& right_source) {
  auto left = nall(forward<A>(left_source));
  auto right = nall(forward<B>(right_source));
  int size = min(left.len(), right.len());
  return nview(size, [left = move(left), right = move(right)](int index) {
    return pair<decltype(left[index]), decltype(right[index])>{left[index], right[index]};
  });
}

template<class A, class B>
auto nproduct(A&& left_source, B&& right_source) {
  auto left = nall(forward<A>(left_source));
  auto right = nall(forward<B>(right_source));
  npre(!left.len() || right.len() <= INT_MAX / left.len());
  int size = left.len() * right.len();
  return nview(size, [left = move(left), right = move(right)](int index) {
    return pair<decltype(left[index / right.len()]), decltype(right[index % right.len()])>{
      left[index / right.len()], right[index % right.len()]};
  });
}
template<class A>
auto nwindows(A&& source, int width, int step = 1) {
  auto base = nall(forward<A>(source));
  npre(width >= 0 && step > 0);
  int size = base.len() < width ? 0 : (base.len() - width) / step + 1;
  if (!width)
    npre(base.len() < INT_MAX);
  return nview(size, [base = move(base), width, step](int index) {
    int left = index * step;
    return nsub(base, left, left + width);
  });
}

class npartition : public nvector<int> {
  using base = nvector<int>;
  int class_count = 0;
public:
using base::base;
  npartition() = default;
  explicit npartition(nvector<int> values) : base(move(values)) {
    map<int, int> dense;
    nrep(i, len()) {
      auto [it, inserted] = dense.emplace(base::operator[](i), class_count);
      if (inserted)
        ++class_count;
      base::operator[](i) = it->second;
    }
  }
  int classes() const { return class_count; }
  int classof(int element, int fallback = npos) const {
    return 0 <= element && element < len() ? base::operator[](element) : fallback;
  }
  int operator[](int element) const {
    npre(0 <= element && element < len());
    return base::operator[](element);
  }
  bool same(int left, int right) const { return (*this)[left] == (*this)[right]; }
  nvector<nvector<int>> groups() const {
    nvector<nvector<int>> result(class_count);
    nrep(i, len())
      result[base::operator[](i)].push(i);
    return result;
  }
  friend bool operator==(const npartition&, const npartition&) = default;
};
using npart = npartition;
using npart_dense = npartition;

class nperm : public nvector<int> {
  using base = nvector<int>;
  void validate() const {
    nvector<char> seen(len());
    nfor(value, *this) {
      npre(0 <= value && value < len() && !seen[value]);
      seen[value] = true;
    }
  }
public:
using base::base;
  nperm() = default;
  explicit nperm(int size) : base(size) { iota(begin(), end(), 0); }
  explicit nperm(nvector<int> values) : base(move(values)) { validate(); }
  nperm(initializer_list<int> values) : base(values) { validate(); }
  int operator()(int value) const {
    npre(0 <= value && value < len());
    return base::operator[](value);
  }
  int operator[](int value) const { return (*this)(value); }
  nperm inverse() const {
    nvector<int> result(len());
    nrep(i, len())
      result[(*this)[i]] = i;
    return nperm(move(result));
  }
  friend nperm operator~(const nperm& value) { return value.inverse(); }
  friend nperm operator*(const nperm& left, const nperm& right) {
    npre(left.len() == right.len());
    nvector<int> result(left.len());
    nrep(i, left.len())
      result[i] = left[right[i]];
    return nperm(move(result));
  }
  nperm pow(int64_t exponent) const {
    nperm base = exponent < 0 ? inverse() : *this, result(len());
    uint64_t count = exponent < 0 ? uint64_t{} - uint64_t(exponent) : uint64_t(exponent);
    while (count) {
      if (count & 1)
        result = base * result;
      count >>= 1;
      if (count)
        base = base * base;
    }
    return result;
  }
  npartition cycles() const {
    nvector<int> labels(len(), npos);
    int classes = 0;
    nrep(start, len())
      if (labels[start] == npos) {
        for (int value = start; labels[value] == npos; value = (*this)[value])
          labels[value] = classes;
        ++classes;
      }
    return npartition(move(labels));
  }
  template<class A>
  auto pull(const A& source) const {
    using T = nplain_t<decltype(source[0])>;
    npre(nlen(source) == len());
    nvector<T> result(len());
    nrep(i, len())
      result[i] = source[(*this)[i]];
    return result;
  }
  template<class A>
  auto push(const A& source) const {
    using T = nplain_t<decltype(source[0])>;
    npre(nlen(source) == len());
    nvector<T> result(len());
    nrep(i, len())
      result[(*this)[i]] = source[i];
    return result;
  }
  friend bool operator==(const nperm&, const nperm&) = default;
};

template<class A>
auto ncompress_stl(const A& source) {
  using T = remove_cvref_t<decltype(*source.begin())>;
  nvector<T> values;
  for (const T& value : source)
    values.push(value);
  return ncompress(nvector<T>(move(values)));
}

namespace ni {
template<class G>
using ngraph_edge_t = decltype(declval<const decltype(declval<const G&>().neighbors(0))&>()[0]);
}
template<class T>
T ncapadd(T left, T right, T limit = numeric_limits<T>::max()) {
  npre(!(left < T{}) && !(right < T{}) && !(limit < T{}));
  return left > limit - right ? limit : left + right;
}
template<ngraph_like G, class F>
auto ngraph_where(const G& graph, F predicate) {
  using W = remove_cvref_t<decltype(nedge_weight(graph.neighbors(0)[0]))>;
  ngraph_list<W> result(graph.vertices());
  ni_nfor_edges(graph, [&](int from, const auto& edge) {
    if (invoke(predicate, edge))
      result.add(from, nedge_vertex(edge), W(nedge_weight(edge)));
  });
  return result;
}
template<ngraph_like G, class F>
auto nkruskal(const G& graph, F weight) {
  using W = remove_cvref_t<invoke_result_t<F&, decltype(graph.neighbors(0)[0])>>;
  struct edge {
    int from, to;
    W weight;
  };
  nvector<edge> edges;
  ni_nfor_edges(graph, [&](int from, const auto& edge_value) {
    edges.push(edge{from, nedge_vertex(edge_value),
          W(invoke(weight, edge_value))});
  });
  nsort(edges, [](const edge& a, const edge& b) { return a.weight < b.weight; });
  nvector<int> parent(graph.vertices(), -1);
  auto find = [&](auto&& self, int vertex) -> int {
    return parent[vertex] < 0 ? vertex : parent[vertex] = self(self, parent[vertex]);
  };
  nmst_result<W> result;
  result.components = graph.vertices();
  nfor(current, edges) {
    int left = find(find, current.from), right = find(find, current.to);
    if (left == right)
      continue;
    if (parent[left] > parent[right])
      swap(left, right);
    parent[left] += parent[right];
    parent[right] = left;
    result.weight += current.weight;
    result.edges.push(nedge<W>{current.from, current.to, current.weight});
    result.edge.push(result.edges.len() - 1);
    --result.components;
  }
  return result;
}

template<ngraph_like G>
auto nkruskal(const G& graph) {
  return nkruskal(graph, [](const auto& edge) { return nedge_weight(edge); });
}
template<class C, bool CheckTotal = false>
  requires integral<C> && (!same_as<remove_cv_t<C>, bool>)
class nflow_dinic {
  int vertex_count = 0;
  nvector<int> head, to, next, level, current;
  nvector<C> residual, initial;
  conditional_t<CheckTotal, nvector<pair<int, C>>, monostate> added;
  bool levels(int source, int sink) {
    fill(level.begin(), level.end(), npos);
    queue<int> pending;
    level[source] = 0;
    pending.push(source);
    while (!pending.empty()) {
      int from = pending.front();
      pending.pop();
      for (int edge = head[from]; edge != npos; edge = next[edge])
        if (residual[edge] > C{} && level[to[edge]] == npos)
          level[to[edge]] = level[from] + 1, pending.push(to[edge]);
    }
    return level[sink] != npos;
  }
  C send(int from, int sink, C available) {
    if (from == sink)
      return available;
    for (int& edge = current[from]; edge != npos; edge = next[edge]) {
      int target = to[edge];
      if (!(residual[edge] > C{}) || level[target] != level[from] + 1)
        continue;
      C pushed = send(target, sink, min(available, residual[edge]));
      if (pushed > C{}) {
        residual[edge] -= pushed;
        npre(residual[edge ^ 1] <= numeric_limits<C>::max() - pushed);
        residual[edge ^ 1] += pushed;
        return pushed;
      }
    }
    return C{};
  }
public:
explicit nflow_dinic(int vertices = 0, int expected_edges = 0)
  : vertex_count(vertices), head(vertices, npos), level(vertices), current(vertices) {
    npre(0 <= vertices && vertices <= INT_MAX / 2);
    reserve(expected_edges);
  }
  int len() const { return vertex_count; }
  int vertices() const { return vertex_count; }
  int edges() const { return to.len() / 2; }
  void reserve(int expected_edges) {
    npre(0 <= expected_edges && expected_edges <= INT_MAX / 2);
    to.reserve(2 * expected_edges);
    next.reserve(2 * expected_edges);
    residual.reserve(2 * expected_edges);
    initial.reserve(2 * expected_edges);
  }
  int add(int from, int target, C capacity, C reverse_capacity = C{}) {
    npre(0 <= from && from < vertex_count && 0 <= target && target < vertex_count);
    npre(capacity >= C{} && reverse_capacity >= C{});
    if constexpr (CheckTotal) {
      for (const auto& [source, old] : added)
        if (source == from) {
          npre(old <= numeric_limits<C>::max() - capacity);
          break;
        }
      added.push(from, capacity);
    }
    int id = edges();
    to.push(target);
    next.push(head[from]);
    residual.push(capacity);
    initial.push(capacity);
    head[from] = to.len() - 1;
    to.push(from);
    next.push(head[target]);
    residual.push(reverse_capacity);
    initial.push(reverse_capacity);
    head[target] = to.len() - 1;
    return id;
  }
  C flow(int source, int sink, C limit = numeric_limits<C>::max()) {
    npre(0 <= source && source < vertex_count && 0 <= sink && sink < vertex_count && source != sink);
    npre(limit >= C{});
    C result{};
    while (result < limit && levels(source, sink)) {
      current = head;
      while (result < limit) {
        C pushed = send(source, sink, limit - result);
        if (!(pushed > C{}))
          break;
        npre(result <= numeric_limits<C>::max() - pushed);
        result += pushed;
      }
    }
    return result;
  }
  C operator()(int source, int sink, C limit = numeric_limits<C>::max()) {
    return flow(source, sink, limit);
  }
  C used(int id) const {
    npre(0 <= id && id < edges());
    return initial[2 * id] - residual[2 * id];
  }
  nvector<unsigned char> cut(int source) const {
    npre(0 <= source && source < vertex_count);
    nvector<unsigned char> result(vertex_count);
    queue<int> pending;
    result[source] = true;
    pending.push(source);
    while (!pending.empty()) {
      int from = pending.front();
      pending.pop();
      for (int edge = head[from]; edge != npos; edge = next[edge])
        if (residual[edge] > C{} && !result[to[edge]])
          result[to[edge]] = true, pending.push(to[edge]);
    }
    return result;
  }
  nvector<unsigned char> mincut(int source) const { return cut(source); }
  void reset() { residual = initial; }
};
template<class C>
using nmaxflow = nflow_dinic<C, true>;
template<class C>
using nflow = nflow_dinic<C>;
template<unsigned_integral T = uint64_t>
class nxorbasis {
  static constexpr int bits = numeric_limits<T>::digits;
  array<T, bits> basis_{};
  int rank_ = 0;
public:
int len() const { return rank_; }
  bool empty() const { return rank_ == 0; }
  bool ins(T value) {
    nrrep(bit, bits) {
      if (!((value >> bit) & T{1}))
        continue;
      if (basis_[bit]) {
        value ^= basis_[bit];
      } else {
        basis_[bit] = value;
        ++rank_;
        return true;
      }
    }
    return false;
  }
  bool has(T value) const {
    nrrep(bit, bits)
      if ((value >> bit) & T{1}) value ^= basis_[bit];
    return value == T{};
  }
  T max(T initial = T{}) const {
    nrrep(bit, bits)
      nchmax(initial, T(initial ^ basis_[bit]));
    return initial;
  }
  T min_nonzero(T fallback = T{}) const {
    nfor(value, basis_)
      if (value)
        return value;
    return fallback;
  }
};

template<class P = long double>
class nprob : public nvector<P> {
  using base = nvector<P>;
  static bool valid_weight(const P& value) {
    if constexpr (floating_point<P>)
      return isfinite(value) && !(value < P{});
    else
      return !(value < P{});
  }
public:
using value_type = P;
  using base::base;
  P sum() const {
    P result{};
    nrep(index, this->len())
      result += (*this)[index];
    return result;
  }
  bool nonnegative() const {
    nrep(index, this->len())
      if (!valid_weight((*this)[index]))
        return false;
    return true;
  }
  bool is_normalized(P total = P{1}) const {
    if (!nonnegative()) return false;
    P actual = sum();
    if constexpr (floating_point<P>) return isfinite(actual) && actual == total;
    else return actual == total;
  }
  nprob& operator*=(P factor) {
    nrep(index, this->len())
      (*this)[index] *= factor;
    return *this;
  }
  friend nprob operator*(nprob distribution, P factor) { return distribution *= factor; }
  friend nprob operator*(P factor, nprob distribution) { return distribution *= factor; }
  template<class F>
  auto expect(F evaluate) const {
    using R = remove_cvref_t<invoke_result_t<F&, int>>;
    R result{};
    nrep(index, this->len())
      result += (*this)[index] * invoke(evaluate, index);
    return result;
  }
  nmaybe<nprob> normalized_copy(P total = P{1}) const {
    P current = sum();
    if (!nonnegative() || !(current > P{}))
      return {};
    if constexpr (floating_point<P>)
      if (!isfinite(current) || !isfinite(total))
        return {};
    nprob result = *this;
    nrep(index, result.len())
      result[index] = result[index] * total / current;
    return result;
  }
  nmaybe<nprob> normalized(P total = P{1}) const { return normalized_copy(total); }
  nprob& normalize(P total = P{1}) {
    auto result = normalized_copy(total);
    npre(result.ok());
    *this = move(result.val());
    return *this;
  }
  int draw(nrng& random = nrng_global, int fallback = npos) const {
    long double total = static_cast<long double>(sum());
    if (!nonnegative() || !(total > 0) || !isfinite(total))
      return fallback;
    long double unit = ldexp(static_cast<long double>(random() >> 11), -53);
    long double remaining = unit * total;
    nrep(index, this->len()) {
      remaining -= static_cast<long double>((*this)[index]);
      if (remaining < 0)
        return index;
    }
    return this->empty() ? fallback : this->len() - 1;
  }
  friend bool operator==(const nprob&, const nprob&) = default;
};
template<class P, class F>
auto nexpect(const nprob<P>& distribution, F evaluate) {
  return distribution.expect(move(evaluate));
}
template<unsigned_integral T = uint64_t>
class nnim {
public:
nvector<T> h;
private:
T xor_{};
public:
nnim() = default;
  template<class A>
  explicit nnim(const A& heaps) {
    nfor(value, heaps)
      push(T(value));
  }
  int len() const { return h.len(); }
  bool empty() const { return h.empty(); }
  void push(T value) { h.push(value); xor_ ^= value; }
  bool win() const { return xor_ != T{}; }
  T nim_sum() const { return xor_; }
  nmaybe<pair<int, T>> winning() const {
    if (!win())
      return {};
    nfori(index, value, h) {
      T reduced = value ^ xor_;
      if (reduced < h[index])
        return pair<int, T>{index, reduced};
    }
    npre(false);
    return {};
  }
  pair<int, T> winning(pair<int, T> fallback) const {
    auto result = winning();
    return result ? result.val() : move(fallback);
  }
};
template<ngraph_like G>
nmaybe<nvector<int>> nsg_dag(const G& graph) {
  auto order = ntoposort(graph);
  if (!order)
    return {};
  int vertices = graph.vertices();
  nvector<int> grundy(vertices, 0);
  nvector<int> mark(vertices + 1, npos);
  nrrep(position, order->len()) {
    int vertex = (*order)[position];
    int stamp = position;
    decltype(auto) adjacency = graph.neighbors(vertex);
    nfor(edge, adjacency) {
      int to = nedge_to(edge);
      npre_index(to, vertices);
      if (grundy[to] <= vertices)
        mark[grundy[to]] = stamp;
    }
    int value = 0;
    while (value <= vertices && mark[value] == stamp)
      ++value;
    grundy[vertex] = value;
  }
  return grundy;
}
template<ngraph_like G>
nvector<int> nsg_dag(const G& graph, nvector<int> fallback) {
  auto result = nsg_dag(graph);
  return result ? move(result.val()) : move(fallback);
}

template<ngraph_like G>
nmaybe<nvector<int>> nsg(const G& graph) {
  return nsg_dag(graph);
}
template<ngraph_like G>
nvector<int> nsg(const G& graph, nvector<int> fallback) {
  return nsg_dag(graph, move(fallback));
}

struct ninterval_query {
  int left;
  int right;
  int id;
};
template<class Q>
nvector<int> nmo_order(const Q& queries, int universe) {
  npre(universe >= 0);
  int count = nlen(queries);
  int block = max(1, int(sqrt(double(max(1, universe)))));
  nvector<int> order(count);
  nrep(index, count) {
    npre(0 <= queries[index].left && queries[index].left <= queries[index].right &&
    queries[index].right <= universe);
    order[index] = index;
  }
  nsort(order, [&](int left, int right) {
    int block_left = queries[left].left / block;
    int block_right = queries[right].left / block;
    if (block_left != block_right)
      return block_left < block_right;
    if (block_left & 1)
      return queries[right].right < queries[left].right;
    return queries[left].right < queries[right].right;
  });
  return order;
}
template<class Q, class AddLeft, class AddRight, class RemoveLeft, class RemoveRight,
  class Answer>
void nrun_mo(const Q& queries, int universe, AddLeft&& add_left, AddRight&& add_right,
    RemoveLeft&& remove_left, RemoveRight&& remove_right, Answer&& answer) {
  auto order = nmo_order(queries, universe);
  int left = 0;
  int right = 0;
  nrep(position, order.len()) {
    int query_index = order[position];
    const auto& query = queries[query_index];
    while (query.left < left)
      invoke(add_left, --left);
    while (right < query.right)
      invoke(add_right, right++);
    while (left < query.left)
      invoke(remove_left, left++);
    while (query.right < right)
      invoke(remove_right, --right);
    invoke(answer, query.id);
  }
}

template<class Q, class Add, class Remove, class Answer>
void nrun_mo(const Q& queries, int universe, Add&& add, Remove&& remove, Answer&& answer) {
  nrun_mo(queries, universe, add, add, remove, remove, answer);
}
template<class T>
struct nline {
  union {
    T m;
    T slope;
  };
  union {
    T b;
    T intercept;
  };
  using value_type = nwide_t<T>;
  constexpr nline(T m = {}, T b = {}) : m(m), b(b) {}
  constexpr value_type operator()(T x) const {
    return nchecked_add(nchecked_mul(nchecked_number<value_type>(m),
                  nchecked_number<value_type>(x)),
            nchecked_number<value_type>(b));
  }
  friend bool operator==(const nline& left, const nline& right) {
    return left.m == right.m && left.b == right.b;
  }
};
template<class T>
using nline_function = nline<T>;

namespace ni {
template<class T>
struct line_domain {
  const nvector<T>* values = nullptr;
  T first{};
  T last{};
  int len() const {
    if (values)
      return values->len();
    __int128 size = __int128(last) - first;
    npre(0 <= size && size <= INT_MAX);
    return int(size);
  }
  T at(int index) const {
    npre_index(index, len());
    return values ? (*values)[index]
        : T(__int128(first) + index);
  }
  int lower(const T& value) const {
    if (values)
      return nlower(*values, value);
    __int128 index = __int128(value) - first;
    return index < 0 ? 0 : index > len() ? len() : int(index);
  }
  int exact(const T& value) const {
    int index = lower(value);
    return index < len() && !(value < at(index)) && !(at(index) < value)
      ? index
      : npos;
  }
};

template<class T, class Better>
class line_tree {
public:
using line_type = nline_function<T>;
  using value_type = typename line_type::value_type;
private:
struct node {
    line_type line{};
    int left = npos;
    int right = npos;
    bool used = false;
  };
  line_domain<T> domain_;
  [[no_unique_address]] Better better_;
  nvector<node> nodes_{node{}};
  int child(int vertex, bool right) {
    int& link = right ? nodes_[vertex].right : nodes_[vertex].left;
    if (link == npos) {
      int next = nodes_.len();
      link = next;
      nodes_.push();
      return next;
    }
    return link;
  }
  void put(int vertex, int left, int right, line_type line) {
    if (!nodes_[vertex].used) {
      nodes_[vertex].line = line;
      nodes_[vertex].used = true;
      return;
    }
    int middle = left + (right - left) / 2;
    bool left_better = invoke(better_, line(domain_.at(left)),
              nodes_[vertex].line(domain_.at(left)));
    bool middle_better = invoke(better_, line(domain_.at(middle)),
                nodes_[vertex].line(domain_.at(middle)));
    if (middle_better)
      swap(nodes_[vertex].line, line);
    if (right - left == 1)
      return;
    if (left_better != middle_better)
      put(child(vertex, false), left, middle, line);
    else
      put(child(vertex, true), middle, right, line);
  }
  void put_segment(int vertex, int left, int right,
        int query_left, int query_right, line_type line) {
    if (query_left <= left && right <= query_right) {
      put(vertex, left, right, line);
      return;
    }
    int middle = left + (right - left) / 2;
    if (query_left < middle)
      put_segment(child(vertex, false), left, middle,
          query_left, query_right, line);
    if (middle < query_right)
      put_segment(child(vertex, true), middle, right,
          query_left, query_right, line);
  }
  nmaybe<value_type> get(int vertex, int left, int right, int index) const {
    nmaybe<value_type> result;
    if (nodes_[vertex].used)
      result = nodes_[vertex].line(domain_.at(index));
    if (right - left == 1)
      return result;
    int middle = left + (right - left) / 2;
    int next = index < middle ? nodes_[vertex].left : nodes_[vertex].right;
    if (next == npos)
      return result;
    auto candidate = index < middle
            ? get(next, left, middle, index)
            : get(next, middle, right, index);
    if (candidate && (!result ||
          invoke(better_, candidate.val(), result.val())))
      result = candidate.val();
    return result;
  }
public:
line_tree() = default;
  line_tree(line_domain<T> domain, Better better = {})
  : domain_(domain), better_(move(better)) {}
  int len() const {
    return domain_.len();
  }
  int nodes() const {
    return nodes_.len();
  }
  void add(line_type line) {
    if (len())
      put(0, 0, len(), line);
  }
  void add_segment(line_type line, int left, int right) {
    npre_range(left, right, len());
    if (left < right)
      put_segment(0, 0, len(), left, right, line);
  }
  nmaybe<value_type> get_index(int index) const {
    npre_index(index, len());
    return get(0, 0, len(), index);
  }
  int lower(const T& value) const {
    return domain_.lower(value);
  }
  int exact(const T& value) const {
    return domain_.exact(value);
  }
};
}
template<signed_integral T, class Better = nless<nwide_t<T>>>
class nlichao {
public:
using line_type = nline_function<T>;
  using value_type = typename line_type::value_type;
private:
ni::line_tree<T, Better> tree_;
  T first_;
  T last_;
public:
explicit nlichao(T first, T last, Better better = {})
  : tree_(ni::line_domain<T>{nullptr, first, last}, move(better)),
  first_(first), last_(last) {
    npre(first < last);
  }
  int nodes() const {
    return tree_.nodes();
  }
  void add(line_type line) {
    tree_.add(line);
  }
  void add(T slope, T intercept) {
    add(line_type{slope, intercept});
  }
  void add_segment(line_type line, T left, T right) {
    npre(first_ <= left && left <= right && right <= last_);
    tree_.add_segment(line, tree_.lower(left) - tree_.lower(first_),
          tree_.lower(right) - tree_.lower(first_));
  }
  void add_segment(T slope, T intercept, T left, T right) {
    add_segment(line_type{slope, intercept}, left, right);
  }
  nmaybe<value_type> query(T x) const {
    npre(first_ <= x && x < last_);
    return tree_.get_index(tree_.lower(x));
  }
};
template<class T, class Better = nless<nwide_t<T>>>
class nlichao_static {
public:
using line_type = nline<T>;
  using value_type = typename line_type::value_type;
  nvector<T> x;
private:
ni::line_tree<T, Better> tree_;
public:
nlichao_static() = default;
  template<class A>
  explicit nlichao_static(const A& coordinates, Better better = {})
  : x(ncollect<T>(coordinates)),
  tree_(ni::line_domain<T>{&x, {}, {}}, move(better)) {
    nsort(x);
    nunique(x);
    npre(x.len() <= (INT_MAX - 1) / 4);
  }
  int len() const {
    return x.len();
  }
  bool empty() const {
    return x.empty();
  }
  bool hasx(const T& value) const {
    return tree_.exact(value) != npos;
  }
  void add(line_type line) {
    tree_.add(line);
  }
  void add(T slope, T intercept) {
    add(line_type{slope, intercept});
  }
  void addidx(line_type line, int left, int right) {
    tree_.add_segment(static_cast<nline_function<T>>(line), left, right);
  }
  void addseg(line_type line, T left, T right) {
    addidx(line, tree_.lower(left), tree_.lower(right));
  }
  nmaybe<value_type> get(T value) const {
    int index = tree_.exact(value);
    return index == npos ? nmaybe<value_type>{} : tree_.get_index(index);
  }
  value_type get(T value, value_type fallback) const {
    auto result = get(value);
    return result ? result.val() : move(fallback);
  }
  value_type operator()(T value, value_type fallback) const {
    return get(value, move(fallback));
  }
};

template<signed_integral I, class F, class Better = nless<>>
I nunimodal_arg(I first, I last, F function, Better better = {}) {
  npre(first < last);
  auto distance = [](I left, I right) { return __uint128_t(right) - __uint128_t(left); };
  while (distance(first, last) > 4) {
    I third = I(distance(first, last) / 3);
    I left = I(__int128_t(first) + third);
    I right = I(__int128_t(last) - 1 - third);
    auto left_value = invoke(function, left);
    auto right_value = invoke(function, right);
    if (invoke(better, right_value, left_value))
      first = left + 1;
    else
      last = right + 1;
  }
  I best = first;
  auto value = invoke(function, best);
  for (I candidate = first + 1; candidate < last; ++candidate) {
    auto candidate_value = invoke(function, candidate);
    if (invoke(better, candidate_value, value)) {
      best = candidate;
      value = move(candidate_value);
    }
  }
  return best;
}
template<floating_point T, class F>
T nternary_min(T left, T right, F function, int iterations = 100) {
  npre(left <= right && iterations >= 0);
  nrep(iteration, iterations) {
    T distance = (right - left) / T{3};
    T a = left + distance;
    T b = right - distance;
    if (invoke(function, a) < invoke(function, b))
      right = b;
    else
      left = a;
  }
  return midpoint(left, right);
}
template<class T, class O = nadd<T>>
class npersistent_seg {
  struct node {
    T aggregate;
    int left = 0;
    int right = 0;
  };
  [[no_unique_address]] O operation_;
  int size_ = 0;
  int base_ = 1;
  vector<node> nodes_;
  vector<int> roots_;
  static int checked_size(int size) {
    npre(0 <= size && size <= (1 << 30));
    return size;
  }
  const T& aggregate(int node) const {
    return nodes_[node].aggregate;
  }
  int append(node value) {
    npre(nodes_.size() <= size_t(INT_MAX));
    int index = int(nodes_.size());
    nodes_.push_back(move(value));
    return index;
  }
  template<class V>
  int build(const V& source, int left, int right) {
    if (left >= size_)
      return 0;
    if (right - left == 1)
      return append({source[left], 0, 0});
    int middle = left + (right - left) / 2;
    int left_node = build(source, left, middle);
    int right_node = build(source, middle, right);
    return append({operation_(aggregate(left_node), aggregate(right_node)),
        left_node, right_node});
  }
  int set0(int current, int left, int right, int index, const T& value) {
    if (right - left == 1)
      return append({value, 0, 0});
    int left_node = nodes_[current].left;
    int right_node = nodes_[current].right;
    int middle = left + (right - left) / 2;
    if (index < middle)
      left_node = set0(left_node, left, middle, index, value);
    else
      right_node = set0(right_node, middle, right, index, value);
    return append({operation_(aggregate(left_node), aggregate(right_node)),
        left_node, right_node});
  }
  T fold0(int current, int left, int right, int query_left, int query_right) const {
    if (!current || query_right <= left || right <= query_left)
      return operation_.id();
    if (query_left <= left && right <= query_right)
      return aggregate(current);
    int middle = left + (right - left) / 2;
    return operation_(fold0(nodes_[current].left, left, middle, query_left, query_right),
          fold0(nodes_[current].right, middle, right, query_left, query_right));
  }
public:
explicit npersistent_seg(int size = 0, O operation = {})
  : operation_(move(operation)), size_(checked_size(size)), base_(nbitceil(size_)),
  nodes_{{operation_.id(), 0, 0}}, roots_{0} {}
  template<class V>
    requires requires(const V& value) {
      nlen(value);
      value[0];
    }
  explicit npersistent_seg(const V& source, O operation = {})
  : operation_(move(operation)), size_(checked_size(nlen(source))), base_(nbitceil(size_)),
  nodes_{{operation_.id(), 0, 0}} {
    roots_.push_back(size_ ? build(source, 0, base_) : 0);
  }
  int len() const {
    return size_;
  }
  int versions() const {
    npre(roots_.size() <= size_t(INT_MAX));
    return int(roots_.size());
  }
  int nodes() const {
    npre(!nodes_.empty() && nodes_.size() <= size_t(INT_MAX) + 1);
    return int(nodes_.size() - 1);
  }
  const O& operation() const {
    return operation_;
  }
  void reserve_nodes(int count) {
    npre(count >= 0);
    nodes_.reserve(size_t(count) + 1);
  }
  int fork(int version) {
    npre(0 <= version && version < versions());
    npre(roots_.size() < size_t(INT_MAX));
    roots_.push_back(roots_[version]);
    return versions() - 1;
  }
  int set(int version, int index, const T& value) {
    npre(0 <= version && version < versions());
    npre_index(index, size_);
    npre(roots_.size() < size_t(INT_MAX));
    int root = set0(roots_[version], 0, base_, index, value);
    roots_.push_back(root);
    return versions() - 1;
  }
  T fold(int version, int left, int right) const {
    npre(0 <= version && version < versions());
    npre_range(left, right, size_);
    return fold0(roots_[version], 0, base_, left, right);
  }
  T fold(int version) const {
    return fold(version, 0, size_);
  }
  T get(int version, int index) const {
    npre_index(index, size_);
    return fold(version, index, index + 1);
  }
};
template<class T>
struct nntt_info {
  static constexpr bool ok = false;
};
template<>
struct nntt_info<nmodint<998244353>> {
  static constexpr bool ok = true;
  static constexpr uint64_t root = 3;
};

template<>
struct nntt_info<nmodint<1004535809>> {
  static constexpr bool ok = true;
  static constexpr uint64_t root = 3;
};
template<>
struct nntt_info<nmodint<469762049>> {
  static constexpr bool ok = true;
  static constexpr uint64_t root = 3;
};

namespace ni {
template<class T>
inline constexpr bool nstatic_modular = false;
template<uint64_t Modulus>
inline constexpr bool nstatic_modular<nmodint<Modulus>> = true;

inline uint64_t nprimitive_root(uint64_t modulus) {
  npre(2 <= modulus && modulus <= UINT32_MAX && nisprime(modulus));
  if (modulus == 2)
    return 1;
  uint64_t phi = modulus - 1;
  uint64_t remaining = phi;
  nvector<uint64_t> factors;
  for (uint64_t prime = 2; prime <= remaining / prime; ++prime) {
    if (remaining % prime)
      continue;
    factors.push(prime);
    while (remaining % prime == 0)
      remaining /= prime;
  }
  if (remaining > 1)
    factors.push(remaining);
  for (uint64_t candidate = 2;; ++candidate) {
    bool primitive = true;
    nfor(prime, factors)
      if (npowmod(candidate, phi / prime, modulus) == 1) {
        primitive = false;
        break;
      }
    if (primitive)
      return candidate;
  }
}
template<uint64_t Modulus>
void nntt(nvector<nmodint<Modulus>>& values, bool inverse) {
  int size = values.len();
  npre(size > 0 && has_single_bit(unsigned(size)));
  npre((Modulus - 1) % uint64_t(size) == 0);
  for (int index = 1, reversed = 0; index < size; ++index) {
    int bit = size >> 1;
    for (; reversed & bit; bit >>= 1)
      reversed ^= bit;
    reversed ^= bit;
    if (index < reversed)
      swap(values[index], values[reversed]);
  }
  using mint = nmodint<Modulus>;
  static const uint64_t primitive = [] {
    if constexpr (nntt_info<mint>::ok)
      return nntt_info<mint>::root;
    else
      return nprimitive_root(Modulus);
  }();
  for (int width = 2; width <= size;) {
    mint step = mint(primitive).pow((Modulus - 1) / uint64_t(width));
    if (inverse)
      step = step.inverse().val();
    for (int first = 0; first < size; first += width) {
      mint root = 1;
      nrep(offset, width / 2) {
        mint even = values[first + offset];
        mint odd = values[first + offset + width / 2] * root;
        values[first + offset] = even + odd;
        values[first + offset + width / 2] = even - odd;
        root *= step;
      }
    }
    if (width == size)
      break;
    width <<= 1;
  }
  if (inverse) {
    mint scale = mint(size).inverse().val();
    nrep(index, size)
      values[index] *= scale;
  }
}
}
template<class A, class B>
auto nconv_naive(const A& left, const B& right) {
  using T = nindex_value_t<const A>;
  static_assert(same_as<T, nindex_value_t<const B>>);
  if (!nlen(left) || !nlen(right))
    return nvector<T>{};
  npre(nlen(left) <= INT_MAX - nlen(right) + 1);
  nvector<T> result(nlen(left) + nlen(right) - 1);
  nrep(i, nlen(left))
    nrep(j, nlen(right))
      result[i + j] += left[i] * right[j];
  return result;
}
template<class A, class B>
  requires nindexed<const A&> && nindexed<const B&> &&
    ni::nstatic_modular<nindex_value_t<const A>> &&
    nexact_field<nindex_value_t<const A>> &&
    same_as<nindex_value_t<const A>, nindex_value_t<const B>>
auto nconv_ntt(const A& left, const B& right) {
  using mint = nindex_value_t<const A>;
  if (!nlen(left) || !nlen(right))
    return nvector<mint>{};
  npre(nlen(left) <= INT_MAX - nlen(right) + 1);
  int size = nlen(left) + nlen(right) - 1;
  int transform_size = nbitceil(size);
  npre(mint::mod() <= UINT32_MAX &&
  (mint::mod() - 1) % uint64_t(transform_size) == 0);
  nvector<mint> first(transform_size), second(transform_size);
  nrep(index, nlen(left))
    first[index] = left[index];
  nrep(index, nlen(right))
    second[index] = right[index];
  ni::nntt(first, false);
  ni::nntt(second, false);
  nrep(index, transform_size)
    first[index] *= second[index];
  ni::nntt(first, true);
  first.resize(size);
  return first;
}

template<class A, class B>
auto nconv_auto(const A& left, const B& right) {
  using T = nindex_value_t<const A>;
  static_assert(same_as<T, nindex_value_t<const B>>);
  if constexpr (ni::nstatic_modular<T> && nexact_field<T>) {
    if (nlen(left) && nlen(right) && min(nlen(left), nlen(right)) >= 32) {
      long long size = 1LL * nlen(left) + nlen(right) - 1;
      if (size <= (1 << 30)) {
        int transform_size = nbitceil(int(size));
        if (T::mod() <= UINT32_MAX && nisprime(T::mod()) &&
        (T::mod() - 1) % uint64_t(transform_size) == 0)
          return nconv_ntt(left, right);
      }
    }
  }
  return nconv_naive(left, right);
}
template<class A, class B>
auto nconv(const A& left, const B& right) {
  return nconv_auto(left, right);
}
template<class A>
auto npoly_derivative(const A& polynomial) {
  using T = nindex_value_t<const A>;
  nvector<T> result(max(0, nlen(polynomial) - 1));
  for (int index = 1; index < nlen(polynomial); ++index)
    result[index - 1] = polynomial[index] * T(index);
  return result;
}
template<class A>
  requires nindexed<const A&> &&
    (floating_point<nindex_value_t<const A>> ||
    nexact_field_element<nindex_value_t<const A>>)
auto npoly_integral(const A& polynomial) {
  using T = nindex_value_t<const A>;
  npre(nlen(polynomial) < INT_MAX);
  nvector<T> result(nlen(polynomial) + 1);
  nrep(index, nlen(polynomial))
    result[index + 1] = polynomial[index] / T(index + 1);
  return result;
}
template<class A, class X>
auto npoly_evaluate(const A& polynomial, const X& point) {
  using T = nindex_value_t<const A>;
  T result{};
  nrrep(index, nlen(polynomial))
    result = result * point + polynomial[index];
  return result;
}

template<class A>
auto nfps_inverse(const A& series, int terms) {
  using T = nindex_value_t<const A>;
  npre(terms >= 0);
  if (!terms)
    return nvector<T>{};
  npre(nlen(series) > 0 && series[0] != T{});
  nvector<T> result{T{1} / series[0]};
  while (result.len() < terms) {
    int size = int(min<long long>(terms, 2LL * result.len()));
    nvector<T> prefix(size);
    nrep(index, min(size, nlen(series)))
      prefix[index] = series[index];
    auto correction = nconv(prefix, result);
    correction.resize(size);
    correction[0] = T{2} - correction[0];
    for (int index = 1; index < size; ++index)
      correction[index] = -correction[index];
    result = nconv(result, correction);
    result.resize(size);
  }
  return result;
}
template<class T>
class npoly {
public:
using value_type = T;
  nvector<T> a;
  npoly() = default;
  npoly(initializer_list<T> coefficients) : a(coefficients) {
    norm();
  }
  explicit npoly(nvector<T> coefficients) : a(move(coefficients)) {
    norm();
  }
  int len() const {
    return a.len();
  }
  int deg() const {
    return len() - 1;
  }
  bool empty() const {
    return a.empty();
  }
  void norm() {
    while (!a.empty() && a.back() == T{})
      a.pop_back();
  }
  T operator[](int index) const {
    return 0 <= index && index < len() ? a[index] : T{};
  }
  T& at(int index) {
    npre_index(index, len());
    return a[index];
  }
  const T& at(int index) const {
    npre_index(index, len());
    return a[index];
  }
  template<class X>
  T operator()(const X& point) const {
    return npoly_evaluate(a, point);
  }
  npoly& operator+=(const npoly& other) {
    if (len() < other.len())
      a.resize(other.len(), T{});
    nrep(index, other.len())
      a[index] += other.a[index];
    norm();
    return *this;
  }
  npoly& operator-=(const npoly& other) {
    if (len() < other.len())
      a.resize(other.len(), T{});
    nrep(index, other.len())
      a[index] -= other.a[index];
    norm();
    return *this;
  }
  npoly& operator*=(const npoly& other) {
    a = nconv(a, other.a);
    norm();
    return *this;
  }
  friend npoly operator+(npoly left, const npoly& right) {
    return left += right;
  }
  friend npoly operator-(npoly left, const npoly& right) {
    return left -= right;
  }
  friend npoly operator*(npoly left, const npoly& right) {
    return left *= right;
  }
  friend bool operator==(const npoly&, const npoly&) = default;
  npoly deriv() const {
    return npoly(npoly_derivative(a));
  }
  npoly integral() const {
    return npoly(npoly_integral(a));
  }
  npoly cut(int terms) const {
    npre(terms >= 0);
    nvector<T> result(min(terms, len()));
    nrep(index, result.len())
      result[index] = a[index];
    return npoly(move(result));
  }
  npoly inv(int terms) const {
    npre(terms >= 0);
    if (!terms)
      return {};
    npre(!empty() && a[0] != T{});
    return npoly(nfps_inverse(a, terms));
  }
  npoly log(int terms) const {
    npre(terms >= 0);
    if (!terms)
      return {};
    npre((*this)[0] == T{1});
    return (deriv() * inv(terms)).cut(terms - 1).integral().cut(terms);
  }
  npoly exp(int terms) const {
    npre(terms >= 0);
    if (!terms)
      return {};
    npre((*this)[0] == T{});
    npoly result{T{1}};
    for (int size = 1; size < terms;) {
      int next = int(min<long long>(terms, 2LL * size));
      npoly correction = cut(next) - result.log(next);
      if (correction.empty())
        correction.a.resize(1);
      correction.a[0] += T{1};
      result = (result * correction).cut(next);
      size = next;
    }
    return result.cut(terms);
  }
};
template<class A>
auto nberlekamp(const A& sequence) {
  using T = nindex_value_t<const A>;
  nvector<T> current{T{1}};
  nvector<T> previous{T{1}};
  int length = 0;
  int shift = 1;
  T previous_discrepancy{1};
  nrep(index, nlen(sequence)) {
    T discrepancy = sequence[index];
    for (int i = 1; i <= length; ++i)
      discrepancy += current[i] * sequence[index - i];
    if (discrepancy == T{}) {
      ++shift;
      continue;
    }
    nvector<T> saved = current;
    T factor = discrepancy / previous_discrepancy;
    if (current.len() < previous.len() + shift)
      current.resize(previous.len() + shift, T{});
    nrep(i, previous.len())
      current[i + shift] -= factor * previous[i];
    if (2 * length <= index) {
      length = index + 1 - length;
      previous = move(saved);
      previous_discrepancy = discrepancy;
      shift = 1;
    } else {
      ++shift;
    }
  }
  nvector<T> result(length);
  nrep(i, length)
    result[i] = -current[i + 1];
  return result;
}
template<class A, class C>
auto nrec_nth(const A& initial, const C& recurrence, uint64_t index)
  -> nmaybe<nindex_value_t<const A>> {
  using T = nindex_value_t<const A>;
  int order = nlen(recurrence);
  if (index < uint64_t(nlen(initial)))
    return initial[int(index)];
  if (!order || nlen(initial) < order)
    return {};
  npre(order <= INT_MAX / 2);
  auto multiply = [&](const nvector<T>& left, const nvector<T>& right) {
    nvector<T> product(2 * order - 1, T{});
    nrep(i, order)
      nrep(j, order)
        product[i + j] += left[i] * right[j];
    for (int degree = 2 * order - 1; degree-- > order;)
      nrep(offset, order)
        product[degree - offset - 1] += product[degree] * recurrence[offset];
    product.resize(order);
    return product;
  };
  nvector<T> coefficient(order, T{});
  nvector<T> power(order, T{});
  coefficient[0] = T{1};
  if (order == 1)
    power[0] = recurrence[0];
  else
    power[1] = T{1};
  while (index) {
    if (index & 1)
      coefficient = multiply(coefficient, power);
    index >>= 1;
    if (index)
      power = multiply(power, power);
  }
  T result{};
  nrep(i, order)
    result += coefficient[i] * initial[i];
  return result;
}
template<class A, class C>
auto nrec_nth(const A& initial, const C& recurrence, uint64_t index,
    nindex_value_t<const A> fallback) {
  auto result = nrec_nth(initial, recurrence, index);
  return result ? result.val() : move(fallback);
}

template<integral T>
  requires(!same_as<remove_cv_t<T>, bool>)
class nwavelet {
  using U = make_unsigned_t<T>;
  static constexpr int bits_ = numeric_limits<U>::digits;
  int size_ = 0;
  array<vector<int>, bits_> zero_prefix_;
  array<int, bits_> zero_count_{};
  static constexpr U encode(T value) {
    U encoded = U(value);
    if constexpr (is_signed_v<T>)
      encoded ^= U(1) << (bits_ - 1);
    return encoded;
  }
  static constexpr T decode(U encoded) {
    if constexpr (is_signed_v<T>) {
      encoded ^= U(1) << (bits_ - 1);
      return bit_cast<T>(encoded);
    } else {
      return encoded;
    }
  }
  pair<int, int> descend(int level, int left, int right, bool one) const {
    if (one)
      return {zero_count_[level] + left - zero_prefix_[level][left],
        zero_count_[level] + right - zero_prefix_[level][right]};
    return {zero_prefix_[level][left], zero_prefix_[level][right]};
  }
public:
nwavelet() {
    nfor(prefix, zero_prefix_)
      prefix.assign(1, 0);
  }
  template<class A>
    requires nindexed<const A&>
  explicit nwavelet(const A& source) : size_(nlen(source)) {
    vector<U> current(size_), next(size_);
    nrep(index, size_)
      current[index] = encode(T(source[index]));
    nrep(level, bits_) {
      int bit = bits_ - 1 - level;
      auto& prefix = zero_prefix_[level];
      prefix.resize(size_t(size_) + 1);
      nrep(index, size_)
        prefix[index + 1] = prefix[index] +
                int(((current[index] >> bit) & U(1)) == 0);
      int zeros = zero_count_[level] = prefix[size_];
      int zero_position = 0;
      int one_position = zeros;
      nfor(value, current) {
        if ((value >> bit) & U(1))
          next[one_position++] = value;
        else
          next[zero_position++] = value;
      }
      current.swap(next);
    }
  }
  int len() const {
    return size_;
  }
  bool empty() const {
    return size_ == 0;
  }
  T kth(int left, int right, int rank) const {
    npre_range(left, right, size_);
    npre(0 <= rank && rank < right - left);
    U value = 0;
    nrep(level, bits_) {
      int bit = bits_ - 1 - level;
      int zeros = zero_prefix_[level][right] - zero_prefix_[level][left];
      if (rank < zeros) {
        tie(left, right) = descend(level, left, right, false);
      } else {
        rank -= zeros;
        value |= U(1) << bit;
        tie(left, right) = descend(level, left, right, true);
      }
    }
    return decode(value);
  }
  int count_less(int left, int right, T bound) const {
    npre_range(left, right, size_);
    U value = encode(bound);
    int result = 0;
    nrep(level, bits_) {
      int bit = bits_ - 1 - level;
      int zeros = zero_prefix_[level][right] - zero_prefix_[level][left];
      if ((value >> bit) & U(1)) {
        result += zeros;
        tie(left, right) = descend(level, left, right, true);
      } else {
        tie(left, right) = descend(level, left, right, false);
      }
    }
    return result;
  }
  int count(int left, int right, T value) const {
    npre_range(left, right, size_);
    U encoded = encode(value);
    nrep(level, bits_) {
      int bit = bits_ - 1 - level;
      if ((encoded >> bit) & U(1))
        tie(left, right) = descend(level, left, right, true);
      else
        tie(left, right) = descend(level, left, right, false);
    }
    return right - left;
  }
  int count(int left, int right, T low, T high) const {
    npre(!(high < low));
    return count_less(left, right, high) - count_less(left, right, low);
  }
  nmaybe<T> predecessor(int left, int right, T bound) const {
    int count = count_less(left, right, bound);
    return count ? nmaybe<T>(kth(left, right, count - 1)) : nmaybe<T>{};
  }
  nmaybe<T> successor(int left, int right, T bound) const {
    int count = count_less(left, right, bound);
    return count < right - left ? nmaybe<T>(kth(left, right, count)) : nmaybe<T>{};
  }
};
